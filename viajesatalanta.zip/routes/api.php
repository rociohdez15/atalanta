<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Topbar\MensajesController;
use App\Http\Controllers\Topbar\NotificacionesController;
use App\Http\Controllers\Eventos\EventosController;
use App\Http\Controllers\Dashboard\DashboardController;
use App\Http\Controllers\Administradores\AdministradoresController;
use App\Http\Controllers\Galeria\GaleriaController;
use App\Http\Controllers\Paquetes\PaqueteTuristicoController;
use App\Http\Controllers\Blog\BlogController;
use App\Http\Controllers\Pago\PagoController;
use App\Http\Controllers\Usuarios\DashboardUserController;
use App\Http\Controllers\Reservas\ReservasController;
use App\Http\Controllers\Facturas\FacturasController;
use App\Models\Cliente;
use Illuminate\Http\Request;


//Auth
Route::post('/auth/login', [AuthController::class, 'login']);
Route::post('/auth/register', [AuthController::class, 'register']);
Route::post('/auth/olvidaste', [AuthController::class, 'olvidaste']);


//Dashboard panel de administración
Route::prefix('admin')->group(function () {
    Route::get('/total-proveedores', [DashboardController::class, 'getTotalProveedores']);
    Route::get('/total-ingresos', [DashboardController::class, 'getTotalIngresos']);
    Route::get('/total-reservas', [DashboardController::class, 'getTotalReservas']);
    Route::get('/total-usuarios', [DashboardController::class, 'getTotalUsuarios']);
    Route::get('/ingresos-semana-actual', [DashboardController::class, 'obtenerIngresosSemanaActual']);
    Route::get('/ingresos-semana-anterior', [DashboardController::class, 'obtenerIngresosSemanaAnterior']);
    Route::get('/ventas-semana-actual', [DashboardController::class, 'obtenerVentasSemanaActual']);
    Route::get('/ingresos-y-ventas-semana', [DashboardController::class, 'obtenerIngresosYReservasSemana']);
    Route::get('/ventas-anuales', [DashboardController::class, 'obtenerVentasAnuales']);
    Route::get('/ingresos-primer-trimestre', fn() => app(DashboardController::class)->ingresosTrimestre(1));
    Route::get('/ingresos-segundo-trimestre', fn() => app(DashboardController::class)->ingresosTrimestre(2));
    Route::get('/ingresos-tercer-trimestre', fn() => app(DashboardController::class)->ingresosTrimestre(3));
    Route::get('/obtener-proyectos', [DashboardController::class, 'obtenerProyectos']);
    Route::get('/obtener-form-contactos', [DashboardController::class, 'obtenerFormContacto']);
    Route::get('/obtener-notificaciones', [DashboardController::class, 'obtenerNotificaciones']);
});

// Administración
Route::prefix('rol-admin')->group(function () {
    Route::get('/obtener-admins', [AdministradoresController::class, 'obtenerAdmins']);
    Route::get('/buscar', [AdministradoresController::class, 'buscarUsuario']); // ?input=...
    Route::delete('/eliminar/{id}', [AdministradoresController::class, 'eliminarAdmin']);
    Route::put('/editar/{id}', [AdministradoresController::class, 'editarEmail']); // email en body o query param
    Route::get('/existe', [AdministradoresController::class, 'existeAdmin']); // ?email=...
    Route::post('/alta', [AdministradoresController::class, 'altaAdmin']); // email y password en body
});

// Eventos
Route::prefix('eventos')->group(function () {
    Route::post('/crear-evento', [EventosController::class, 'crearEvento']);
    Route::get('/obtener-eventos', [EventosController::class, 'obtenerEventos']);
    Route::delete('/eliminar/{id}', [EventosController::class, 'eliminarEvento']);
    Route::put('/editar/{id}', [EventosController::class, 'editarEvento']);
    Route::get('/buscar', [EventosController::class, 'buscarEvento']);
});

// Mensajes
Route::prefix('mensajes')->group(function () {
    Route::get('/obtener-mensajes', [MensajesController::class, 'obtenerMensajes']);
    Route::put('/leido', [MensajesController::class, 'marcarComoLeido']);
    Route::get('/mensaje/{id}', [MensajesController::class, 'obtenerMensajePorId']);
    Route::get('/buscar', [MensajesController::class, 'buscarMensajes']);
    Route::delete('/eliminar/{id}', [MensajesController::class, 'eliminarMensaje']);
        Route::post('/contacto', [MensajesController::class, 'agregar']);
});

// Notificaciones
Route::prefix('notificaciones')->group(function () {
    Route::get('/obtener-notificaciones', [NotificacionesController::class, 'obtenerNotificaciones']);
    Route::put('/notificaciones/leido', [NotificacionesController::class, 'marcarComoLeido']);
    Route::get('/notificacion/{id}', [NotificacionesController::class, 'obtenerNotificacionPorId']);
    Route::get('/notificaciones/buscar', [NotificacionesController::class, 'buscarNotificacion']);
    Route::delete('/eliminar/{id}', [NotificacionesController::class, 'eliminarNotificacion']);
});


// Imagenes
Route::prefix('imagenes')->group(function () {
    Route::get('/', [GaleriaController::class, 'index']);
    Route::get('/obtener-galeria', [GaleriaController::class, 'obtenerGaleria']);
    Route::post('/', [GaleriaController::class, 'guardarImagen']);
    Route::put('/editar/{id}', [GaleriaController::class, 'editar']);
    Route::delete('/eliminar/{id}', [GaleriaController::class, 'eliminar']);
    Route::get('/buscar', [GaleriaController::class, 'buscarImagen']);
});


// Paquetes
Route::get('/paquetes/ultimos', [PaqueteTuristicoController::class, 'ultimos']);
Route::get('/paquetes/buscar', [PaqueteTuristicoController::class, 'buscar']);
Route::get('/paquetes', [PaqueteTuristicoController::class, 'index']);
Route::get('/paquetes/{id}', [PaqueteTuristicoController::class, 'show']);
Route::get('/paquetes/{id}/imagenes', [PaqueteTuristicoController::class, 'imagenes']);
Route::get('/paquetes/{id}/puntos', [PaqueteTuristicoController::class, 'getByPaquete']);
Route::get('/paquetes/{id}/itinerarios', [PaqueteTuristicoController::class, 'itinerarios']);
Route::get('/paquetes/{id}/incluye', [PaqueteTuristicoController::class, 'incluye']);
Route::get('/paquetes/{id}/noincluye', [PaqueteTuristicoController::class, 'noIncluye']);
Route::put('/paquetes/editar/{id}', [PaqueteTuristicoController::class, 'editar']);
Route::delete('paquetes/eliminar/{id}', [PaqueteTuristicoController::class, 'destroy']);
Route::post('/paquetes/agregar', [PaqueteTuristicoController::class, 'agregar']);
Route::get('/paquetes/paquete/{id}', [PaqueteTuristicoController::class, 'obtenerPaquetePorId']);

// Servicios Incluidos
Route::post('/paquetes/{id}/incluye', [PaqueteTuristicoController::class, 'agregarIncluye']);
Route::put('/incluye/{id}', [PaqueteTuristicoController::class, 'editarIncluye']);
Route::delete('/incluye/{id}', [PaqueteTuristicoController::class, 'eliminarIncluye']);

// Servicios No Incluidos
Route::post('/paquetes/{id}/no-incluye', [PaqueteTuristicoController::class, 'agregarNoIncluye']);
Route::put('/no-incluye/{id}', [PaqueteTuristicoController::class, 'editarNoIncluye']);
Route::delete('/no-incluye/{id}', [PaqueteTuristicoController::class, 'eliminarNoIncluye']);

// Imágenes Galería
Route::put('/galeria/{id}', [PaqueteTuristicoController::class, 'editarImagenGaleria']);

// Puntos del Mapa
Route::post('/paquetes/{id}/mapa', [PaqueteTuristicoController::class, 'agregarPuntoMapa']);
Route::delete('/mapa/{id}', [PaqueteTuristicoController::class, 'eliminarPuntoMapa']);
Route::put('/mapa/{id}', [PaqueteTuristicoController::class, 'editarPuntoMapa']);

// Itinerario
Route::post('/paquetes/{id}/itinerario', [PaqueteTuristicoController::class, 'agregarItinerario']);
Route::delete('/itinerario/{id}', [PaqueteTuristicoController::class, 'eliminarItinerario']);
Route::put('/itinerario/{id}', [PaqueteTuristicoController::class, 'editarItinerario']);

//Blog
Route::get('/blogger', [BlogController::class, 'index']);
Route::delete('/blog/eliminar/{id}', [BlogController::class, 'eliminar']);
Route::get('/entrada/{id}', [BlogController::class, 'show']);
Route::post('/like/toggle', [BlogController::class, 'toggle']);
Route::get('/like/check/{entradaId}', [BlogController::class, 'likedByUser']);
Route::get('/blog/obtener-entradas', [BlogController::class, 'obtenerEntradas']);
Route::get('/like/count/{entradaId}', [BlogController::class, 'count']);
Route::put('/blog/editar/{id}', [BlogController::class, 'editar']);
Route::get('/blog/buscar', [BlogController::class, 'buscar']);
Route::post('/blog/agregar', [BlogController::class, 'agregar']);

// Pago
Route::post('/pago/stripe', [PagoController::class, 'crearPago']);
Route::post('/registro/reserva', [PagoController::class, 'registrarReserva']);
Route::get('/pago/cliente', [PagoController::class, 'obtenerClienteUsuario']);

// Dashboard Usuario
Route::get('/profile', [DashboardUserController::class, 'show']);
Route::put('/profile/update', [DashboardUserController::class, 'update']);
Route::post('/profile/password', [DashboardUserController::class, 'cambioPassword']);
Route::get('/mis-reservas', [DashboardUserController::class, 'listarReservasUsuario']);
Route::get('/facturas/{reservaId}/descargar', [DashboardUserController::class, 'mostrarNombrePorLog']);

// Reservas
Route::get('/reservas/pendientes', [ReservasController::class, 'pendientes']);
Route::put('/reservas/{id}', [ReservasController::class, 'update']);
Route::delete('/reservas/eliminar/{id}', [ReservasController::class, 'destroy']);
Route::get('/reservas/buscar', [ReservasController::class, 'buscar']);
Route::get('/reservas/confirmadas', [ReservasController::class, 'confirmadas']);
Route::get('/reservas/canceladas', [ReservasController::class, 'canceladas']);
Route::get('/participantes/reserva/{id}', [ReservasController::class, 'getPorReserva']);
Route::put('/participantes/{id}', [ReservasController::class, 'updateParticipantes']);
Route::delete('/participantes/{id}', [ReservasController::class, 'destroyParticipantes']);

// Facturas
Route::get('/clientes/obtener-clientes', [FacturasController::class, 'obtenerClientes']);
Route::get('/clientes/buscar', [FacturasController::class, 'buscarClientes']);
Route::delete('/clientes/eliminar/{id}', [FacturasController::class, 'eliminarCliente']);
Route::get('/reservas/cliente/{clienteId}', [FacturasController::class, 'reservasPorCliente']);
Route::get('/factura/{reservaId}/{id}', [FacturasController::class, 'generarFacturaAdmin']);
Route::get('/facturas', [FacturasController::class, 'index']);
Route::get('/facturas/{id}', [FacturasController::class, 'show']);
Route::get('/facturas/buscador', [FacturasController::class, 'buscador']);
Route::delete('/facturas/eliminar/{id}', [FacturasController::class, 'destroy']);
Route::post('/facturas', [FacturasController::class, 'store']);
Route::get('/factura/{id}', [FacturasController::class, 'generarFacturaSimple']);
