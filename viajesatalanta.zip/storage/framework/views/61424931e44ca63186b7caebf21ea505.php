<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <base href="/" />
  <title>Atalanta</title>

  <!-- Fuentes y CSS de terceros -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" />
  <link href="https://cdn.materialdesignicons.com/6.5.95/css/materialdesignicons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Savate:ital,wght@0,200..900;1,200..900&display=swap" rel="stylesheet">
  <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
  <link href="https://cdn.tailwindcss.com" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" />

  <!-- Tus estilos propios -->
  <link rel="stylesheet" href="<?php echo e(asset('resources/js/nicepage.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('css/index3.css')); ?>" />

  <!-- Evitar que Bootstrap modifique el tamaño de las letras del Navbar -->
  <style>
    nav, .navbar, .navbar-brand, .navbar-nav .nav-link {
      font-size: inherit !important;
    }
  </style>

  <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
  <?php echo app('Illuminate\Foundation\Vite')('resources/js/main.jsx'); ?>
</head>

<body>
  <noscript>You need to enable JavaScript to run this app.</noscript>
  <div id="root"></div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <!-- CookieConsent -->
  <script src="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/cookieconsent@3/build/cookieconsent.min.css" />

<script>
window.addEventListener("load", function() {
  window.cookieconsent.initialise({
    palette: {
      popup: { background: "#ffffff", color: "#877c4f" },
      button: { background: "#8a775a", color: "#ffffff" },
      deny: { background: "#d9534f", color: "#ffffff" }
    },
    theme: "classic",
    type: "opt-in",
    content: {
      message: "Utilizamos cookies para ofrecerte la mejor experiencia en nuestra web.",
      allow: "Aceptar cookies",
      deny: "Rechazar",
      link: "Política de cookies",
      href: "/cookies"
    },
    showSettings: true,

    onStatusChange: function(status) {
      // Oculta el banner manualmente al aceptar o rechazar
      const banner = document.querySelector(".cc-window");
      if (banner) {
        banner.style.display = "none";
      }

      if (this.hasConsented()) {
        console.log("Usuario ha aceptado cookies.");
      } else {
        console.log("Usuario ha rechazado cookies.");
      }
    }
  });
});
</script>


  <style>
    .cc-window {
      max-width: 100% !important;
      width: 100% !important;
      left: 0 !important;
      right: 0 !important;
      transform: none !important;
      border-radius: 0 !important;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15) !important;
      padding: 1rem 2rem !important;
      background-color: #ffffff !important;
      color: #877c4f !important;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif !important;
      text-align: center !important;
      position: fixed !important;
      bottom: 0 !important;
      z-index: 9999 !important;
    }

    .cc-message {
      font-size: 1rem !important;
      margin-bottom: 0.75rem !important;
    }

    .cc-link {
      color: #8a775a !important;
      font-weight: 600 !important;
      text-decoration: underline !important;
    }

    .cc-btn {
      font-weight: 600 !important;
      padding: 0.5rem 1.2rem !important;
      margin: 0 0.3rem !important;
      border-radius: 4px !important;
      text-decoration: none !important;
    }

    .cc-btn.cc-allow {
      background-color: #8a775a !important;
      color: #ffffff !important;
    }

    .cc-btn.cc-deny {
      background-color: #8a775a !important;
      color: #ffffff !important;
    }

    .cc-btn.cc-settings {
      background-color: transparent !important;
      color: #877c4f !important;
      border: 1px solid #8a775a !important;
    }
  </style>
</body>

</html>
<?php /**PATH C:\wamp64\www\atalanta\resources\views/welcome.blade.php ENDPATH**/ ?>