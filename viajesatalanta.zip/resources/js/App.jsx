import React from "react";
import './index.css';
import './nicepage.css';
import './index3.css'
import './nicepage3.css';
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
} from "react-router-dom"; // Usamos Routes en lugar de Switch
import Home from "./pages/clientes/Home"; // Asegúrate de ajustar la ruta si es necesario
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import Galeria from "./pages/clientes/Galeria";
import Nosotros from "./pages/clientes/Nosotros";
import Experiencia from "./pages/clientes/Experiencia";
import ExperienciaSola from "./pages/clientes/ExperienciaSola";
import Preguntas from "./pages/clientes/PaginaPreguntas";
import Blog from "./pages/clientes/PaginaBlog";
import EntradaSola from "./pages/clientes/EntradaSola";
import Contacto from "./pages/clientes/PaginaContacto";
import Olvidaste from "./pages/clientes/PaginaOlvidaste";
import Terminos from "./pages/clientes/PaginaTerminos";
import Politica from "./pages/clientes/PaginaPolitica";
import Reserva from "./pages/clientes/PaginaReserva";
import TipoPago from "./pages/clientes/PaginaTipoPago";
import PagoExito from './pages/clientes/PaginaExito';
import Dashboard from './pages/clientes/PaginaDashboard';
import PrivateRoute from "./PrivateRoute";
import DashboardAdmin from "./pages/admin/dashboard/DashboardAdmin";
import AdminTodos from "./pages/admin/administradores/AdminTodos";
import AdminAlta from "./pages/admin/administradores/AdminAlta";
import EventosTodos from "./pages/admin/eventos/EventosTodos";
import CrearEventos from "./pages/admin/eventos/CrearEventos";
import Mensajes from "./pages/admin/mensajes/MensajesTodos";
import MensajeSolo from "./pages/admin/mensajes/MensajeSolo";
import Notificaciones from "./pages/admin/notificaciones/NotificacionesTodas";
import NotificacionSola from "./pages/admin/notificaciones/NotificacionSola";
import GaleriaTodos from "./pages/admin/galeria/GaleriaTodos";
import AgregarImagen from "./pages/admin/galeria/AgregarImagen";
import PaquetesTodos from "./pages/admin/paquetes/PaquetesTodos";
import PaquetesArgegar from "./pages/admin/paquetes/AgregarPaquete";
import PaqueteSolo from "./pages/admin/paquetes/PaqueteSolo";
import BlogTodos from "./pages/admin/blog/BlogTodos";
import EntradasArgegar from "./pages/admin/blog/AgregarEntrada";
import Cookies from "./pages/clientes/PaginaCookies";
import ReservasPendientes from "./pages/admin/reservas/PaginaReservasPendientes";
import ReservasConfirmadas from "./pages/admin/reservas/PaginaReservasConfirmadas";
import ReservasCanceladas from "./pages/admin/reservas/PaginaReservasCanceladas";
import ReservaSolaConfirmada from "./pages/admin/reservas/PaginaLeerConfirmada";
import ReservaSolaPendiente from "./pages/admin/reservas/PaginaLeerPendiente";
import ReservaSolaCancelada from "./pages/admin/reservas/PaginaLeerCancelada";
import FacturasClientes from "./pages/admin/facturas/PaginaFacturasCliente";
import FacturaClienteSolo from "./pages/admin/facturas/PaginaFacturaClienteSolo";
import FacturasAtalanta from "./pages/admin/facturas/PaginaFacturaAtalanta";


const App = () => {
  const token = localStorage.getItem("token"); // Verificar si hay token
  console.log(token);
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />{" "}
        {/* Cambié "component" por "element" */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/galeria" element={<Galeria />} />
        <Route path="/experiencias" element={<Experiencia />} />
        <Route path="/experiencia/:id" element={<ExperienciaSola />} />
        <Route path="/nosotros" element={<Nosotros />} />
        <Route path="/faq" element={<Preguntas />} />
        <Route path="/blogger" element={<Blog />} />
        <Route path="/entrada/:id" element={<EntradaSola/>}/>
        <Route path="/contacto" element={<Contacto />} />
        <Route path="/olvidaste" element={<Olvidaste />} />
        <Route path="/terminos" element={<Terminos />} />
        <Route path="/politica" element={<Politica />} />
        <Route path="/cookies" element={<Cookies />} />
        <Route path="/pago/exito" element={<PagoExito />} />

        <Route
          path="/dashboard-admin"
          element={
            <PrivateRoute>
              <DashboardAdmin />
            </PrivateRoute>
          }
        />
        <Route
          path="/admin-todos"
          element={
            <PrivateRoute>
              <AdminTodos/>
            </PrivateRoute>
          }
        />
        <Route
          path="/admin-alta"
          element={
            <PrivateRoute>
              <AdminAlta/>
            </PrivateRoute>
          }
        />
        <Route
          path="/eventos-todos"
          element={
            <PrivateRoute>
              <EventosTodos/>
            </PrivateRoute>
          }
        />
        <Route
          path="/crear-eventos"
          element={
            <PrivateRoute>
              <CrearEventos/>
            </PrivateRoute>
          }
        />
        <Route
          path="/mensajes"
          element={
            <PrivateRoute>
              <Mensajes/>
            </PrivateRoute>
          }
        />
        <Route
          path="/mensaje/:id"
          element={
            <PrivateRoute>
              <MensajeSolo/>
            </PrivateRoute>
          }
        />
        <Route
          path="/notificaciones"
          element={
            <PrivateRoute>
              <Notificaciones/>
            </PrivateRoute>
          }
        />
        <Route
          path="/notificacion/:id"
          element={
            <PrivateRoute>
              <NotificacionSola/>
            </PrivateRoute>
          }
        />
        <Route
          path="/galeria-listado"
          element={
            <PrivateRoute>
              <GaleriaTodos/>
            </PrivateRoute>
          }
        />
        <Route
          path="/agregar-imagen"
          element={
            <PrivateRoute>
              <AgregarImagen/>
            </PrivateRoute>
          }
        />
        <Route
          path="/paquetes-listado"
          element={
            <PrivateRoute>
              <PaquetesTodos/>
            </PrivateRoute>
          }
        />
        <Route
          path="/paquetes-agregar"
          element={
            <PrivateRoute>
              <PaquetesArgegar/>
            </PrivateRoute>
          }
        />
        <Route
          path="/paquete/:id"
          element={
            <PrivateRoute>
              <PaqueteSolo/>
            </PrivateRoute>
          }
        />
        <Route
          path="/blog-listado"
          element={
            <PrivateRoute>
              <BlogTodos/>
            </PrivateRoute>
          }
        />
        <Route
          path="/blog-agregar"
          element={
            <PrivateRoute>
              <EntradasArgegar/>
            </PrivateRoute>
          }
        />
        <Route
          path="/reservas/:paqueteId"
          element={
            <PrivateRoute>
              <Reserva/>
            </PrivateRoute>
          }
        />
        <Route
          path="/seleccionar-pago/:paqueteId"
          element={
            <PrivateRoute>
              <TipoPago/>
            </PrivateRoute>
          }
        />
        <Route
          path="/profile"
          element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          }
        />
        <Route
          path="/reservas-pendientes"
          element={
            <PrivateRoute>
              <ReservasPendientes />
            </PrivateRoute>
          }
        />
        <Route
          path="/reservas-confirmadas"
          element={
            <PrivateRoute>
              <ReservasConfirmadas />
            </PrivateRoute>
          }
        />
        <Route
          path="/reservas-canceladas"
          element={
            <PrivateRoute>
              <ReservasCanceladas />
            </PrivateRoute>
          }
        />
        <Route
          path="/reserva-confirmada/:id"
          element={
            <PrivateRoute>
              <ReservaSolaConfirmada/>
            </PrivateRoute>
          }
        />
        <Route
          path="/reserva-pendiente/:id"
          element={
            <PrivateRoute>
              <ReservaSolaPendiente/>
            </PrivateRoute>
          }
        />
        <Route
          path="/reserva-cancelada/:id"
          element={
            <PrivateRoute>
              <ReservaSolaCancelada/>
            </PrivateRoute>
          }
        />
        <Route
          path="/facturas-clientes"
          element={
            <PrivateRoute>
              <FacturasClientes />
            </PrivateRoute>
          }
        />
        <Route
          path="/factura-cliente/:id"
          element={
            <PrivateRoute>
              <FacturaClienteSolo/>
            </PrivateRoute>
          }
        />
        <Route
          path="/facturas-atalanta"
          element={
            <PrivateRoute>
              <FacturasAtalanta />
            </PrivateRoute>
          }
        />
      </Routes>
    </Router>
  );
};

export default App;


