import React from "react";
import { Link, useLocation } from "react-router-dom";

const Cookies = () => {
    const { pathname } = useLocation();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);
    return (
        <div
            className="min-vh-100 d-flex justify-content-center align-items-start"
            style={{
                backgroundColor: "#877c4f",
                paddingTop: "20px",
                paddingBottom: "40px",
                color: "#343a40",
                fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
            }}
        >
            <div
                className="col-12 col-md-10 col-lg-8 rounded shadow p-4 p-md-5"
                style={{
                    maxHeight: "90vh",
                    overflowY: "auto",
                    boxShadow: "0 8px 30px rgba(0,0,0,0.15)",
                    backgroundColor: "#fcf4ef",
                    color: "#877c4f",
                }}
            >
                <h2
                    className="text-center mb-5 p-nosotros"
                    style={{ color: "#35372e", fontWeight: "700" }}
                >
                    Política de Cookies
                </h2>

                {[
                    {
                        title: "1. Información que recopilamos",
                        content:
                            "Recopilamos datos personales que tú nos proporcionas directamente al registrarte, hacer una reserva o comunicarte con nosotros, incluyendo nombre, correo electrónico, dirección y detalles de pago.",
                    },
                    {
                        title: "2. Uso de la información",
                        content:
                            "Utilizamos tu información para procesar reservas, mejorar nuestros servicios, enviarte comunicaciones relevantes y cumplir con obligaciones legales.",
                    },
                    {
                        title: "3. Compartición de datos",
                        content:
                            "No vendemos ni alquilamos tu información personal. Podemos compartir datos con proveedores de servicios que nos ayudan a operar la plataforma, siempre bajo estrictas condiciones de confidencialidad.",
                    },
                    {
                        title: "4. Seguridad de los datos",
                        content:
                            "Implementamos medidas técnicas y organizativas para proteger tus datos contra accesos no autorizados, pérdida o alteración.",
                    },
                    {
                        title: "5. Tus derechos",
                        listItems: [
                            "Acceder a tus datos personales.",
                            "Solicitar la rectificación o eliminación de tus datos.",
                            "Oponerte al tratamiento o solicitar su limitación.",
                            "Solicitar la portabilidad de tus datos.",
                            "Retirar tu consentimiento en cualquier momento.",
                        ],
                    },
                    {
                        title: "6. Retención de datos",
                        content:
                            "Conservamos tus datos únicamente durante el tiempo necesario para cumplir con los fines para los que fueron recogidos o por exigencias legales.",
                    },
                    {
                        title: "7. Cookies y tecnologías similares",
                        content:
                            "Utilizamos cookies para mejorar la experiencia del usuario, analizar el tráfico y personalizar contenido. Puedes configurar tu navegador para bloquearlas o alertarte de su uso.",
                    },
                    {
                        title: "8. Menores de edad",
                        content:
                            "Nuestra plataforma no está destinada a menores de 18 años y no recopilamos conscientemente datos de menores.",
                    },
                    {
                        title: "9. Cambios en la política",
                        content:
                            "Podemos actualizar esta Política de Cookies en cualquier momento. Publicaremos los cambios en esta página para que estés informado.",
                    },
                    {
                        title: "10. Contacto",
                        content: (
                            <>
                                Para consultas o ejercer tus derechos,
                                escríbenos a:{" "}
                                <a
                                    href="mailto:soporte@viajesatalanta.com"
                                    style={{
                                        color: "#2575fc",
                                        fontWeight: "600",
                                    }}
                                >
                                    soporte@viajesatalanta.com
                                </a>
                                .
                            </>
                        ),
                    },
                ].map(({ title, content, listItems }, i) => (
                    <section
                        key={i}
                        className="mb-4 p-nosotros"
                        style={{ lineHeight: "1.6" }}
                    >
                        <h5
                            style={{
                                color: "#35372e",
                                fontWeight: "600",
                                marginBottom: "0.8rem",
                            }}
                        >
                            {title}
                        </h5>
                        {listItems ? (
                            <ul style={{ paddingLeft: "1.2rem" }}>
                                {listItems.map((item, idx) => (
                                    <li
                                        key={idx}
                                        style={{ marginBottom: "0.3rem" }}
                                    >
                                        {item}
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p style={{ fontSize: "1.05rem" }}>{content}</p>
                        )}
                    </section>
                ))}

                <div className="text-center mt-5">
                    <Link
                        to="/"
                        className="btn px-4 py-2 p-nosotros"
                        style={{
                            fontWeight: "600",
                            fontSize: "1rem",
                            backgroundColor: "#c16e44",
                            color: "#fcf4ef",
                        }}
                    >
                        Volver al inicio
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default Cookies;
