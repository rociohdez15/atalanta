import { useEffect } from "react";
import { Link, useLocation } from "react-router-dom";

const Terminos = () => {
    const { pathname } = useLocation();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);
    return (
        <div
            className="min-vh-100 d-flex justify-content-center align-items-start"
            style={{
                backgroundColor: "#ffffff",
                paddingTop: "3rem",
                paddingBottom: "4rem",
                fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
            }}
        >
            <div
                className="col-12 col-md-10 col-lg-8 p-4 p-md-5 rounded-4 shadow-lg"
                style={{
                    backgroundColor: " #8a775a",
                    color: "#ffffff",
                    maxHeight: "90vh",
                    overflowY: "auto",
                    backdropFilter: "blur(6px)",
                    border: "none",
                }}
            >
                <div className="text-center mb-5">
                    <div
                        className="rounded-circle d-inline-flex align-items-center justify-content-center mb-4"
                        style={{
                            background:
                                "linear-gradient(to right, #8a775a, #ffffff)",
                            borderRadius: "50%",
                            width: "80px",
                            height: "80px",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                        }}
                    >
                        <i
                            className="bi bi-shield-fill"
                            style={{ fontSize: "40px", color: "#ffffff" }}
                        ></i>
                    </div>
                    <h2 style={{ fontWeight: "700", color: "#ffffff", fontSize:"40px" }}>
                        Términos y Condiciones de Uso
                    </h2>
                    <p style={{ color: "#ffffff", fontSize:"18px"}}>
                        Última actualización: 1 de septiembre de 2025
                    </p>
                </div>

                <p
                    style={{
                        lineHeight: "1.7",
                        color: "#ffffff",
                        fontSize:"16px"
                    }}
                >
                    Estos Términos y Condiciones regulan el acceso y uso de la
                    plataforma Atalanta, así como los servicios y
                    funcionalidades disponibles para los usuarios. Al utilizar
                    nuestros servicios, aceptas cumplir con todas las
                    disposiciones que se describen a continuación.
                </p>

                {/* Secciones mapeadas */}
                {[
                    {
                        title: "1. Aceptación de los términos",
                        content:
                            "Al acceder y utilizar Atalanta, el usuario declara que ha leído, entendido y aceptado estos Términos y Condiciones en su totalidad. Si no estás de acuerdo con alguna parte de los mismos, te pedimos no utilizar nuestros servicios.",
                    },
                    {
                        title: "2. Registro del usuario",
                        content:
                            "Para utilizar ciertas funcionalidades de la plataforma, deberás crear una cuenta proporcionando información veraz, completa y actualizada. Eres responsable de mantener la confidencialidad de tus credenciales y de todas las actividades que ocurran bajo tu cuenta.",
                    },
                    {
                        title: "3. Servicios ofrecidos",
                        content:
                            "Atalanta proporciona una plataforma de reservas de paquetes turísticos, permitiendo a los usuarios explorar, comparar y contratar experiencias personalizadas. Los servicios están sujetos a disponibilidad y pueden cambiar sin previo aviso.",
                    },
                    {
                        title: "4. Reservas y pagos",
                        content:
                            "Los pagos se procesan mediante métodos seguros habilitados en la plataforma. Al realizar una reserva, el usuario acepta las condiciones específicas del paquete, incluyendo precios, fechas, políticas de cancelación y servicios incluidos.",
                    },
                    {
                        title: "5. Políticas de cancelación",
                        content:
                            "Cada paquete cuenta con políticas de cancelación y reembolso propias. Estas se encuentran claramente detalladas en la descripción del paquete. Atalanta no se responsabiliza por reembolsos fuera de las condiciones establecidas.",
                    },
                    {
                        title: "6. Privacidad y protección de datos",
                        content: (
                            <>
                                Atalanta respeta tu privacidad. Toda la
                                información personal proporcionada será tratada
                                conforme a nuestra{" "}
                                <Link
                                    to="/politica"
                                    style={{
                                        color: "#2575fc",
                                        fontWeight: "600",
                                    }}
                                >
                                    Política de Privacidad
                                </Link>
                                . No compartiremos ni venderemos tus datos a
                                terceros sin tu consentimiento.
                            </>
                        ),
                    },
                    {
                        title: "7. Obligaciones del usuario",
                        listItems: [
                            "No utilizar la plataforma para fines ilegales o no autorizados.",
                            "No interferir con el funcionamiento del sitio o de otros usuarios.",
                            "No publicar contenido falso, ofensivo o que viole derechos de terceros.",
                        ],
                    },
                    {
                        title: "8. Propiedad intelectual",
                        content:
                            "Todos los derechos sobre el contenido, diseño, imágenes, marcas y software de Atalanta pertenecen a la empresa o a sus licenciantes. Está prohibido copiar, reproducir o distribuir cualquier contenido sin autorización expresa.",
                    },
                    {
                        title: "9. Limitación de responsabilidad",
                        content:
                            "Atalanta no será responsable por daños directos o indirectos derivados del uso o la imposibilidad de uso de la plataforma, incluyendo pérdida de datos, interrupciones del servicio o fallos en las reservas causados por terceros.",
                    },
                    {
                        title: "10. Modificaciones a los términos",
                        content:
                            "Nos reservamos el derecho de modificar estos Términos y Condiciones en cualquier momento. Las actualizaciones se publicarán en esta página. Es responsabilidad del usuario revisar periódicamente para mantenerse informado.",
                    },
                    {
                        title: "11. Suspensión o terminación",
                        content:
                            "Atalanta podrá suspender o cancelar el acceso de un usuario si considera que ha violado estos términos o ha realizado actividades fraudulentas, ilegales o dañinas para otros usuarios o la plataforma.",
                    },
                    {
                        title: "12. Legislación aplicable",
                        content:
                            "Estos Términos se rigen por las leyes de España. Cualquier conflicto que surja será resuelto por los tribunales competentes del domicilio social de Atalanta, salvo disposición legal en contrario.",
                    },
                    {
                        title: "13. Contacto",
                        content: (
                            <>
                                Para cualquier consulta sobre estos Términos y
                                Condiciones, puedes escribirnos a:{" "}
                                <a
                                    href="mailto:soporte@viajesatalanta.com"
                                    style={{
                                        color: "#2575fc",
                                        fontWeight: "600",
                                    }}
                                >
                                    soporte@viajesatalanta.com
                                </a>
                                .
                            </>
                        ),
                    },
                ].map(({ title, content, listItems }, i) => (
                    <section
                        key={i}
                        className="mb-4"
                        style={{ lineHeight: "1.6", color: "#ffffff" }}
                    >
                        <h5
                            style={{
                                fontWeight: "600",
                                marginBottom: "0.8rem",
                                color: "#ffffff",
                                fontSize:"18px"
                            }}
                        >
                            {title}
                        </h5>
                        {listItems ? (
                            <ul className="ms-3">
                                {listItems.map((item, idx) => (
                                    <li
                                        key={idx}
                                        style={{ marginBottom: "0.4rem", fontSize:"18px" }}
                                    >
                                        {item}
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p
                                style={{
                                    color: "#ffffff",
                                    fontSize:"16px"
                                }}
                            >
                                {content}
                            </p>
                        )}
                    </section>
                ))}

                <div className="text-center mt-5">
                    <Link
                        to="/login"
                        className="btn px-4 py-2 rounded-top-2"
                        style={{
                            backgroundColor: "rgba(255, 255, 255, 0.8)", // fondo translúcido
                            backdropFilter: "blur(12px)",
                            WebkitBackdropFilter: "blur(12px)",
                            color: "#8a775a", // texto marrón
                            border: "1px solid rgba(255,255,255,0.5)", // borde sutil
                            fontWeight: "600",
                            fontSize: "12px",
                            minWidth: "110px",
                            textAlign: "center",
                            transition: "all 0.3s ease",
                            fontFamily: "Inter, sans-serif",
                        }}
                        onMouseEnter={(e) => {
                            e.currentTarget.style.backgroundColor =
                                "rgba(255, 255, 255, 0.2)";
                            e.currentTarget.style.color = "#ffffff";
                        }}
                        onMouseLeave={(e) => {
                            e.currentTarget.style.backgroundColor =
                                "rgba(255, 255, 255, 0.8)";
                            e.currentTarget.style.color = "#8a775a";
                        }}
                    >
                        Entendido, volver al login
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default Terminos;
