import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import {
    ArrowLeft,
    Users,
    Award,
    Globe,
    Heart,
    Star,
    Clock,
    ChevronRight,
    ChevronLeft,
} from "lucide-react";
import { motion } from "framer-motion";

const Entrada = () => {
    const [entrada, setEntrada] = useState(null);
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [isLiked, setIsLiked] = useState(false);

    const { pathname } = useLocation();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);

    const navigate = useNavigate();
    const { id } = useParams(); // <-- capturamos el id de la URL

    useEffect(() => {
        const token =
            sessionStorage.getItem("token") || localStorage.getItem("token");
        setIsLoggedIn(!!token);
    }, []);

    // Obtener la entrada concreta
    useEffect(() => {
        axios.get(`/api/entrada/${id}`).then((res) => {
            setEntrada(res.data);
        });
    }, [id]);

    // Comprobar si el usuario ha dado like
    useEffect(() => {
        const token =
            sessionStorage.getItem("token") || localStorage.getItem("token");
        if (!token || !entrada) return;

        axios
            .get(`/api/like/check/${entrada.id}`, {
                headers: { Authorization: `Bearer ${token}` },
            })
            .then((res) => {
                setIsLiked(res.data.liked);
            });
    }, [entrada]);

    const handleLikeClick = async () => {
        const token =
            sessionStorage.getItem("token") || localStorage.getItem("token");
        if (!token) {
            navigate("/login");
            return;
        }

        try {
            await axios.post(
                "/api/like/toggle",
                { entrada_id: entrada.id },
                { headers: { Authorization: `Bearer ${token}` } }
            );

            const res = await axios.get(`/api/like/count/${entrada.id}`);
            setEntrada((prev) => ({ ...prev, likes_count: res.data.likes }));

            setIsLiked((prev) => !prev);
        } catch (err) {
            console.error(" ");
        }
    };

    if (!entrada) {
        return <div className="container py-5">Cargando entrada...</div>;
    }

    return (
        <div className="container py-5 pt-0">
            <div className="row justify-content-center">
                <div className="col-lg-8">
                    <div
                        className="mb-4"
                        style={{ opacity: 1, transform: "translateX(0)" }}
                    >
                        <button
                            type="button"
                            onClick={() => (window.location.href = "/")}
                            className="btn btn-link d-flex align-items-center mb-4"
                            style={{
                                transition:
                                    "color 0.3s ease, background-color 0.3s ease",
                                textDecoration: "none", // quita el subrayado
                                boxShadow: "none", // quita cualquier sombra por defecto
                                color: " #8a775a",
                                fontFamily: "Inter, sans-serif",
                                fontSize: "10pt",
                            }}
                            onMouseEnter={(e) => {
                                e.currentTarget.style.color = " #8a775a";
                                e.currentTarget.style.backgroundColor =
                                    "rgba(53, 55, 46, 0.1)";
                                e.currentTarget.style.textDecoration = "none";
                                e.currentTarget.style.boxShadow = "none";
                            }}
                            onMouseLeave={(e) => {
                                e.currentTarget.style.color = " #8a775a";
                                e.currentTarget.style.backgroundColor =
                                    "transparent";
                                e.currentTarget.style.textDecoration = "none";
                                e.currentTarget.style.boxShadow = "none";
                            }}
                        >
                            <ArrowLeft size={20} className="me-2" />
                            Volver al inicio
                        </button>
                    </div>
                    <br />
                    <motion.div
                        initial={{ y: 50, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ duration: 0.8 }}
                        className="rounded-4 shadow-lg overflow-hidden mb-5"
                        style={{ backgroundColor: "#8a775a" }}
                    >
                        {/* Imagen de cabecera con gradiente y metadatos */}
                        <div
                            className="position-relative"
                            style={{ height: "24rem", overflow: "hidden" }}
                        >
                            <img
                                src={`/storage/blog/${entrada.id}/${entrada.imagen_destacada}`}
                                alt={entrada.titulo}
                                className="w-100 h-100 object-fit-cover"
                            />
                            <div
                                className="position-absolute top-0 start-0 w-100 h-100"
                                style={{
                                    background:
                                        "linear-gradient(to top, rgba(0, 0, 0, 0.5), transparent)",
                                }}
                            ></div>
                            <div className="position-absolute bottom-0 start-0 p-4 text-white">
                                <h1
                                    className="fw-bold p-nosotros fs-1"
                                    style={{ color: "#ffffff" }}
                                >
                                    {entrada.titulo}
                                </h1>
                            </div>
                        </div>

                        {/* Contenido */}
                        <div className="p-4">
                            <div
                                className="mb-4"
                                style={{
                                    color: "#ffffff",
                                    lineHeight: "1.7",
                                    fontSize: "1.1rem",
                                }}
                            >
                                {entrada.contenido}
                            </div>

                            {/* Likes y compartir */}
                            <div className="pt-3 d-flex flex-wrap align-items-center justify-content-between gap-2 custom-border-top">
                                <button
                                    onClick={handleLikeClick}
                                    className={`d-flex align-items-center gap-2 px-3 py-2 rounded-pill border-0 transition`}
                                    style={{
                                        backgroundColor: "#ffffff",
                                        color: isLiked ? "#8a775a" : "#000000", // 👈 controlas el color aquí
                                    }}
                                    aria-label={
                                        isLiked ? "Quitar like" : "Dar like"
                                    }
                                >
                                    <i
                                        className={`bi bi-heart${
                                            isLiked ? "-fill" : ""
                                        }`}
                                        style={{ color: "#8a775a", fontFamily: "Inter, sans-serif",
                                fontSize: "14px", }}
                                    ></i>
                                    <span style={{ fontFamily: "Inter, sans-serif",
                                fontSize: "14px", }}>
                                        {entrada.likes_count || 0} Me gusta
                                    </span>
                                </button>

                                <div
                                    className="small"
                                    style={{
                                        color: "#ffffff",
                                        marginTop: "0.5rem",
                                        minWidth: "100px",
                                        textAlign: "right",
                                        fontFamily: "Inter, sans-serif",
                                        fontSize: "12px"
                                    }}
                                >
                                    ¿Te gustó este artículo? ¡Compártelo!
                                </div>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </div>
        </div>
    );
};

export default Entrada;
