import { useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { FaInstagram, FaWhatsapp, FaFacebookF } from "react-icons/fa";

const Footer = () => {
    const { pathname } = useLocation();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);
    return (
        <footer
            className="py-4"
            style={{
                backgroundColor: " #8a775a",
                borderTop: "1px solid #ffffff",
                fontSize: "10px", // letra más pequeña
            }}
        >
            <div className="container">
                <div className="row justify-content-between align-items-center">
                    {/* Columna izquierda: Redes y FAQ */}
                    <div className="col-md-6 mb-3 text-md-start text-center">
                        <h6
                            className="p-nosotros"
                            style={{
                                fontWeight: "bold",
                                marginBottom: "8px",
                                marginLeft: "10px",
                                fontFamily: "Inter, sans-serif",
                                fontSize: "15px",
                                color: " #ffffff",
                            }}
                        >
                            Síguenos
                        </h6>
                        <div className="mb-2">
                            <a
                                href="https://www.instagram.com"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="mx-2"
                                style={{
                                    fontFamily: "Inter, sans-serif",
                                    fontSize: "15px",
                                    color: " #ffffff",
                                }}
                            >
                                <FaInstagram size={20} />
                            </a>
                            <a
                                href="https://wa.me/34123456789"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="mx-2"
                                style={{
                                    fontFamily: "Inter, sans-serif",
                                    fontSize: "15px",
                                    color: " #ffffff",
                                }}
                            >
                                <FaWhatsapp size={20} />
                            </a>
                            <a
                                href="https://www.facebook.com"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="mx-2"
                                style={{
                                    fontFamily: "Inter, sans-serif",
                                    fontSize: "15px",
                                    color: " #ffffff",
                                }}
                            >
                                <FaFacebookF size={20} />
                            </a>
                        </div>
                        <div>
                            <Link
                                to="/faq"
                                className="mx-2 text-decoration-none p-nosotros"
                                style={{
                                    fontFamily: "Inter, sans-serif",
                                    fontSize: "15px",
                                    color: " #ffffff",
                                }}
                            >
                                Preguntas Frecuentes
                            </Link>
                        </div>
                    </div>

                    {/* Columna derecha: Datos empresa */}
                    <div className="col-md-6 mb-3 text-md-end text-center">
                        <h6
                            className="p-nosotros"
                            style={{
                                fontWeight: "bold",
                                marginBottom: "10px",
                                fontFamily: "Inter, sans-serif",
                                fontSize: "15px",
                                color: " #ffffff",
                            }}
                        >
                            Atalanta S.L.
                        </h6>
                        <p
                            className="p-nosotros"
                            style={{
                                margin: 0,
                                fontFamily: "Inter, sans-serif",
                                fontSize: "15px",
                                color: " #ffffff",
                            }}
                        >
                            Calle Ejemplo 123, Madrid, España
                        </p>
                        <p
                            className="p-nosotros"
                            style={{
                                margin: 0,
                                fontFamily: "Inter, sans-serif",
                                fontSize: "15px",
                                color: " #ffffff",
                            }}
                        >
                            Tel: +34 912 345 678 | Email:
                            info@viajesatalanta.com
                        </p>
                        <p
                            className="p-nosotros"
                            style={{
                                margin: 0,
                                fontFamily: "Inter, sans-serif",
                                fontSize: "15px",
                                color: " #ffffff",
                            }}
                        >
                            NIF: B12345678
                        </p>
                    </div>
                </div>

                <div className="row">
                    <div className="col-12 text-center">
                        <Link
                            to="/politica"
                            className="mx-2 text-decoration-none p-nosotros "
                            style={{
                                fontFamily: "Inter, sans-serif",
                                fontSize: "15px",
                                color: " #ffffff",
                            }}
                        >
                            Política de Privacidad
                        </Link>
                        <Link
                            to="/terminos"
                            className="mx-2 text-decoration-none p-nosotros"
                            style={{
                                fontFamily: "Inter, sans-serif",
                                fontSize: "15px",
                                color: " #ffffff",
                            }}
                        >
                            Términos y Condiciones
                        </Link>
                        <Link
                            to="/contacto"
                            className="mx-2 text-decoration-none p-nosotros"
                            style={{
                                fontFamily: "Inter, sans-serif",
                                fontSize: "15px",
                                color: " #ffffff",
                            }}
                        >
                            Contacto
                        </Link>
                    </div>
                </div>

                <div className="row">
                    <div className="col-12 text-center">
                        <p
                            className="small mb-0 p-nosotros"
                            style={{
                                fontFamily: "Inter, sans-serif",
                                fontSize: "15px",
                                color: " #ffffff",
                            }}
                        >
                            &copy; {new Date().getFullYear()} Atalanta S.L. -
                            Todos los derechos reservados
                        </p>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
