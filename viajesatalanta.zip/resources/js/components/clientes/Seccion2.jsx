import React, { useEffect, useRef } from "react";
import { Link, useLocation } from "react-router-dom";

const Seccion2 = () => {
    const sectionRef = useRef(null);

    const { pathname } = useLocation();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);

    const runAnimation = () => {
        // Reset estilos antes de animar para poder repetir la animación
        $("#sec-d117 .image-container").css({
            opacity: 0,
            position: "relative",
            left: "-50px",
        });

        $("#sec-d117 .text-container").css({
            opacity: 0,
            position: "relative",
            right: "-50px",
        });

        // Animar imagen primero (fade + slide)
        $("#sec-d117 .image-container").animate(
            {
                opacity: 1,
                left: 0,
            },
            700,
            "swing",
            () => {
                // Luego animar texto con pequeño delay
                $("#sec-d117 .text-container").delay(200).animate(
                    {
                        opacity: 1,
                        right: 0,
                    },
                    700,
                    "swing"
                );
            }
        );
    };

    useEffect(() => {
        // Ejecutar animación al cargar la página
        runAnimation();

        // Crear observer para detectar entrada en viewport
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        runAnimation();
                    }
                });
            },
            {
                threshold: 0.5, // Cuando al menos el 50% de la sección esté visible
            }
        );

        if (sectionRef.current) {
            observer.observe(sectionRef.current);
        }

        return () => {
            if (sectionRef.current) {
                observer.unobserve(sectionRef.current);
            }
        };
    }, []);

    return (
        <section
            ref={sectionRef}
            className="u-clearfix u-container-align-center u-section-2"
            id="sec-d117"
            style={{ backgroundColor: "#8a775a", color: "white" }}
        >
            <div className="container py-5">
                <div className="row align-items-center justify-content-center">
                    {/* Texto (izquierda en escritorio) */}
                    <div className="col-12 col-md-6 text-center text-md-start text-container">
                        <h2
                            className="fs-2 fs-md-1 fw-bold mb-4"
                            style={{ color: "#ffffff" , fontFamily: "Inter, sans-serif",}}
                        >
                            Sobre Nosotros
                        </h2>

                        <p
                            className="mb-3"
                            style={{
                                color: "#ffffff",
                                lineHeight: "1.7",
                                fontFamily: "Inter, sans-serif",
                                fontSize: "14pt" , 
                            }}
                        >
                            En Atalanta creamos aventuras más allá de lo
                            convencional. Nuestras propuestas tienen una
                            conexión directa con el lugar y con su gente.
                            Valoramos la dedicación al 100% y hacemos que cada
                            detalle cuente. Por eso el objetivo no es solo
                            llevarte a nuevos destinos, sino que tu viaje se
                            convierta en una experiencia enriquecedora antes,
                            durante y después de realizarlo. ¿TE ATREVES A
                            VIVIRLO?
                        </p>

                        <Link
                            to="/nosotros"
                            className="btn btn-primary rounded-3"
                            style={{
                                backgroundColor: "#ffffff",
                                color: "#8a775a",
                                borderColor: "#ffffff",
                                fontSize: "12px" , 
                                fontFamily: "Inter, sans-serif",
                            }}
                        >
                            Saber Más
                        </Link>
                    </div>

                    {/* Imagen (derecha en escritorio) */}
                    <div className="col-12 col-md-6 order-md-last mt-4 mt-md-0 image-container">
                        <div className="position-relative">
                            <div className="rounded-4 overflow-hidden shadow-lg">
                                <img
                                    src="images/prueba.jpg"
                                    alt="Equipo de turismo profesional"
                                    className="img-fluid"
                                    style={{
                                        height: "500px",
                                        objectFit: "cover",
                                        width: "100%",
                                    }}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Seccion2;
