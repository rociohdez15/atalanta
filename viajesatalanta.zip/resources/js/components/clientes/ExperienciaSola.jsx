import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams, Link, useLocation } from "react-router-dom";
import MapaPuntos from "./mapas/MapaPuntos";
import ServiciosIncluidos from "./servicios/Servicios";
import { motion } from "framer-motion";
import { BsCheck, BsX } from "react-icons/bs";
import {
    ArrowLeft,
    Calendar,
    ChevronLeft,
    ChevronRight,
    CreditCard,
    HelpCircle,
    Clock,
    MapPin,
} from "lucide-react";

const ExperienciaSola = () => {
    const { id } = useParams();
    const [paquete, setPaquete] = useState(null);
    const [puntosMapa, setPuntosMapa] = useState([]);
    const [itinerarios, setItinerarios] = useState([]);
    const [imagenes, setImagenes] = useState([]);
    const [error, setError] = useState(null);
    const [selectedImageIndex, setSelectedImageIndex] = useState(0);
    const location = useLocation();

    const { pathname } = useLocation();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);

    const baseUrl = `/storage/paquetes/${id}/images/`;

    const estiloFondo = paquete
        ? {
              backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url(/storage/paquetes/portada/${id}/${paquete.foto})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
              backgroundRepeat: "no-repeat",
          }
        : {};

    useEffect(() => {
        axios
            .get(`/api/paquetes/${id}`)
            .then((res) => setPaquete(res.data))
            .catch(() => setError("No se pudo cargar el paquete"));

        axios
            .get(`/api/paquetes/${id}/imagenes`)
            .then((res) => setImagenes(res.data))
            .catch(() => setError("No se pudieron cargar las imágenes"));

        axios
            .get(`/api/paquetes/${id}/puntos`)
            .then((res) => setPuntosMapa(res.data))
            .catch(() => setError("No se pudieron cargar los puntos del mapa"));

        axios
            .get(`/api/paquetes/${id}/itinerarios`)
            .then((res) => setItinerarios(res.data))
            .catch(() => setError("No se pudieron cargar los itinerarios"));
    }, [id]);

    useEffect(() => {
        $(".dia")
            .off("click")
            .on("click", function () {
                const target = $(this).data("target");
                $(target).slideToggle();
            });

        return () => {
            $(".dia").off("click");
        };
    }, [puntosMapa]);

    const isLoggedIn = !!(
        localStorage.getItem("token") || sessionStorage.getItem("token")
    );

    return (
        <>
            <style
                dangerouslySetInnerHTML={{
                    __html: `
      body {
        font-family: 'Merriweather', serif;
        margin: 0;
      }

      .bg-cover {
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        filter: brightness(75%);
      }

      .hero-container {
        background-color: transparent !important; /* Asegura que el hero no reciba el fondo */
      }
    `,
                }}
            />

            {/* Hero section debajo del navbar */}
            <section className="w-100 m-0 p-0">
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.8 }}
                    className="position-relative overflow-hidden"
                    style={{
                        paddingTop: "5rem",
                        paddingBottom: "5rem",
                        background:
                            "linear-gradient(to right, #8a775a, #877c4f)",
                    }}
                >
                    {/* Imagen de fondo */}
                    <div className="position-absolute top-0 start-0 w-100 h-100">
                        <img
                            src={
                                paquete
                                    ? `/storage/paquetes/portada/${id}/${paquete.foto}`
                                    : "https://via.placeholder.com/1920x1080" // fallback
                            }
                            alt={paquete ? paquete.nombre : "Imagen de paquete"}
                            className="w-100 h-100"
                            style={{ objectFit: "cover" }}
                        />
                        {/* Overlay oscuro translúcido */}
                        <div
                            className="position-absolute top-0 start-0 w-100 h-100"
                            style={{
                                backgroundColor: "rgba(0, 0, 0, 0.4)", // negro translúcido
                            }}
                        ></div>
                    </div>

                    {/* Contenido */}
                    <section className="position-relative px-3 px-sm-4 px-lg-5">
                        <div
                            className="container position-relative"
                            style={{ zIndex: 2, maxWidth: "1200px" }}
                        >
                            {/* Botón volver */}
                            <button
                                type="button"
                                onClick={() =>
                                    (window.location.href = "/experiencias")
                                }
                                className="btn btn-link d-flex align-items-center mb-4"
                                style={{
                                    transition:
                                        "color 0.3s ease, background-color 0.3s ease",
                                    textDecoration: "none",
                                    boxShadow: "none",
                                    color: "#ffffff",
                                    fontFamily: "Inter, sans-serif",
                                    fontSize: "10pt",
                                    marginTop:"-25px",
                                    marginLeft: "-60px"
                                }}
                                onMouseEnter={(e) => {
                                    e.currentTarget.style.color = "#ffffff";
                                    e.currentTarget.style.backgroundColor =
                                        "rgba(53, 55, 46, 0.1)";
                                    e.currentTarget.style.textDecoration =
                                        "none";
                                    e.currentTarget.style.boxShadow = "none";
                                }}
                                onMouseLeave={(e) => {
                                    e.currentTarget.style.color = "#ffffff";
                                    e.currentTarget.style.backgroundColor =
                                        "transparent";
                                    e.currentTarget.style.textDecoration =
                                        "none";
                                    e.currentTarget.style.boxShadow = "none";
                                }}
                            >
                                <ArrowLeft size={20} className="me-2" />
                                Volver a Experiencias
                            </button>

                            <motion.div
                                initial={{ y: 20, opacity: 0 }}
                                animate={{ y: 0, opacity: 1 }}
                                transition={{ duration: 0.8, delay: 0.2 }}
                                className="row align-items-center g-3"
                            >
                                {/* Información principal */}
                                <div className="col-lg-8">
                                    <span
                                        className="badge mb-2"
                                        style={{
                                            backgroundColor: "#ffffff",
                                            color: "#8a775a",
                                            fontFamily: "'Inter', sans-serif", // aquí pones tu fuente
                                            fontSize: "0.7rem",
                                        }}
                                    >
                                        {paquete
                                            ? paquete.tipo_viaje
                                            : "Cargando..."}
                                    </span>
                                    <br />
                                    <h1
                                        className="fw-bold mb-3"
                                        style={{
                                            color: "#ffffff",
                                            fontFamily:
                                                '"TT Espina Trial Variable", sans-serif',
                                            fontSize: "2rem", // mantiene el mismo tamaño
                                            transform: "scaleX(1.5)", // estira horizontalmente
                                            display: "inline-block", // necesario para que transform funcione bien
                                            transformOrigin: "left center",
                                        }}
                                    >
                                        {paquete
                                            ? paquete.nombre
                                            : "Cargando..."}
                                    </h1>

                                    <div
                                        className="d-flex flex-wrap align-items-center gap-2 mb-3"
                                        style={{
                                            color: "#ffffff",
                                            fontSize: "0.9rem",
                                        }}
                                    >
                                        <div className="d-flex align-items-center">
                                            <MapPin
                                                size={16}
                                                className="me-1"
                                            />
                                            <span
                                                style={{
                                                    fontFamily:
                                                        "'Inter', sans-serif", // aquí pones tu fuente
                                                    fontSize: "1rem",
                                                }}
                                            >
                                                {paquete
                                                    ? paquete.lugar
                                                    : "Cargando..."}
                                            </span>
                                        </div>
                                        <div className="d-flex align-items-center">
                                            <Calendar
                                                size={16}
                                                className="me-1"
                                            />
                                            <span
                                                style={{
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                    fontSize: "1rem",
                                                }}
                                            >
                                                {(() => {
                                                    if (
                                                        !paquete?.fecha_inicio ||
                                                        !paquete?.fecha_fin
                                                    )
                                                        return "Cargando...";

                                                    const inicio = new Date(
                                                        paquete.fecha_inicio
                                                    );
                                                    const fin = new Date(
                                                        paquete.fecha_fin
                                                    );

                                                    const diaInicio =
                                                        inicio.getDate();
                                                    const diaFin =
                                                        fin.getDate();
                                                    const mes =
                                                        fin.toLocaleDateString(
                                                            "es-ES",
                                                            { month: "long" }
                                                        );
                                                    const año =
                                                        fin.getFullYear();

                                                    return `${diaInicio} al ${diaFin} de ${mes} de ${año}`;
                                                })()}
                                            </span>
                                        </div>
                                    </div>

                                    <p
                                        style={{
                                            color: "#ffffff",
                                            maxWidth: "600px",
                                            fontFamily: "'Inter', sans-serif", // aquí pones tu fuente
                                            fontSize: "1rem",
                                        }}
                                    >
                                        {paquete
                                            ? paquete.descripcion
                                            : "Cargando..."}
                                    </p>
                                </div>

                                {/* Precio y acciones */}
                                <div className="col-lg-4">
                                    <div
                                        className="card border-0 shadow-sm"
                                        style={{
                                            backgroundColor: "#ffffff",
                                            backdropFilter: "blur(4px)",
                                            border: "1px solid rgba(233,218,182,0.3)",
                                            borderRadius: "1rem",
                                        }}
                                    >
                                        <br />
                                        <div className="card-header bg-transparent text-center border-0 pb-2">
                                            <div className="d-flex align-items-center justify-content-center gap-2">
                                                <span
                                                    style={{
                                                        fontSize: "1.5rem",
                                                        fontWeight: "bold",
                                                        color: "#8a775a",
                                                        fontFamily:
                                                            "'Inter', sans-serif",
                                                    }}
                                                >
                                                    {paquete
                                                        ? paquete.precio
                                                        : "Cargando..."}
                                                    €
                                                </span>
                                            </div>
                                            <p
                                                style={{
                                                    color: "#8a775a",
                                                    fontSize: "0.8rem",
                                                    marginTop: "0.5rem",
                                                    fontFamily:
                                                        "'Inter', sans-serif", // aquí pones tu fuente
                                                }}
                                            >
                                                por persona
                                            </p>
                                        </div>

                                        <div className="card-body">
                                            <Link
                                                to={
                                                    isLoggedIn
                                                        ? `/reservas/${paquete?.id}`
                                                        : "/login"
                                                }
                                                state={{ from: location }}
                                                className="btn w-100 mb-2 d-flex align-items-center justify-content-center"
                                                style={{
                                                    background: "#8a775a",
                                                    color: "#ffffff",
                                                    fontSize: "0.9rem",
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                    border: "none",
                                                    textDecoration: "none",
                                                    transition: "all 0.3s",
                                                }}
                                                onMouseEnter={(e) =>
                                                    (e.currentTarget.style.filter =
                                                        "brightness(0.9)")
                                                }
                                                onMouseLeave={(e) =>
                                                    (e.currentTarget.style.filter =
                                                        "brightness(1)")
                                                }
                                            >
                                                <CreditCard
                                                    size={16}
                                                    className="me-1"
                                                />
                                                Reservar Ahora
                                            </Link>

                                            <Link
                                                to="/faq"
                                                className="w-100"
                                                style={{
                                                    display: "inline-flex",
                                                    alignItems: "center",
                                                    justifyContent: "center",
                                                    padding: "0.375rem 0.75rem",
                                                    fontSize: "0.9rem",
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                    fontWeight: 500,
                                                    color: "#8a775a",
                                                    border: "1px solid #8a775a", // borde siempre
                                                    borderRadius: "0.25rem",
                                                    backgroundColor:
                                                        "transparent",
                                                    textDecoration: "none",
                                                    transition: "all 0.3s",
                                                }}
                                                onMouseEnter={(e) => {
                                                    e.currentTarget.style.backgroundColor =
                                                        "#8a775a";
                                                    e.currentTarget.style.color =
                                                        "#ffffff";
                                                }}
                                                onMouseLeave={(e) => {
                                                    e.currentTarget.style.backgroundColor =
                                                        "transparent";
                                                    e.currentTarget.style.color =
                                                        "#8a775a";
                                                }}
                                            >
                                                <HelpCircle
                                                    size={16}
                                                    className="me-1"
                                                />
                                                Preguntas Frecuentes
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </motion.div>
                        </div>
                    </section>
                </motion.div>

                <motion.section
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.3 }}
                    className=""
                >
                    <div
                        className="container py-5"
                        style={{ maxWidth: "900px" }}
                    >
                        <h2
                            className="text-center fw-bold mb-4"
                            style={{
                                color: "#8a775a",
                                fontSize: "2rem",
                                fontFamily: "Inter, sans-serif",
                            }}
                        >
                            Itinerario Detallado
                        </h2>

                        <div className="row g-4">
                            {/* Itinerario */}
                            <div className="col-12 col-md-6 ">
                                <div
                                    className="card h-100"
                                    style={{
                                        backgroundColor: "#8a775a",
                                        border: "1px solid #8a775a",
                                        borderRadius: "1rem",
                                    }}
                                >
                                    <div className="card-header bg-transparent border-0">
                                        <h5
                                            className="card-title mb-1 d-flex align-items-center"
                                            style={{
                                                color: " #ffffff",
                                                fontSize: "16px",
                                                fontFamily: "Inter, sans-serif",
                                            }}
                                        >
                                            <Calendar
                                                size={20}
                                                className="me-2"
                                            />
                                            Días de tu Aventura
                                        </h5>
                                        <p
                                            className="mb-0"
                                            style={{
                                                fontFamily:
                                                    "'Inter', sans-serif",
                                                fontSize: "14px",
                                                color: " #ffffff",
                                                marginTop: "0rem",
                                            }}
                                        >
                                            Haz clic en cada día para ver los
                                            detalles completos
                                        </p>
                                    </div>
                                    <div className="card-body">
                                        <div
                                            className="accordion"
                                            id="accordionItinerary"
                                        >
                                            {puntosMapa.map((p, idx) => (
                                                <div
                                                    key={idx}
                                                    className="mb-3"
                                                    style={{
                                                        borderBottom:
                                                            "1px solid  #ffffff",
                                                    }}
                                                >
                                                    <button
                                                        className="btn w-100 text-start d-flex align-items-center justify-content-between"
                                                        type="button"
                                                        data-bs-toggle="collapse"
                                                        data-bs-target={`#collapse-${idx}`}
                                                        aria-expanded="false"
                                                        aria-controls={`collapse-${idx}`}
                                                        style={{
                                                            backgroundColor:
                                                                "transparent",
                                                            border: "none",
                                                            color: " #ffffff",
                                                            fontWeight: 500,
                                                        }}
                                                    >
                                                        <div
                                                            className="d-flex align-items-center"
                                                            style={{
                                                                fontFamily:
                                                                    "'Inter', sans-serif",
                                                                fontSize:
                                                                    "14px",
                                                            }}
                                                        >
                                                            <span
                                                                className="badge me-3"
                                                                style={{
                                                                    backgroundColor:
                                                                        "#ffffff",
                                                                    color: "#8a775a ",
                                                                    fontFamily:
                                                                        "'Inter', sans-serif",
                                                                }}
                                                            >
                                                                Día{" "}
                                                                {itinerarios[
                                                                    idx
                                                                ]?.dia ||
                                                                    idx + 1}
                                                            </span>
                                                            {p.nombre ||
                                                                `Punto ${
                                                                    idx + 1
                                                                }`}
                                                        </div>
                                                        <span
                                                            className="transition-arrow"
                                                            style={{
                                                                display:
                                                                    "inline-block",
                                                                transition:
                                                                    "transform 0.3s",
                                                            }}
                                                        >
                                                            <svg
                                                                xmlns="http://www.w3.org/2000/svg"
                                                                width="16"
                                                                height="16"
                                                                fill="none"
                                                                viewBox="0 0 24 24"
                                                                stroke="#ffffff"
                                                                strokeWidth="2"
                                                                strokeLinecap="round"
                                                                strokeLinejoin="round"
                                                                className="feather feather-chevron-down"
                                                            >
                                                                <polyline points="6 9 12 15 18 9" />
                                                            </svg>
                                                        </span>
                                                    </button>

                                                    <div
                                                        className="collapse"
                                                        id={`collapse-${idx}`}
                                                        onShow={(e) => {
                                                            const arrow =
                                                                e.target.previousSibling.querySelector(
                                                                    ".transition-arrow svg"
                                                                );
                                                            arrow.style.transform =
                                                                "rotate(180deg)";
                                                        }}
                                                        onHide={(e) => {
                                                            const arrow =
                                                                e.target.previousSibling.querySelector(
                                                                    ".transition-arrow svg"
                                                                );
                                                            arrow.style.transform =
                                                                "rotate(0deg)";
                                                        }}
                                                    >
                                                        <div className="pt-3">
                                                            <div
                                                                className="d-flex align-items-center small mb-2"
                                                                style={{
                                                                    fontFamily:
                                                                        "'Inter', sans-serif",
                                                                    fontSize:
                                                                        "14px",
                                                                    paddingLeft:
                                                                        "0.7rem",
                                                                    color: "#ffffff",
                                                                }}
                                                            >
                                                                <MapPin
                                                                    size={20}
                                                                    className="me-2"
                                                                    style={{
                                                                        color: "#ffffff",
                                                                    }}
                                                                />
                                                                {p.descripcion ||
                                                                    `Punto ${
                                                                        idx + 1
                                                                    }`}
                                                            </div>
                                                            <p
                                                                style={{
                                                                    color: "#ffffff",
                                                                    lineHeight:
                                                                        "1.6",
                                                                    paddingLeft:
                                                                        "1rem",
                                                                    marginLeft:
                                                                        "1rem",
                                                                    borderLeft:
                                                                        "2px solid #ffffff",
                                                                    fontFamily:
                                                                        "'Inter', sans-serif",
                                                                    fontSize:
                                                                        "14px",
                                                                }}
                                                            >
                                                                {itinerarios[
                                                                    idx
                                                                ]
                                                                    ?.descripcion ||
                                                                    "Sin descripción disponible"}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Mapa */}
                            <div className="col-12 col-md-6">
                                <div
                                    className="card h-100"
                                    style={{
                                        border: "1px solid #8a775a",
                                        borderRadius: "1rem",
                                        backgroundColor: "#8a775a",
                                    }}
                                >
                                    <div className="card-header border-bottom-0">
                                        <h5
                                            className="card-title d-flex align-items-center mb-1"
                                            style={{
                                                color: "#ffffff",
                                                fontSize: "16px",
                                                fontFamily: "Inter, sans-serif",
                                            }}
                                        >
                                            <span className="me-2">
                                                <i className="bi bi-geo-alt-fill" />
                                            </span>
                                            Tu Ruta de Aventura
                                        </h5>
                                        <p
                                            className="mb-0"
                                            style={{
                                                fontFamily:
                                                    "'Inter', sans-serif",
                                                fontSize: "14px",
                                                color: "#ffffff",
                                                marginTop: "0rem",
                                            }}
                                        >
                                            Explora todos los puntos que
                                            visitarás durante tu experiencia
                                        </p>
                                    </div>
                                    <div className="card-body">
                                        <div
                                            className="rounded overflow-hidden"
                                            style={{
                                                height: "400px",
                                            }}
                                        >
                                            <MapaPuntos puntos={puntosMapa} />
                                        </div>
                                        <div className="mt-3 text-center">
                                            <span
                                                className="badge rounded-pill"
                                                style={{
                                                    backgroundColor: "#ffffff",
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                    fontSize: "12px",
                                                    color: "#8a775a",
                                                }}
                                            >
                                                {puntosMapa.length} ubicaciones
                                                únicas
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </motion.section>

                <motion.section
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.4 }}
                    className="mb-16 container"
                    style={{ maxWidth: "900px" }}
                >
                    <h2
                        className="text-center fw-bold mb-4"
                        style={{
                            color: "#8a775a",
                            fontSize: "2rem",
                            fontFamily: "Inter, sans-serif",
                        }}
                    >
                        Galería de la Experiencia
                    </h2>

                    <div className="space-y-8">
                        {/* Imagen principal con controles */}
                        <div
                            className="position-relative mb-4 overflow-hidden rounded-3 main-image-wrapper"
                            style={{ width: "100%", margin: "0 auto" }}
                        >
                            <img
                                src={`${baseUrl}${imagenes[selectedImageIndex]?.ruta_imagen}`}
                                alt={`Imagen ${selectedImageIndex + 1}`}
                                className="w-100 h-100 object-fit-cover main-image"
                            />

                            {/* Controles y contador, solo visibles al hover */}
                            <div className="overlay d-flex justify-content-between align-items-center p-2 position-absolute w-100 h-100 top-0 start-0">
                                {/* Botón anterior */}
                                <button
                                    onClick={() =>
                                        setSelectedImageIndex(
                                            (selectedImageIndex -
                                                1 +
                                                imagenes.length) %
                                                imagenes.length
                                        )
                                    }
                                    className="btn btn-light"
                                    style={{
                                        width: "48px",
                                        height: "48px",
                                        opacity: 0.8,
                                    }}
                                >
                                    &#8249;
                                </button>

                                {/* Botón siguiente */}
                                <button
                                    onClick={() =>
                                        setSelectedImageIndex(
                                            (selectedImageIndex + 1) %
                                                imagenes.length
                                        )
                                    }
                                    className="btn btn-light"
                                    style={{
                                        width: "48px",
                                        height: "48px",
                                        opacity: 0.8,
                                    }}
                                >
                                    &#8250;
                                </button>

                                {/* Contador arriba derecha */}
                                <div className="position-absolute top-0 end-0 bg-dark text-light px-3 py-1 rounded m-2">
                                    {selectedImageIndex + 1} / {imagenes.length}
                                </div>
                            </div>
                        </div>

                        {/* Thumbnails */}
                        <div className="row g-2">
                            {imagenes.map((img, index) => (
                                <div
                                    key={index}
                                    className="col-4 col-md-2 position-relative"
                                >
                                    <button
                                        onClick={() =>
                                            setSelectedImageIndex(index)
                                        }
                                        className={`position-relative w-100 p-0 border-0 rounded overflow-hidden`}
                                        style={{
                                            aspectRatio: "1/1",
                                            border:
                                                selectedImageIndex === index
                                                    ? "7px solid  #c16e44"
                                                    : "none",
                                        }}
                                    >
                                        <img
                                            src={`${baseUrl}${img.ruta_imagen}`}
                                            alt={`Thumbnail ${index + 1}`}
                                            className="w-100 h-100 object-fit-cover rounded-2"
                                            style={{
                                                borderRadius: "0.5rem",
                                                border:
                                                    selectedImageIndex === index
                                                        ? "7px solid  #c16e44"
                                                        : "none",
                                            }}
                                        />

                                        {/* Tick naranja con círculo beige de fondo */}
                                        {selectedImageIndex === index && (
                                            <div
                                                className="position-absolute top-50 start-50 translate-middle d-flex align-items-center justify-content-center"
                                                style={{
                                                    width: "30px",
                                                    height: "30px",
                                                    borderRadius: "50%",
                                                    backgroundColor: " #ffffff", // beige semitransparente
                                                    color: " #c16e44",
                                                    fontSize: "1rem",
                                                    fontWeight: "bold",
                                                    pointerEvents: "none",
                                                }}
                                            >
                                                &#10003;
                                            </div>
                                        )}
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                    <ServiciosIncluidos paqueteId={id} />
                    <br />
                    <br />
                </motion.section>
            </section>
        </>
    );
};

export default ExperienciaSola;
