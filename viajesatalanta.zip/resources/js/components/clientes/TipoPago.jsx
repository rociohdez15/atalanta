import React, { useState, useEffect, useRef } from "react";
import { useNavigate, useParams, useLocation, Link } from "react-router-dom";
import axios from "axios";
import { motion } from "framer-motion";
import ServiciosIncluidos from "./servicios/Servicios";
import { BsCheck, BsX } from "react-icons/bs";
import {
    ArrowLeft,
    User,
    CheckCircle,
    DollarSign,
    Calendar,
    Users,
    CreditCard,
    Plus,
    Trash2,
    MapPin,
} from "lucide-react";

const TipoPago = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const { paqueteId } = useParams();
    const { id } = useParams();
    const { paqueteId: paqueteIdRuta } = useParams();

    const [tipoPago, setTipoPago] = useState("total");
    const [precioPaquete, setPrecioPaquete] = useState(0);
    const [cuotas, setCuotas] = useState(3);
    const [loading, setLoading] = useState(true);
    const [plazas, setPlazas] = useState(1);
    const [clienteId, setClienteId] = useState(null);
    const [paquete, setPaquete] = useState(null);
    const [error, setError] = useState(null);
    const [participantes, setParticipantes] = useState([null]);

    const { pathname } = useLocation();

    const baseUrl = `/storage/paquetes/${id}/images/`;

    const estiloFondo = paquete
        ? {
              backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url(/storage/paquetes/portada/${id}/${paquete.foto})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
              backgroundRepeat: "no-repeat",
          }
        : {};

    useEffect(() => {
        axios
            .get(`/api/paquetes/${paqueteId}`)
            .then((res) => setPaquete(res.data))
            .catch(() => setError("No se pudo cargar el paquete"));

        axios
            .get(`/api/paquetes/${paqueteId}/imagenes`)
            .then((res) => setImagenes(res.data))
            .catch(() => setError("No se pudieron cargar las imágenes"));

        axios
            .get(`/api/paquetes/${paqueteId}/puntos`)
            .then((res) => setPuntosMapa(res.data))
            .catch(() => setError("No se pudieron cargar los puntos del mapa"));

        axios
            .get(`/api/paquetes/${paqueteId}/itinerarios`)
            .then((res) => setItinerarios(res.data))
            .catch(() => setError("No se pudieron cargar los itinerarios"));
    }, [id]);

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);

    useEffect(() => {
        const idFinal =
            paqueteIdRuta ||
            location.state?.paqueteId ||
            localStorage.getItem("paqueteId");

        if (!idFinal) {
            alert("No se encontró el ID del paquete.");
            return;
        }

        localStorage.setItem("paqueteId", idFinal);

        axios
            .get(`/api/paquetes/${idFinal}`)
            .then((res) => {
                setPrecioPaquete(res.data.precio);
                setLoading(false);
            })
            .catch((err) => {
                setLoading(false);
            });

        const participantes = JSON.parse(
            localStorage.getItem("participantes") || "[]"
        );
        setPlazas(participantes.length || 1);

        const idCliente = localStorage.getItem("clienteId");
        setClienteId(idCliente);
    }, [paqueteIdRuta, location.state]);

    const calcularTotal = () => {
        return (precioPaquete * plazas).toFixed(2);
    };

    const calcularCuota = () => {
        return ((precioPaquete * plazas) / cuotas).toFixed(2);
    };

    const handlePagar = async () => {
        const token =
            localStorage.getItem("token") || sessionStorage.getItem("token");

        if (!token) {
            // Vaciar datos de sesión/localStorage
            localStorage.clear();
            sessionStorage.clear();

            // Redirigir al login
            navigate("/login", { replace: true }); // replace evita que puedan ir atrás
            return false; // opcional: para usarlo en condicionales
        }

        const participantes = JSON.parse(
            localStorage.getItem("participantes") || "[]"
        );
        const emailCliente =
            participantes.length > 0
                ? participantes[0].email
                : "cliente@ejemplo.com";

        const importeAPagar =
            tipoPago === "parcial"
                ? parseFloat(calcularCuota())
                : parseFloat(calcularTotal());

        const paqueteIdFinal =
            paqueteIdRuta ||
            location.state?.paqueteId ||
            localStorage.getItem("paqueteId");

        // Definir cuotas e importeCuota para guardar localStorage y enviar
        const cuotasFinal = tipoPago === "parcial" ? cuotas : null;
        const importeCuotaFinal =
            tipoPago === "parcial" ? parseFloat(calcularCuota()) : 0;

        const datosPago = {
            clienteId,
            participantes,
            tipoPago,
            cuotas: cuotasFinal,
            total: importeAPagar,
            email: emailCliente,
            paqueteId: parseInt(paqueteIdFinal),
            precioUnitario: precioPaquete,
        };

        // Guardar en localStorage de forma consistente
        localStorage.setItem("tipoPago", tipoPago);
        localStorage.setItem(
            "cuotas",
            cuotasFinal ? cuotasFinal.toString() : ""
        );
        localStorage.setItem("totalPrecio", importeAPagar.toString());
        localStorage.setItem(
            "importeCuotas",
            importeCuotaFinal > 0 ? importeCuotaFinal.toString() : "0"
        );
        localStorage.setItem("plazas", plazas.toString());
        localStorage.setItem(
            "clienteId",
            clienteId ? clienteId.toString() : ""
        );

        try {
            const response = await axios.post("/api/pago/stripe", datosPago);
            window.location.replace(response.data.url); // 🔥 Reemplaza la URL actual en el historial
        } catch (error) {
            alert("Error al iniciar el pago, intenta de nuevo.");
        }
    };
    const totalPrice = paquete?.precio
        ? paquete.precio * participantes.length
        : 0;
    const totalOriginalPrice = paquete?.precio
        ? paquete.precio * participantes.length
        : null;

    if (loading)
        return <div className="text-center my-5">Cargando precio...</div>;

    return (
        <>
            <style
                dangerouslySetInnerHTML={{
                    __html: `
      body {
        font-family: 'Merriweather', serif;
        margin: 0;
      }

      .bg-cover {
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        filter: brightness(75%);
      }

      .hero-container {
        background-color: transparent !important; /* Asegura que el hero no reciba el fondo */
      }
    `,
                }}
            />

            {/* Hero section debajo del navbar */}
            <section className="w-100 m-0 p-0">
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.8 }}
                    className="position-relative overflow-hidden"
                    style={{
                        paddingTop: "5rem",
                        paddingBottom: "5rem",
                        background:
                            "linear-gradient(to right, #8a775a, #877c4f)",
                    }}
                >
                    {/* Imagen de fondo */}
                    <div className="position-absolute top-0 start-0 w-100 h-100">
                        <img
                            src={
                                paquete
                                    ? `/storage/paquetes/portada/${paqueteId}/${paquete.foto}`
                                    : "https://via.placeholder.com/1920x1080" // fallback
                            }
                            alt={paquete ? paquete.nombre : "Imagen de paquete"}
                            className="w-100 h-100"
                            style={{
                                objectFit: "cover",
                            }}
                        />

                        {/* Overlay oscuro translúcido */}
                        <div
                            className="position-absolute top-0 start-0 w-100 h-100"
                            style={{
                                backgroundColor: "rgba(0, 0, 0, 0.4)", // negro translúcido
                            }}
                        ></div>
                    </div>

                    {/* Contenido */}
                    <section className="position-relative px-3 px-sm-4 px-lg-5">
                        <div
                            className="container position-relative"
                            style={{ zIndex: 2, maxWidth: "1200px" }}
                        >
                            {/* Botón volver */}
                            <button
                                type="button"
                                onClick={() =>
                                    (window.location.href = "/experiencias")
                                }
                                className="btn btn-link d-flex align-items-center mb-4"
                                style={{
                                    transition:
                                        "color 0.3s ease, background-color 0.3s ease",
                                    textDecoration: "none",
                                    boxShadow: "none",
                                    color: "#ffffff",
                                    fontFamily: "Inter, sans-serif",
                                    fontSize: "10pt",
                                    marginTop: "-25px",
                                    marginLeft: "-60px",
                                }}
                                onMouseEnter={(e) => {
                                    e.currentTarget.style.color = "#ffffff";
                                    e.currentTarget.style.backgroundColor =
                                        "rgba(53, 55, 46, 0.1)";
                                    e.currentTarget.style.textDecoration =
                                        "none";
                                    e.currentTarget.style.boxShadow = "none";
                                }}
                                onMouseLeave={(e) => {
                                    e.currentTarget.style.color = "#ffffff";
                                    e.currentTarget.style.backgroundColor =
                                        "transparent";
                                    e.currentTarget.style.textDecoration =
                                        "none";
                                    e.currentTarget.style.boxShadow = "none";
                                }}
                            >
                                <ArrowLeft size={20} className="me-2" />
                                Volver a Experiencias
                            </button>

                            <motion.div
                                initial={{ y: 30, opacity: 0 }}
                                animate={{ y: 0, opacity: 1 }}
                                transition={{ duration: 0.8, delay: 0.2 }}
                                className="text-center"
                            >
                                <h1
                                    className="fw-bold"
                                    style={{
                                        color: "#ffffff",
                                        fontFamily:
                                            '"TT Espina Trial Variable", sans-serif',
                                        fontSize: "clamp(2rem, 5vw, 4rem)",
                                        transform: "scaleX(1.5)", // 1.0 es normal, >1 estira
                                        display: "inline-block",
                                    }}
                                >
                                    Selecciona el tipo de pago
                                </h1>
                                <p
                                    className="lead mx-auto"
                                    style={{
                                        maxWidth: "720px",
                                        fontSize: "14pt",
                                        color: "#ffffff",
                                    }}
                                >
                                    Elige entre pago único o pago en cuotas para
                                    completar tu reserva. Procesamos pagos de
                                    forma segura.
                                </p>
                            </motion.div>
                        </div>
                    </section>
                </motion.div>

                <div className="container my-5">
                    <div className="row g-5 justify-content-center">
                        {/* Columna izquierda */}
                        <div className="col-lg-8 mx-auto">
                            <motion.div
                                initial={{ opacity: 0, y: 30 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.8, delay: 0.3 }}
                                className="d-flex flex-column gap-4"
                            >
                                {/* Pago Único */}
                                <motion.div
                                    whileHover={{ scale: 1.02 }}
                                    transition={{ duration: 0.2 }}
                                    className={`rounded-4 p-4 cursor-pointer ${
                                        tipoPago === "total"
                                            ? "shadow"
                                            : "border border-secondary-subtle"
                                    }`}
                                    style={{
                                        border: "2px solid",
                                        borderColor:
                                            tipoPago === "total"
                                                ? "#8a775a"
                                                : "#8a775a",
                                        backgroundColor: "#8a775a",
                                    }}
                                    onClick={() => setTipoPago("total")}
                                >
                                    <div className="d-flex">
                                        <input
                                            type="radio"
                                            id="total"
                                            name="pago"
                                            checked={tipoPago === "total"}
                                            onChange={() =>
                                                setTipoPago("total")
                                            }
                                            className="form-check-input me-3 mt-1"
                                        />
                                        <div>
                                            <label
                                                htmlFor="total"
                                                className="form-label fw-semibold d-flex align-items-center"
                                                style={{
                                                    color: "#ffffff",
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                    fontSize: "14px",
                                                }}
                                            >
                                                <DollarSign className="me-2" />
                                                Pago Único
                                                {tipoPago === "total" && (
                                                    <span
                                                        className="badge ms-2"
                                                        style={{
                                                            backgroundColor:
                                                                "#3a9e2fff",
                                                            fontFamily:
                                                                "'Inter', sans-serif",
                                                            color: " #ffffff",
                                                        }}
                                                    >
                                                        Seleccionado
                                                    </span>
                                                )}
                                            </label>
                                            <p
                                                style={{
                                                    color: "#ffffff",
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                    fontSize: "14px",
                                                }}
                                            >
                                                Paga ahora el total del viaje.
                                                ¡Sin complicaciones!
                                            </p>
                                            <div
                                                className=" rounded p-3 d-flex justify-content-between"
                                                style={{
                                                    backgroundColor: "#ffffff",
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                    fontSize: "14px",
                                                    color: "#8a775a",
                                                }}
                                            >
                                                <span
                                                    style={{ fontSize: "14px" }}
                                                >
                                                    Total a pagar:
                                                </span>
                                                <span
                                                    className="fw-bold"
                                                    style={{
                                                        color: " #8a775a",
                                                        fontSize: "14px",
                                                    }}
                                                >
                                                    {calcularTotal()}€
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </motion.div>

                                {/* Pago en Cuotas */}
                                <motion.div
                                    whileHover={{ scale: 1.02 }}
                                    transition={{ duration: 0.2 }}
                                    className={`border rounded-4 p-4 cursor-pointer ${
                                        tipoPago === "parcial"
                                            ? "shadow"
                                            : "border border-secondary-subtle"
                                    }`}
                                    style={{
                                        border: "2px solid",
                                        borderColor:
                                            tipoPago === "total"
                                                ? "#8a775a"
                                                : "#8a775a",
                                        backgroundColor: "#8a775a",
                                    }}
                                    onClick={() => setTipoPago("parcial")}
                                >
                                    <div className="d-flex">
                                        <input
                                            type="radio"
                                            id="parcial"
                                            name="pago"
                                            checked={tipoPago === "parcial"}
                                            onChange={() =>
                                                setTipoPago("parcial")
                                            }
                                            className="form-check-input me-3 mt-1"
                                        />
                                        <div>
                                            <label
                                                htmlFor="parcial"
                                                className="form-label fw-semibold d-flex align-items-center"
                                                style={{
                                                    color: "#ffffff",
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                    fontSize: "14px",
                                                }}
                                            >
                                                <Calendar className="me-2" />
                                                Pago en Cuotas
                                                {tipoPago === "parcial" && (
                                                    <span
                                                        className="badge ms-2"
                                                        style={{
                                                            backgroundColor:
                                                                "#ffffff",
                                                            fontFamily:
                                                                "'Inter', sans-serif",
                                                            color: " #8a775a",
                                                        }}
                                                    >
                                                        Seleccionado
                                                    </span>
                                                )}
                                            </label>
                                            <p
                                                style={{
                                                    color: "#ffffff",
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                    fontSize: "14px",
                                                }}
                                            >
                                                Haz un primer pago ahora y
                                                divide el resto.
                                            </p>

                                            {tipoPago === "parcial" && (
                                                <motion.div
                                                    initial={{
                                                        opacity: 0,
                                                        height: 0,
                                                    }}
                                                    animate={{
                                                        opacity: 1,
                                                        height: "auto",
                                                    }}
                                                    transition={{
                                                        duration: 0.3,
                                                    }}
                                                    className="mt-3"
                                                >
                                                    <label
                                                        className="fw-medium mb-2"
                                                        style={{
                                                            color: "#ffffff",
                                                            fontFamily:
                                                                "'Inter', sans-serif",
                                                            fontSize: "14px",
                                                        }}
                                                    >
                                                        Selecciona número de
                                                        cuotas:
                                                    </label>
                                                    <select
                                                        className="form-select mb-3"
                                                        style={{
                                                            height: "40px",
                                                            backgroundColor:
                                                                "#ffffff",
                                                            color: " #8a775a",
                                                            fontFamily:
                                                                "'Inter', sans-serif",
                                                            fontSize: "14px",
                                                        }}
                                                        value={cuotas}
                                                        onChange={(e) =>
                                                            setCuotas(
                                                                parseInt(
                                                                    e.target
                                                                        .value
                                                                )
                                                            )
                                                        }
                                                    >
                                                        <option value={3}>
                                                            3 cuotas
                                                        </option>
                                                        <option value={6}>
                                                            6 cuotas
                                                        </option>
                                                    </select>

                                                    <div
                                                        className="rounded p-3"
                                                        style={{
                                                            backgroundColor:
                                                                "#ffffff",
                                                            color: " #8a775a",
                                                            fontFamily:
                                                                "'Inter', sans-serif",
                                                        }}
                                                    >
                                                        <div className="d-flex justify-content-between">
                                                            <span
                                                                style={{
                                                                    fontSize:
                                                                        "14px",
                                                                }}
                                                            >
                                                                Primer pago
                                                                (hoy):
                                                            </span>
                                                            <span
                                                                className="fw-bold"
                                                                style={{
                                                                    color: "#8a775a",
                                                                    fontSize:
                                                                        "14px",
                                                                }}
                                                            >
                                                                {calcularCuota()}
                                                                €
                                                            </span>
                                                        </div>
                                                        <hr
                                                            style={{
                                                                color: "#8a775a",
                                                            }}
                                                        />
                                                        <div
                                                            className="d-flex justify-content-between"
                                                            style={{
                                                                backgroundColor:
                                                                    "#ffffff",
                                                                color: " #8a775a",
                                                                fontFamily:
                                                                    "'Inter', sans-serif",
                                                                fontSize:
                                                                    "14px",
                                                            }}
                                                        >
                                                            <span
                                                                style={{
                                                                    fontSize:
                                                                        "14px",
                                                                }}
                                                            >
                                                                Pagos restantes:
                                                            </span>
                                                            <span>
                                                                {cuotas - 1}{" "}
                                                                cuotas de{" "}
                                                                {calcularCuota()}
                                                                €
                                                            </span>
                                                        </div>
                                                        <small
                                                            className="d-block mt-2"
                                                            style={{
                                                                backgroundColor:
                                                                    "#ffffff",
                                                                color: " #8a775a",
                                                                fontFamily:
                                                                    "'Inter', sans-serif",
                                                            }}
                                                        >
                                                            <strong>
                                                                Próximos pagos:
                                                            </strong>{" "}
                                                            Los siguientes{" "}
                                                            {cuotas - 1} meses
                                                        </small>
                                                    </div>
                                                </motion.div>
                                            )}
                                        </div>
                                    </div>
                                </motion.div>

                                {/* Información de Seguridad */}
                                <div
                                    className="card border-0 shadow-sm rounded-4"
                                    style={{
                                        backgroundColor: " #8a775a",
                                    }}
                                >
                                    <div className="card-body">
                                        <div className="d-flex align-items-center mb-3">
                                            <CheckCircle
                                                className="me-2"
                                                size={22}
                                                style={{ color: "#ffffff" }}
                                            />
                                            <h6
                                                className="mb-0 fw-semibold"
                                                style={{
                                                    color: "#ffffff",
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                }}
                                            >
                                                Pago 100% Seguro
                                            </h6>
                                        </div>
                                        <div className="row text-muted small">
                                            <div
                                                className="col-md-4 d-flex align-items-center"
                                                style={{
                                                    color: "#ffffff",
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                }}
                                            >
                                                <div
                                                    className="rounded-circle me-2"
                                                    style={{
                                                        width: "8px",
                                                        height: "8px",
                                                        fontFamily:
                                                            "'Inter', sans-serif",
                                                        backgroundColor:
                                                            "#ffffff",
                                                    }}
                                                ></div>
                                                Cifrado SSL 256-bit
                                            </div>
                                            <div
                                                className="col-md-4 d-flex align-items-center"
                                                style={{
                                                    color: "#ffffff",
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                }}
                                            >
                                                <div
                                                    className="rounded-circle me-2"
                                                    style={{
                                                        width: "8px",
                                                        height: "8px",
                                                        backgroundColor:
                                                            "#ffffff",
                                                    }}
                                                ></div>
                                                Protección antifraude
                                            </div>
                                            <div
                                                className="col-md-4 d-flex align-items-center"
                                                style={{
                                                    color: "#ffffff",
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                }}
                                            >
                                                <div
                                                    className="rounded-circle me-2"
                                                    style={{
                                                        width: "8px",
                                                        height: "8px",
                                                        backgroundColor:
                                                            "#ffffff",
                                                    }}
                                                ></div>
                                                Reembolso garantizado
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Botón Confirmar */}
                                <motion.div
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ duration: 0.6, delay: 0.5 }}
                                    className="d-flex justify-content-center"
                                >
                                    <button
                                        onClick={handlePagar}
                                        className="btn btn-lg text-white fw-semibold px-5 py-3"
                                        style={{
                                            background: "#8a775a",
                                            transition: "all 0.3s",
                                            fontFamily: "'Inter', sans-serif",
                                            fontSize: "14px",
                                        }}
                                    >
                                        <CreditCard
                                            size={18}
                                            className="me-2"
                                        />
                                        {tipoPago === "total"
                                            ? `Pagar €${calcularTotal()}`
                                            : `Pagar Primera Cuota €${calcularCuota()}`}
                                    </button>
                                </motion.div>
                            </motion.div>
                        </div>

                        {/* Columna derecha: Resumen de Reserva */}
                        <div className="col-lg-4 mx-auto">
                            <motion.div
                                initial={{ opacity: 0, y: 30 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.8, delay: 0.4 }}
                                className="position-sticky"
                                style={{ top: "8rem" }}
                            >
                                <div
                                    className="card rounded-4"
                                    style={{
                                        backgroundColor: "#8a775a",
                                        border: "1px solid #ffffff",
                                    }}
                                >
                                    <div
                                        className="card-header"
                                        style={{ borderBottom: "none" }}
                                    >
                                        <h5
                                            className="card-title"
                                            style={{ color: "#ffffff" }}
                                        >
                                            Resumen de Reserva
                                        </h5>
                                    </div>
                                    <div className="card-body">
                                        {/* Imagen y detalles de la experiencia */}
                                        <div className="mb-4">
                                            <div className="ratio ratio-16x9 rounded mb-2 overflow-hidden">
                                                <img
                                                    src={
                                                        paquete
                                                            ? `/storage/paquetes/portada/${paqueteId}/${paquete.foto}`
                                                            : ""
                                                    }
                                                    alt={
                                                        paquete?.titulo ||
                                                        "Imagen de la experiencia"
                                                    }
                                                    className="img-fluid w-100 h-100 object-fit-cover"
                                                />
                                            </div>
                                            {paquete && (
                                                <span
                                                    className="badge"
                                                    style={{
                                                        backgroundColor:
                                                            "#3a9e2fff",
                                                        color: "#ffffff",
                                                        fontFamily:
                                                            "'Inter', sans-serif",
                                                    }}
                                                >
                                                    {paquete.tipo_viaje}
                                                </span>
                                            )}
                                            <h3
                                                className="fw-bold mt-2 mb-2"
                                                style={{
                                                    color: "#ffffff",
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                    fontSize: "18px",
                                                }}
                                            >
                                                {paquete?.nombre ||
                                                    "Nombre no disponible"}
                                            </h3>

                                            <div
                                                className="text-muted small"
                                                style={{
                                                    color: "rgba(53,55,46,0.7)",
                                                }}
                                            >
                                                <div
                                                    className="d-flex align-items-center mb-1"
                                                    style={{
                                                        color: "#ffffff",
                                                        fontFamily:
                                                            "'Inter', sans-serif",
                                                        fontSize: "14px",
                                                    }}
                                                >
                                                    <MapPin
                                                        size={14}
                                                        className="me-2"
                                                    />
                                                    <span>
                                                        {paquete
                                                            ? paquete.lugar
                                                            : "Cargando..."}
                                                    </span>
                                                </div>
                                                <div
                                                    className="d-flex align-items-center mb-1"
                                                    style={{
                                                        color: "#ffffff",
                                                        fontFamily:
                                                            "'Inter', sans-serif",
                                                        fontSize: "14px",
                                                    }}
                                                >
                                                    <Calendar
                                                        size={14}
                                                        className="me-2"
                                                    />
                                                    <span>
                                                        {(() => {
                                                            if (
                                                                !paquete?.fecha_inicio ||
                                                                !paquete?.fecha_fin
                                                            )
                                                                return "Cargando...";

                                                            const inicio =
                                                                new Date(
                                                                    paquete.fecha_inicio
                                                                );
                                                            const fin =
                                                                new Date(
                                                                    paquete.fecha_fin
                                                                );

                                                            const diaInicio =
                                                                inicio.getDate();
                                                            const diaFin =
                                                                fin.getDate();
                                                            const mes =
                                                                fin.toLocaleDateString(
                                                                    "es-ES",
                                                                    {
                                                                        month: "long",
                                                                    }
                                                                );
                                                            const año =
                                                                fin.getFullYear();

                                                            return `${diaInicio} al ${diaFin} de ${mes} de ${año}`;
                                                        })()}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>

                                        <hr
                                            style={{
                                                borderColor: "#ffffff",
                                            }}
                                        />

                                        {/* Precio */}
                                        <div>
                                            <div className="mb-3">
                                                <div className="d-flex justify-content-between text-muted mb-1">
                                                    <span
                                                        style={{
                                                            color: "#ffffff",
                                                            fontFamily:
                                                                "'Inter', sans-serif",
                                                            fontSize: "14px",
                                                        }}
                                                    >
                                                        Precio por persona:
                                                    </span>
                                                    <div className="d-flex align-items-center gap-2">
                                                        <span
                                                            className="fw-medium"
                                                            style={{
                                                                color: "#ffffff",
                                                                fontFamily:
                                                                    "'Inter', sans-serif",
                                                                fontSize:
                                                                    "14px",
                                                            }}
                                                        >
                                                            {paquete?.precio ||
                                                                "Cargando..."}
                                                            €
                                                        </span>
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-between text-muted mb-1">
                                                    <span
                                                        style={{
                                                            color: "#ffffff",
                                                            fontFamily:
                                                                "'Inter', sans-serif",
                                                            fontSize: "14px",
                                                        }}
                                                    >
                                                        Número de viajeros:
                                                    </span>
                                                    <span
                                                        style={{
                                                            color: "#ffffff",
                                                            fontFamily:
                                                                "'Inter', sans-serif",
                                                            fontSize: "14px",
                                                        }}
                                                    >
                                                        {participantes.length}
                                                    </span>
                                                </div>
                                            </div>

                                            <hr
                                                style={{
                                                    borderColor: "#ffffff",
                                                }}
                                            />

                                            <div
                                                className="d-flex justify-content-between fw-bold fs-5"
                                                style={{
                                                    color: "#ffffff",
                                                    fontFamily:
                                                        "'Inter', sans-serif",
                                                    fontSize: "14px",
                                                }}
                                            >
                                                <span>Total:</span>
                                                <span>€{totalPrice}</span>
                                            </div>
                                            <br />
                                            {/* Resumen del plan de pago seleccionado */}
                                            {tipoPago === "parcial" && (
                                                <div
                                                    className="card mb-3"
                                                    style={{
                                                        backgroundColor:
                                                            "#ffffff",
                                                    }}
                                                >
                                                    <div className="card-body p-3">
                                                        <h6
                                                            className="card-subtitle mb-2 fw-medium"
                                                            style={{
                                                                color: " #8a775a",
                                                            }}
                                                        >
                                                            Plan de Pago
                                                            Seleccionado: Cuotas
                                                        </h6>
                                                        <div
                                                            className="small"
                                                            style={{
                                                                color: " #8a775a",
                                                                fontFamily:
                                                                    "'Inter', sans-serif",
                                                            }}
                                                        >
                                                            <div>
                                                                • Hoy:{" "}
                                                                {calcularCuota()}
                                                                €
                                                            </div>
                                                            <div
                                                                style={{
                                                                    color: " #8a775a",
                                                                    fontFamily:
                                                                        "'Inter', sans-serif",
                                                                }}
                                                            >
                                                                {cuotas - 1}{" "}
                                                                cuotas de €
                                                                {calcularCuota()}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </motion.div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
};

export default TipoPago;
