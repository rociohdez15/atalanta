import React, { useEffect, useState } from "react";
import { v4 as uuidv4 } from "uuid";
import { useLocation, Navigate } from "react-router-dom";
import { motion } from "framer-motion";
import { BsCheck, BsX } from "react-icons/bs";
import axios from "axios";
import {
    ArrowLeft,
    Mail,
    CheckCircle,
    DollarSign,
    Calendar,
    Users,
    CreditCard,
    Plus,
    Trash2,
    MapPin,
} from "lucide-react";

const PagoExito = () => {
    const [datosPago, setDatosPago] = useState(null);
    const [reservationToken, setReservationToken] = useState(null);
    const [enviando, setEnviando] = useState(false);

    const { pathname } = useLocation();

    const token =
        localStorage.getItem("token") || sessionStorage.getItem("token");

    if (!token) {
        // Si no hay token, redirige al login
        return <Navigate to="/login" replace />;
    }

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);

    // Crea clave para identificar datos únicos de reserva
    const crearClaveDatos = (datos) => {
        if (!datos) return "";
        return JSON.stringify({
            paqueteId: datos.paqueteId,
            participantes: datos.participantes,
            totalPrecio: datos.totalPrecio,
        });
    };

    // Carga datosPago
    useEffect(() => {
        let tipoPagoRaw = localStorage.getItem("tipoPago") || "";
        const tipoPago = tipoPagoRaw.trim().toLowerCase();

        const participantes = JSON.parse(
            localStorage.getItem("participantes") || "[]"
        );
        const paqueteId = localStorage.getItem("paqueteId");
        const cuotas = localStorage.getItem("cuotas");
        const importeCuotas = localStorage.getItem("importeCuotas");
        const totalPrecio = localStorage.getItem("totalPrecio");
        const plazas = localStorage.getItem("plazas");
        const clienteId = localStorage.getItem("clienteId");

        const datos = {
            participantes,
            paqueteId: paqueteId ? parseInt(paqueteId) : null,
            tipoPago,
            cuotas: cuotas ? parseInt(cuotas) : null,
            importeCuotas: importeCuotas ? parseFloat(importeCuotas) : null,
            totalPrecio: totalPrecio ? parseFloat(totalPrecio) : null,
            plazas: plazas ? parseInt(plazas) : null,
            clienteId: clienteId ? parseInt(clienteId) : null,
        };

        setDatosPago(datos);
    }, []);

    // Manejo de reservationToken y si hay reserva enviada para ese token
    useEffect(() => {
        if (!datosPago) return;

        const datosActualesStr = crearClaveDatos(datosPago);
        const datosGuardadosStr =
            localStorage.getItem("datosReservaClave") || "";
        let tokenGuardado = localStorage.getItem("reservationToken");

        if (!tokenGuardado || datosGuardadosStr !== datosActualesStr) {
            // Cambiaron los datos o no hay token, genero nuevo
            tokenGuardado = uuidv4();
            localStorage.setItem("reservationToken", tokenGuardado);
            localStorage.setItem("datosReservaClave", datosActualesStr);
            // Importante: también eliminar marca de reserva enviada para token previo si existe
            // (por si token guardado cambió)
            localStorage.removeItem("reservaRegistrada_" + tokenGuardado);
        }

        setReservationToken(tokenGuardado);
    }, [datosPago]);

    // Enviar reserva SOLO si NO está marcada como enviada para este token
    useEffect(() => {
    if (!datosPago || !reservationToken) return;

    const reservaYaEnviada =
        localStorage.getItem("reservaRegistrada_" + reservationToken) === "true";

    if (reservaYaEnviada) return;

    if (datosPago.participantes.length > 0 && datosPago.paqueteId) {
        setEnviando(true);
        const token =
            localStorage.getItem("token") ||
            sessionStorage.getItem("token");

        const body = {
            paqueteId: datosPago.paqueteId,
            clienteId: datosPago.clienteId,
            tipoPago: datosPago.tipoPago,
            cuotas: datosPago.cuotas,
            importeCuotas: datosPago.importeCuotas,
            totalPrecio: datosPago.totalPrecio,
            plazas: datosPago.plazas,
            participantes: datosPago.participantes,
            reservationToken: reservationToken,
        };

        axios.post("/api/registro/reserva", body, {
            headers: { Authorization: `Bearer ${token}` },
        })
        .then((res) => {
            console.log("Reserva registrada:", res.data);
            // Marca que la reserva ya fue enviada para este token
            localStorage.setItem("reservaRegistrada_" + reservationToken, "true");
            setEnviando(false);
        })
        .catch((err) => {
            console.error("Error al registrar reserva:", err.response || err);
            setEnviando(false);
        });
    }
}, [datosPago, reservationToken]);


    return (
        <div
            className="min-vh-100"
            style={{
                backgroundColor: "#ffffff",
            }}
        >
            {/* Header de éxito */}
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
                className="position-relative py-5 px-3 overflow-hidden"
                style={{
                    backgroundColor: "#ffffff",
                }}
            >
                {/* Overlay de gradiente */}
                <div
                    className="position-absolute w-100 h-100 top-0 start-0"
                    style={{
                        backgroundColor: "#ffffff",
                    }}
                ></div>

                <div
                    className="position-relative text-center mx-auto"
                    style={{ maxWidth: "960px" }}
                >
                    {/* Icono de éxito animado */}
                    <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ duration: 0.6, delay: 0.2 }}
                        className="d-inline-flex align-items-center justify-content-center mb-4 rounded-circle shadow"
                        style={{
                            width: "6rem",
                            height: "6rem",
                            backgroundColor: "#4ade80",
                        }}
                    >
                        <CheckCircle size={48} className="text-white" />
                    </motion.div>

                    <motion.div
                        initial={{ y: 30, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ duration: 0.8, delay: 0.4 }}
                    >
                        <h1
                            className="fw-bold mb-3"
                            style={{
                                fontSize: "2.5rem",
                                color: "#8a775a",
                                fontFamily: "'Inter', sans-serif",
                            }}
                        >
                            ¡Pago realizado con éxito!
                        </h1>
                        <p
                            className="mb-4"
                            style={{
                                fontSize: "1.25rem",
                                color: "#8a775a",
                                fontFamily:
                                                    "'Inter', sans-serif",
                            }}
                        >
                            Tu reserva ha sido registrada correctamente.
                        </p>
                    </motion.div>
                </div>
            </motion.div>

            {/* Contenido principal */}
            <div
                className="d-flex justify-content-center align-items-center"
                style={{
                    backgroundColor: "#ffffff",
                    padding: " 1rem",
                }}
            >
                <div className="col-12 col-md-8">
                    <motion.div
                        initial={{ opacity: 0, x: -30 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.8, delay: 0.3 }}
                    >
                        {/* Card de agradecimiento */}
                        <div
                            className="card mb-4"
                            style={{
                                backgroundColor: "#8a775a",
                                border: "1px solid #8a775a",
                                overflow: "hidden",
                            }}
                        >
                            <div className="card-body text-center p-4">
                                <h2
                                    className="fw-bold mb-3"
                                    style={{ color: "#ffffff", fontFamily:
                                                    "'Inter', sans-serif", }}
                                >
                                    ¡Gracias!
                                </h2>
                                <p
                                    className="mb-3"
                                    style={{ color: "#ffffff", fontFamily:
                                                    "'Inter', sans-serif", }}
                                >
                                    Te hemos enviado un email con toda la
                                    información, por favor revisa tu correo
                                    electrónico.
                                </p>

                                <hr
                                    style={{
                                        borderColor: "#ffffff",
                                    }}
                                />

                                <div
                                    className=" mt-3"
                                    style={{ color: "#ffffff" }}
                                >
                                    <div className="d-flex align-items-center justify-content-center mb-2">
                                        <Mail
                                            size={20}
                                            className="me-2"
                                        />
                                        <span style={{fontFamily:
                                                    "'Inter', sans-serif",}}>
                                            Confirmación enviada por email
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </div>
        </div>
    );
};

export default PagoExito;
