import React, { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Menu, X, User, LogOut } from "lucide-react";

function isTokenExpired(token) {
    try {
        const payload = JSON.parse(atob(token.split(".")[1]));
        return payload.exp && payload.exp < Math.floor(Date.now() / 1000);
    } catch {
        return true;
    }
}

const Navbar = () => {
    const [isNavOpen, setIsNavOpen] = useState(false);
    const [isScrolled, setIsScrolled] = useState(false);
    const [user, setUser] = useState(null);
    const navigate = useNavigate();
    const { pathname } = useLocation();

    // Detectar scroll
    useEffect(() => {
        const handleScroll = () => setIsScrolled(window.scrollY > 50); // si scrolleas más de 50px
        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);

    useEffect(() => {
        const storedUser =
            localStorage.getItem("user") || sessionStorage.getItem("user");
        const storedToken =
            localStorage.getItem("token") || sessionStorage.getItem("token");

        if (storedUser && storedToken && !isTokenExpired(storedToken)) {
            setUser(JSON.parse(storedUser));
        } else {
            localStorage.removeItem("token");
            localStorage.removeItem("user");
            sessionStorage.removeItem("token");
            sessionStorage.removeItem("user");
            setUser(null);
        }
    }, []);

    const toggleMenu = () => setIsNavOpen((prev) => !prev);
    const closeMenu = () => setIsNavOpen(false);

    const handleLogout = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        sessionStorage.removeItem("token");
        sessionStorage.removeItem("user");
        setUser(null);
        navigate("/login");
        closeMenu();
    };

    const isHome = location.pathname === "/";

    return (
        <header
            className="u-header fixed-top"
            style={{
                backgroundColor: isHome
                    ? isScrolled
                        ? "#8a775a"
                        : "transparent"
                    : "#8a775a",
                width: "100%", // 🔥 ocupa todo el ancho
                left: 0, // 🔥 alinea al borde izquierdo
                right: 0,
                padding: "0.25rem 1rem",
                height: "80px",
                display: "flex",
                alignItems: "center",
                zIndex: 999,
            }}
        >
            <div className="container-fluid d-flex justify-content-between align-items-center flex-wrap">
                {/* Logo */}
                <Link to="/" className="u-image u-logo ms-3">
                    <div style={{ display: "flex", alignItems: "center" }}>
                        <img
                            src="images/logo_atalanta1.png"
                            alt="Logo"
                            style={{
                                width: "70px",
                                height: "70px",
                                borderRadius: "10%",
                                marginTop: "0px",
                            }}
                        />
                        <img
                            src="images/titulo_atalanta1.png"
                            alt="Logo Texto"
                            style={{
                                width: "110px",
                                height: "30px",
                                objectFit: "contain",
                                marginLeft: "-15px",
                                marginTop: "0px",
                            }}
                        />
                    </div>
                </Link>

                {/* Botón hamburguesa mobile */}
                <button
                    className="d-lg-none btn"
                    onClick={toggleMenu}
                    style={{
                        backgroundColor: "#ffffff",
                        borderColor: "#ffffff",
                    }}
                >
                    {isNavOpen ? (
                        <X color="#8a775a" size={24} />
                    ) : (
                        <Menu color="#8a775a" size={24} />
                    )}
                </button>
                {/* Menú mobile */}
                <div
                    className={`d-lg-none position-absolute top-100 start-0 w-100 ${
                        isNavOpen ? "d-block" : "d-none"
                    }`}
                    style={{
                        backgroundColor: "#ffffff",
                        borderRadius: "12px", // redondeado completo
                        marginTop: "0.5rem", // separación debajo del navbar
                        boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                        paddingBottom: "0", // <-- menos espacio abajo
                    }}
                >
                    <ul className="navbar-nav text-center p-0 mb-1">
                        <li className="nav-item">
                            <Link
                                to="/"
                                className="nav-link p-nosotros"
                                onClick={closeMenu}
                                style={{
                                    color: "#8a775a",
                                    fontFamily: "Inter, sans-serif",
                                }}
                            >
                                Inicio
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link
                                to="/contacto"
                                className="nav-link p-nosotros"
                                onClick={closeMenu}
                                style={{
                                    color: "#8a775a",
                                    fontFamily: "Inter, sans-serif",
                                }}
                            >
                                Contacto
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link
                                to="/proyecto"
                                className="nav-link p-nosotros"
                                onClick={closeMenu}
                                style={{
                                    color: "#8a775a",
                                    fontFamily: "Inter, sans-serif",
                                }}
                            >
                                Colaboraciones
                            </Link>
                        </li>
                        {/* Separador */}
                        <li
                            className="border-top"
                            style={{
                                borderColor: "#8a775a",
                                margin: "0.5rem auto", // centrado
                                width: "90%", // ocupa solo el 80% del ancho
                            }}
                        ></li>
                        {user ? (
                            <>
                                <li className="nav-item">
                                    <Link
                                        to="/profile"
                                        className="nav-link p-nosotros"
                                        onClick={closeMenu}
                                        style={{
                                            backgroundColor: "#ffffff",
                                            color: "#8a775a",
                                            borderColor: "#ffffff",
                                            fontSize: "16px",
                                            fontFamily: "Inter, sans-serif",
                                        }}
                                    >
                                        <User size={18} className="me-2" /> Ver
                                        perfil
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <button
                                        className="nav-link p-nosotros btn w-100 text-center"
                                        onClick={handleLogout}
                                        style={{
                                            backgroundColor: "#ffffff",
                                            color: "#8a775a",
                                            borderColor: "#ffffff",
                                            fontSize: "16px",
                                            fontFamily: "Inter, sans-serif",
                                        }}
                                    >
                                        <LogOut size={18} className="me-2" />{" "}
                                        Cerrar sesión
                                    </button>
                                </li>
                            </>
                        ) : (
                            <li className="nav-item">
                                <Link
                                    to="/login"
                                    className="nav-link p-nosotros"
                                    onClick={closeMenu}
                                    style={{
                                        color: "#ffffff",
                                        backgroundColor: "#8a775a",
                                        margin: "0.5rem auto", // centrado
                                        width: "90%",
                                        borderRadius: "12px 12px 12px 12px",
                                        fontFamily: "Inter, sans-serif",
                                    }}
                                >
                                    Iniciar Sesión
                                </Link>
                            </li>
                        )}
                    </ul>
                </div>

                {/* Menú desktop */}
                <div className="d-none d-lg-flex flex-grow-1 align-items-center">
                    {/* Enlaces a la izquierda */}
                    <ul className="navbar-nav d-flex flex-row">
                        <li className="nav-item px-2">
                            <Link
                                to="/"
                                className="nav-link p-nosotros"
                                onClick={closeMenu}
                                style={{
                                    color: "#ffffff",
                                    fontSize: "15px",
                                    marginTop: "5px",
                                    fontFamily: "Inter, sans-serif",
                                }}
                                onMouseEnter={(e) =>
                                    (e.currentTarget.style.color = "#d5d2d2")
                                }
                                onMouseLeave={(e) =>
                                    (e.currentTarget.style.color = "#ffffff")
                                }
                            >
                                Inicio
                            </Link>
                        </li>
                        <li className="nav-item px-2">
                            <Link
                                to="/contacto"
                                className="nav-link p-nosotros"
                                onClick={closeMenu}
                                style={{
                                    color: "#ffffff",
                                    fontSize: "15px",
                                    marginTop: "5px",
                                    fontFamily: "Inter, sans-serif",
                                }}
                                onMouseEnter={(e) =>
                                    (e.currentTarget.style.color = "#d5d2d2")
                                }
                                onMouseLeave={(e) =>
                                    (e.currentTarget.style.color = "#ffffff")
                                }
                            >
                                Contacto
                            </Link>
                        </li>
                        <li className="nav-item px-2">
                            <Link
                                to="/proyecto"
                                className="nav-link p-nosotros"
                                onClick={closeMenu}
                                style={{
                                    color: "#ffffff",
                                    fontSize: "15px",
                                    marginTop: "5px",
                                    fontFamily: "Inter, sans-serif",
                                }}
                                onMouseEnter={(e) =>
                                    (e.currentTarget.style.color = "#d5d2d2")
                                }
                                onMouseLeave={(e) =>
                                    (e.currentTarget.style.color = "#ffffff")
                                }
                            >
                                Colaboraciones
                            </Link>
                        </li>
                    </ul>

                    {/* Botón a la derecha */}
                    <div className="ms-auto">
                        {user ? (
                            <div className="dropdown">
                                <button
                                    className="btn p-nosotros btn-outline-primary dropdown-toggle rounded-2"
                                    data-bs-toggle="dropdown"
                                    style={{
                                        backgroundColor: "#ffffff",
                                        color: "#8a775a",
                                        borderColor: "#ffffff",
                                        fontSize: "12px",
                                        fontFamily: "Inter, sans-serif",
                                    }}
                                >
                                    <User size={18} className="me-2" />
                                    {user.name}
                                </button>
                                <ul
                                    className="dropdown-menu dropdown-menu-end"
                                    style={{
                                        backgroundColor: "#ffffff",
                                        color: "#8a775a",
                                        borderColor: "#ffffff",
                                        fontSize: "12px",
                                        fontFamily: "Inter, sans-serif",
                                    }}
                                >
                                    <li>
                                        <Link
                                            to="/profile"
                                            className="dropdown-item p-nosotros"
                                            style={{
                                                backgroundColor: "#ffffff",
                                                color: "#8a775a",
                                                borderColor: "#ffffff",
                                                fontSize: "12px",
                                                fontFamily: "Inter, sans-serif",
                                            }}
                                        >
                                            <User size={18} className="me-2" />{" "}
                                            Ver perfil
                                        </Link>
                                    </li>
                                    <li>
                                        <hr className="dropdown-divider" />
                                    </li>
                                    <li>
                                        <button
                                            className="dropdown-item p-nosotros"
                                            onClick={handleLogout}
                                            style={{
                                                backgroundColor: "#ffffff",
                                                color: "#8a775a",
                                                borderColor: "#ffffff",
                                                fontSize: "12px",
                                                fontFamily: "Inter, sans-serif",
                                            }}
                                        >
                                            <LogOut
                                                size={18}
                                                className="me-2"
                                            />{" "}
                                            Cerrar sesión
                                        </button>
                                    </li>
                                </ul>
                            </div>
                        ) : (
                            <Link
                                to="/login"
                                className="btn rounded-top-2 p-nosotros"
                                style={{
                                    backgroundColor: "rgba(255, 255, 255, 0.8)", // fondo blanco translúcido
                                    backdropFilter: "blur(12px)",
                                    WebkitBackdropFilter: "blur(12px)",
                                    color: "#8a775a", // texto marrón
                                    border: "1px solid rgba(255,255,255,0.5)", // borde sutil
                                    minWidth: "110px",
                                    textAlign: "center",
                                    fontSize: "12px",
                                    transition: "all 0.3s ease",
                                    fontFamily: "Inter, sans-serif",
                                }}
                                onMouseEnter={(e) => {
                                    e.currentTarget.style.backgroundColor =
                                        "rgba(255, 255, 255, 0.2)";
                                    e.currentTarget.style.color = "#ffffff";
                                }}
                                onMouseLeave={(e) => {
                                    e.currentTarget.style.backgroundColor =
                                        "rgba(255, 255, 255, 0.8)";
                                    e.currentTarget.style.color = "#8a775a";
                                }}
                            >
                                Iniciar Sesión
                            </Link>
                        )}
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Navbar;
