import React, { useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Users, MapPin, Star } from "lucide-react";

const Seccion1 = () => {
    const { pathname } = useLocation();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);

    const navigationCards = [
        {
            title: "Nosotros",
            iconClass: "fa-users",
            gradient: "#ffffff", // color sólido
            description: "",
            link: "/nosotros",
        },
        {
            title: "Experiencias",
            iconClass: "fa-earth-americas",
            gradient: "#ffffff",
            description: "",
            link: "/experiencias",
        },
        {
            title: "Blog",
            iconClass: "fa-pencil",
            gradient: "#ffffff",
            description: "",
            link: "/blogger",
        },
        {
            title: "Galería",
            iconClass: "fa-photo-film",
            gradient: "#ffffff",
            description: "",
            link: "/galeria",
        },
    ];

    useEffect(() => {
        // tu efecto de animación (no modificado)
    }, []);

    return (
        <section
            className="position-relative d-flex align-items-center u-section-1"
            id="sec-0609"
            style={{
                minHeight: "auto",
                paddingTop: "4rem",
                paddingBottom: "4rem",
            }}
        >
            {/* Wrapper para fondo e overlay */}
            <div
                className="position-absolute top-0 start-0 w-100 h-100"
                style={{ zIndex: 0, overflow: "visible" }}
            >
                <img
                    src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80"
                    alt="Paisaje de viaje"
                    className="w-100 h-100"
                    style={{ objectFit: "cover" }}
                />
            </div>
            <div
                className="position-absolute top-0 start-0 w-100 h-100"
                style={{
                    backgroundColor: "rgba(0, 0, 0, 0.4)", // negro translúcido
                }}
            ></div>
            {/* Floating Elements */}
            <div className="position-absolute top-0 start-0 w-100 h-100 overflow-hidden">
                <motion.div
                    animate={{ y: [0, -30, 0], rotate: [0, 10, 0] }}
                    transition={{
                        duration: 8,
                        repeat: Infinity,
                        ease: "easeInOut",
                    }}
                    style={{
                        position: "absolute",
                        top: "5rem",
                        left: "2.5rem",
                        width: "6rem",
                        height: "6rem",
                        backgroundColor: "rgba(239, 182, 106, 0.2)",
                        borderRadius: "50%",
                        filter: "blur(1rem)",
                        zIndex: 2,
                    }}
                />
            </div>

            <div
                className="container text-center position-relative px-3 px-md-5"
                style={{ zIndex: 2 }}
            >
                <motion.div
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.2, duration: 0.8 }}
                    className="text-center mb-5"
                >
                    <br />
                    <h1
                        className="fw-bold lh-tight titulo"
                        style={{
                            fontFamily:
                                '"TT Espina Trial Variable", sans-serif',
                            fontSize: "clamp(3rem, 8vw, 6.5rem)",
                            color: "#ffffff",
                            wordWrap: "break-word",
                        }}
                    >
                        Haz de cada aventura, una historia que contar
                    </h1>

                    <p
                        className="lead mx-auto"
                        style={{
                            maxWidth: "720px",
                            fontSize: "14pt",
                            color: "#ffffff",
                        }}
                    >
                        Viaja con la seguridad de quienes conocen el
                        camino&nbsp;
                    </p>

                    <p
                        className="lead mx-auto"
                        style={{
                            maxWidth: "720px",
                            fontSize: "14pt",
                            color: "#ffffff",
                        }}
                    >
                        Descúbrelo&nbsp;
                    </p>
                </motion.div>

                <motion.div
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.8, duration: 0.8 }}
                >
                    <div
                        className="d-flex flex-wrap justify-content-center"
                        style={{ gap: "1rem" }} // espacio entre tarjetas
                    >
                        {navigationCards.map(({ title, iconClass, link }) => (
                            <motion.div
                                key={title}
                                whileHover={{
                                    y: -8,
                                    transition: { duration: 0.3 },
                                }}
                            >
                                <Link
                                    to={link}
                                    style={{
                                        textDecoration: "none",
                                        display: "flex",
                                        flexDirection: "column",
                                    }}
                                >
                                    <div
                                        className="card text-center shadow-sm d-flex flex-column justify-content-center"
                                        style={{
                                            width: "230px", // ancho fijo
                                            aspectRatio: "1 / 1", // hace que alto = ancho
                                            padding: "1.5rem",
                                            background:
                                                "rgba(255,255,255,0.12)",
                                            backdropFilter: "blur(12px)",
                                            WebkitBackdropFilter: "blur(12px)",
                                            color: "#fff",
                                            borderRadius: "12px",
                                            boxShadow:
                                                "0 8px 24px rgb(0 0 0 / 0.2)",
                                            cursor: "pointer",
                                            transition: "all 0.3s ease",
                                        }}
                                    >
                                        <div
                                            style={{
                                                marginTop: "1rem", // ajustado para que el icono esté centrado verticalmente
                                                marginBottom: "0.8rem",
                                                fontSize: "2.25rem",
                                                filter: "drop-shadow(1px 1px 1px rgba(0,0,0,0.3))",
                                            }}
                                        >
                                            <i
                                                className={`fa-solid ${iconClass}`}
                                                style={{ fontSize: "2.5rem" }}
                                            ></i>
                                        </div>
                                        <h5
                                            className="fw-bold mb-1"
                                            style={{
                                                color: "inherit",
                                                wordWrap: "break-word",
                                                fontFamily: "Inter, sans-serif",
                                            }}
                                        >
                                            {title}
                                        </h5>
                                        <p
                                            style={{
                                                color: "inherit",
                                                fontSize: "0.875rem",
                                                marginTop: "0.25rem",
                                                wordWrap: "break-word",
                                            }}
                                        >
                                            {
                                                navigationCards.find(
                                                    (c) => c.title === title
                                                ).description
                                            }
                                        </p>
                                    </div>
                                </Link>
                            </motion.div>
                        ))}
                    </div>
                </motion.div>

                {/* Aquí añadimos el bloque debajo de los cuadros */}
                <br />
                <motion.div
                    initial={{ y: 30, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 1.5, duration: 0.8 }}
                    className="text-center mt-4"
                >
                    <Link
                        to="/experiencias"
                        className="btn me-3 rounded-top-2 rounded-bottom-2 p-nosotros"
                        style={{
                            backgroundColor: "rgba(255, 255, 255, 0.8)", // fondo blanco translúcido
                            backdropFilter: "blur(12px)",
                            WebkitBackdropFilter: "blur(12px)",
                            color: "#8a775a", // texto marrón
                            border: "1px solid rgba(255,255,255,0.5)", // borde sutil
                            transition: "all 0.3s ease", // suaviza hover
                        }}
                        onMouseEnter={(e) => {
                            e.currentTarget.style.backgroundColor =
                                "rgba(255, 255, 255, 0.2)";
                            e.currentTarget.style.color = "#ffffff";
                        }}
                        onMouseLeave={(e) => {
                            e.currentTarget.style.backgroundColor =
                                "rgba(255, 255, 255, 0.8)";
                            e.currentTarget.style.color = "#8a775a";
                        }}
                    >
                        RESERVAR AHORA
                    </Link>
                </motion.div>
            </div>
        </section>
    );
};

export default Seccion1;
