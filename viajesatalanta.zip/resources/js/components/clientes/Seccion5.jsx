import React, { useEffect, useRef } from "react";
import { Star, MapPin, Clock, Users } from "lucide-react";
import { useLocation } from "react-router-dom";

const Seccion5 = () => {
    const { pathname } = useLocation();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);

    const testimonials = [
        {
            id: 1,
            name: "María González",
            location: "México",
            image: "https://images.unsplash.com/photo-1643892055607-192cf75e93f3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaXNwYW5pYyUyMHdvbWFuJTIwc21pbGluZyUyMHBvcnRyYWl0JTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc1ODIxMTIzMnww&ixlib=rb-4.1.0&q=80&w=1080",
            rating: 5,
            comment:
                "Increíble experiencia en Machu Picchu. La organización fue perfecta y el guía muy profesional. Definitivamente volveré a contratar sus servicios.",
        },
        {
            id: 2,
            name: "Carlos Rodríguez",
            location: "España",
            image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
            rating: 5,
            comment:
                "El safari en Kenya superó todas mis expectativas. Cada detalle estaba cuidado al máximo. Una experiencia que recordaré toda la vida.",
        },
        {
            id: 3,
            name: "Ana Martínez",
            location: "Argentina",
            image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80",
            rating: 5,
            comment:
                "Las Maldivas fueron un sueño hecho realidad. La atención al cliente fue excepcional desde el primer momento. 100% recomendado.",
        },
    ];

    const sectionRef = useRef(null);

    const runAnimation = () => {
        const items = $("#sec-55f1 .col-12.col-md-6.col-lg-4");
        // Resetear estilos para que la animación pueda repetirse
        items.css({ opacity: 0, position: "relative", top: "40px" });

        items.each((i, el) => {
            $(el)
                .delay(i * 300) // retraso escalonado
                .animate({ opacity: 1, top: 0 }, 800, "swing");
        });
    };

    useEffect(() => {
        // Ejecutar animación inicialmente (opcional)
        //runAnimation();

        // Crear observer para detectar entrada en viewport
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        runAnimation();
                    }
                });
            },
            {
                threshold: 0.5, // cuando el 50% de la sección sea visible
            }
        );

        if (sectionRef.current) {
            observer.observe(sectionRef.current);
        }

        return () => {
            if (sectionRef.current) {
                observer.unobserve(sectionRef.current);
            }
        };
    }, []);

    return (
        <>
            <style>{`
        /* Móvil: imagen antes que texto */
        @media (max-width: 767.98px) {
          #sec-55f1 .img-col {
            order: 1 !important;
          }
          #sec-55f1 .text-col {
            order: 2 !important;
          }
        }

        /* Escritorio: invertir orden (texto arriba, imagen abajo) solo en columnas 2 y 4 */
        @media (min-width: 992px) {
          #sec-55f1 .col-2,
          #sec-55f1 .col-4 {
            flex-direction: column-reverse !important;
          }
        }
      `}</style>

            <section
                ref={sectionRef}
                className="text-center py-5"
                id="sec-55f1"
                style={{ backgroundColor: "#ffffff" }}
            >
                <div className="container">
                    {/* Título de la sección */}
                    <div className="text-center mb-5">
                        <h2
                            className="h1 fw-bold mb-3"
                            style={{ color: " #8a775a", fontFamily: "Inter, sans-serif", }}
                        >
                            Lo que Dicen Nuestros Viajeros
                        </h2>
                        <p
                            className="fs-5 mx-auto"
                            style={{ maxWidth: "700px", color: " #8a775a", fontFamily: "Inter, sans-serif", fontSize: "14pt" }}
                        >
                            Miles de aventureros han confiado en nosotros para
                            crear sus memorias más preciadas
                        </p>
                    </div>

                    {/* Grid de testimonios */}
                    <div className="row">
                        {testimonials.map((testimonial) => (
                            <div
                                className="col-12 col-md-6 col-lg-4 mb-4"
                                key={testimonial.id}
                            >
                                <div
                                    className="card h-100 shadow-sm border"
                                    style={{
                                        borderColor: "#e9dab64d",
                                        backgroundColor: " #8a775a",
                                    }}
                                >
                                    <div className="card-body p-4">
                                        {/* Estrellas */}
                                        <div className="d-flex align-items-center mb-3">
                                            {[...Array(testimonial.rating)].map(
                                                (_, i) => (
                                                    <Star
                                                        key={i}
                                                        size={16}
                                                        className="me-1"
                                                        style={{
                                                            fill: "#efb66a",
                                                            color: "#efb66a",
                                                        }}
                                                    />
                                                )
                                            )}
                                        </div>

                                        {/* Comentario */}
                                        <p
                                            className="fst-italic mb-4"
                                            style={{ color: "#ffffff", fontFamily: "Inter, sans-serif", fontSize: "14px" }}
                                        >
                                            "{testimonial.comment}"
                                        </p>

                                        <div className="d-flex align-items-center">
                                            <img
                                                src={testimonial.image}
                                                alt={testimonial.name}
                                                className="rounded-circle me-3"
                                                style={{
                                                    width: "48px",
                                                    height: "48px",
                                                    objectFit: "cover",
                                                    color: "#ffffff", fontFamily: "Inter, sans-serif", fontSize: "14px"
                                                }}
                                            />
                                            <div>
                                                <div
                                                    className="fw-medium"
                                                    style={{ color: "#ffffff", fontFamily: "Inter, sans-serif", fontSize: "14px"}}
                                                >
                                                    {testimonial.name}
                                                </div>
                                                <div
                                                    className="small"
                                                    style={{ color: "#ffffff", fontFamily: "Inter, sans-serif", fontSize: "14px" }}
                                                >
                                                    {testimonial.location}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </>
    );
};

export default Seccion5;
