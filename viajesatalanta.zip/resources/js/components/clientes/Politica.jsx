import { useEffect }  from "react";
import { Link, useLocation } from "react-router-dom";

const Politica = () => {
    const { pathname } = useLocation();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);

    return (
        <div
            className="min-vh-100 d-flex justify-content-center align-items-start"
            style={{
                backgroundColor: "#ffffff",
                paddingTop: "3rem",
                paddingBottom: "4rem",
                fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
            }}
        >
            <div
                className="col-12 col-md-10 col-lg-8 p-4 p-md-5 rounded-4 shadow-lg"
                style={{
                    backgroundColor: " #8a775a",
                    color: "#ffffff",
                    maxHeight: "90vh",
                    overflowY: "auto",
                    backdropFilter: "blur(6px)",
                    border: "none",
                }}
            >
                {/* Header */}
                <div className="text-center mb-5">
                    <div
                        className="rounded-circle d-inline-flex align-items-center justify-content-center mb-4"
                        style={{
                            background:
                                "linear-gradient(to right, #8a775a, #ffffff)",
                            borderRadius: "50%",
                            width: "80px",
                            height: "80px",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                        }}
                    >
                        <i
                            className="bi bi-shield-lock-fill"
                            style={{ fontSize: "40px", color: "#ffffff" }}
                        ></i>
                    </div>
                    <h2 style={{ fontWeight: "700", color: "#ffffff", fontSize:"40px" }}>
                        Política de Privacidad
                    </h2>
                    <p style={{ color: "#ffffff" , fontSize:"18px"}}>
                        Última actualización: 1 de enero de 2025
                    </p>
                </div>

                {/* Secciones de política */}
                {[
                    {
                        title: "1. Información que recopilamos",
                        content:
                            "Recopilamos datos personales que tú nos proporcionas directamente al registrarte, hacer una reserva o comunicarte con nosotros, incluyendo nombre, correo electrónico, dirección y detalles de pago.",
                    },
                    {
                        title: "2. Uso de la información",
                        content:
                            "Utilizamos tu información para procesar reservas, mejorar nuestros servicios, enviarte comunicaciones relevantes y cumplir con obligaciones legales.",
                    },
                    {
                        title: "3. Compartición de datos",
                        content:
                            "No vendemos ni alquilamos tu información personal. Podemos compartir datos con proveedores de servicios que nos ayudan a operar la plataforma, siempre bajo estrictas condiciones de confidencialidad.",
                    },
                    {
                        title: "4. Seguridad de los datos",
                        content:
                            "Implementamos medidas técnicas y organizativas para proteger tus datos contra accesos no autorizados, pérdida o alteración.",
                    },
                    {
                        title: "5. Tus derechos",
                        listItems: [
                            "Acceder a tus datos personales.",
                            "Solicitar la rectificación o eliminación de tus datos.",
                            "Oponerte al tratamiento o solicitar su limitación.",
                            "Solicitar la portabilidad de tus datos.",
                            "Retirar tu consentimiento en cualquier momento.",
                        ],
                    },
                    {
                        title: "6. Retención de datos",
                        content:
                            "Conservamos tus datos únicamente durante el tiempo necesario para cumplir con los fines para los que fueron recogidos o por exigencias legales.",
                    },
                    {
                        title: "7. Cookies y tecnologías similares",
                        content:
                            "Utilizamos cookies para mejorar la experiencia del usuario, analizar el tráfico y personalizar contenido. Puedes configurar tu navegador para bloquearlas o alertarte de su uso.",
                    },
                    {
                        title: "8. Menores de edad",
                        content:
                            "Nuestra plataforma no está destinada a menores de 18 años y no recopilamos conscientemente datos de menores.",
                    },
                    {
                        title: "9. Cambios en la política",
                        content:
                            "Podemos actualizar esta Política de Privacidad en cualquier momento. Publicaremos los cambios en esta página para que estés informado.",
                    },
                    {
                        title: "10. Contacto",
                        content: (
                            <>
                                Para consultas o ejercer tus derechos,
                                escríbenos a:{" "}
                                <a
                                    href="mailto:soporte@viajesatalanta.com"
                                    style={{
                                        color: "#2575fc",
                                        fontWeight: "600",
                                    }}
                                >
                                    soporte@viajesatalanta.com
                                </a>
                                .
                            </>
                        ),
                    },
                ].map(({ title, content, listItems }, i) => (
                    <section
                        key={i}
                        className="mb-4"
                        style={{ lineHeight: "1.6", color: "#ffffff" }}
                    >
                        <h5
                            style={{
                                fontWeight: "600",
                                marginBottom: "0.8rem",
                                color: "#ffffff",
                                fontSize:"18px"
                            }}
                        >
                            {title}
                        </h5>
                        {listItems ? (
                            <ul className="ms-3">
                                {listItems.map((item, idx) => (
                                    <li
                                        key={idx}
                                        style={{ marginBottom: "0.4rem", fontSize:"18px" }}
                                    >
                                        {item}
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p
                                style={{
                                    color: "#ffffff",
                                    fontSize:"16px"
                                }}
                            >
                                {content}
                            </p>
                        )}
                    </section>
                ))}

                {/* Botón */}
                <div className="text-center mt-5">
                    <Link
                        to="/login"
                        className="btn px-4 py-2"
                        style={{
                            backgroundColor: "rgba(255, 255, 255, 0.8)", // fondo translúcido
                            backdropFilter: "blur(12px)",
                            WebkitBackdropFilter: "blur(12px)",
                            color: "#8a775a", // texto marrón
                            border: "1px solid rgba(255,255,255,0.5)", // borde sutil
                            fontWeight: "600",
                            fontSize: "12px",
                            minWidth: "110px",
                            textAlign: "center",
                            transition: "all 0.3s ease",
                            fontFamily: "Inter, sans-serif",
                        }}
                        onMouseEnter={(e) => {
                            e.currentTarget.style.backgroundColor =
                                "rgba(255, 255, 255, 0.2)";
                            e.currentTarget.style.color = "#ffffff";
                        }}
                        onMouseLeave={(e) => {
                            e.currentTarget.style.backgroundColor =
                                "rgba(255, 255, 255, 0.8)";
                            e.currentTarget.style.color = "#8a775a";
                        }}
                    >
                        Entendido, volver al login
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default Politica;
