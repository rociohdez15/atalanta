import React, { useEffect, useState, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import axios from "axios";
import { MapPin, Clock, Users } from "lucide-react";

const Seccion3 = () => {
    const [experiencias, setExperiencias] = useState([]);
    const [error, setError] = useState(null);
    const sectionRef = useRef(null);

    const { pathname } = useLocation();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);

    useEffect(() => {
        axios
            .get(`/api/paquetes/ultimos`)
            .then((res) => {
                const paquetesConPlazas = res.data.content.filter(
                    (exp) => exp.plazas > 0
                );
                setExperiencias(paquetesConPlazas);
            })
            .catch(() => setError("No se pudieron cargar las experiencias"));
    }, []);

    useEffect(() => {
        if (experiencias.length === 0 || !window.$) return;

        const sectionEl = sectionRef.current;
        if (!sectionEl) return;

        const runAnimation = () => {
            const $cards = window.$(sectionEl).find(".card-item");

            $cards.css({
                opacity: 0,
                position: "relative",
                bottom: "-50px",
            });

            $cards.each(function (index) {
                const $card = window.$(this);
                setTimeout(() => {
                    $card.animate(
                        {
                            opacity: 1,
                            bottom: 0,
                        },
                        700,
                        "swing"
                    );
                }, index * 200);
            });
        };

        // Ejecutar animación al cargar
        runAnimation();

        // Observer para volver a ejecutar si entra en viewport otra vez
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        runAnimation();
                    }
                });
            },
            {
                threshold: 0.5,
            }
        );

        observer.observe(sectionEl);

        return () => {
            observer.disconnect();
        };
    }, [experiencias]);

    if (error) return <p className="text-center text-danger">{error}</p>;

    return (
        <section
            ref={sectionRef}
            className="u-align-center u-clearfix u-container-align-center u-palette-2-base u-section-3 py-5"
            id="sec-4bf5"
            style={{ backgroundColor: "#ffffff" }}
        >
            <div className="container">
                <br />
                <div className="text-center mb-5">
                    <h2
                        className="display-5 fw-bold"
                        style={{ color: " #8a775a", fontFamily: "Inter, sans-serif", }}
                    >
                        Encuentra tu Próxima Aventura
                    </h2>
                    <p
                        className="fs-5 p-nosotros"
                        style={{ color: " #8a775a", fontFamily: "Inter, sans-serif", fontSize: "14pt",}}
                    >
                        Descubre nuestras experiencias más populares diseñadas
                        para brindarte momentos inolvidables
                    </p>
                </div>
                {experiencias.length < 0 ==
                    "No hay paquetes disponibles en este momento"}
                {/* Grid de experiencias */}
                <div className="row">
                    {experiencias.map((exp) => {
                        const urlImagen = `/storage/paquetes/portada/${exp.id}/${exp.foto}`;
                        const fechaInicio = new Date(exp.fecha_inicio);
                        const fechaFin = new Date(exp.fecha_fin);
                        const duracionDias = Math.ceil(
                            (fechaFin - fechaInicio) / (1000 * 60 * 60 * 24)
                        );
                        return (
                            <div
                                className="col-md-6 col-lg-4 mb-4 card-item"
                                key={exp.id}
                            >
                                <div
                                    className="card h-100 shadow-sm border-0 rounded-4"
                                    style={{ backgroundColor: "  #8a775a" }}
                                >
                                    <div className="position-relative ">
                                        <img
                                            src={urlImagen}
                                            alt={exp.nombre}
                                            className="card-img-top border-0 rounded-top rounded-top-4"
                                            style={{
                                                height: "200px", // altura fija para todas las imágenes
                                                objectFit: "cover", // recorta la imagen para que ocupe todo el espacio sin deformar
                                                width: "100%", // ocupa todo el ancho de la card
                                            }}
                                        />
                                        <div
                                            className="position-absolute top-0 end-0 m-3 px-3 py-1 rounded-pill fw-semibold"
                                            style={{
                                                backgroundColor: "#ffffff",
                                                color: " #8a775a",
                                                fontFamily: "Inter, sans-serif",
                                                fontSize: "12px"
                                            }}
                                        >
                                            Desde {exp.precio} €
                                        </div>
                                    </div>
                                    <div className="card-body text-start">
                                        <h5
                                            className="card-title fw-bold mb-2 mt-5"
                                            style={{
                                                lineHeight: "0",
                                                color: "#ffffff",
                                                textAlign: "center",
                                                fontFamily: "Inter, sans-serif",
                                            }}
                                        >
                                            {exp.nombre}
                                        </h5>
                                        <p
                                            className="card-text"
                                            style={{
                                                color: "#ffffff",
                                                textAlign: "center",
                                                fontFamily: "Inter, sans-serif",
                                                fontSize: "14px"
                                            }}
                                        >
                                            {exp.descripcion}
                                        </p>
                                        <ul className="list-unstyled mt-3 mb-4 ">
                                            <li className="mb-2 d-flex align-items-center" style={{fontSize: "14px"}}>
                                                <MapPin
                                                    size={16}
                                                    className="me-2 text-primary"
                                                    style={{
                                                        stroke: "#ffffff",
                                                        fontFamily: "Inter, sans-serif",
                                                        fontSize: "14px"
                                                    }}
                                                />
                                                {exp.lugar}
                                            </li>
                                            <li className="mb-2 d-flex align-items-center" style={{fontSize: "14px"}}>
                                                <Clock
                                                    size={16}
                                                    className="me-2 text-primary"
                                                    style={{
                                                        stroke: "#ffffff",
                                                        fontFamily: "Inter, sans-serif",
                                                        fontSize: "14px"
                                                    }}
                                                />
                                                {duracionDias} días
                                            </li>
                                            <li className="d-flex align-items-center" style={{fontSize: "14px"}}>
                                                <Users
                                                    size={16}
                                                    className="me-2 text-primary"
                                                    style={{
                                                        stroke: "#ffffff",
                                                        fontFamily: "Inter, sans-serif",
                                                        fontSize: "14px"
                                                    }}
                                                />
                                                {exp.plazas} plazas
                                            </li>
                                        </ul>
                                        <Link
                                            to={`/experiencia/${exp.id}`}
                                            className="btn btn-dark w-100"
                                            style={{
                                                backgroundColor:
                                                    "rgba(255, 255, 255, 0.8)", // fondo blanco translúcido
                                                backdropFilter: "blur(12px)",
                                                WebkitBackdropFilter:
                                                    "blur(12px)",
                                                color: "#8a775a", // texto marrón
                                                border: "1px solid rgba(255,255,255,0.5)", // borde sutil
                                                minWidth: "110px",
                                                textAlign: "center",
                                                fontSize: "12px",
                                                transition: "all 0.3s ease",
                                                fontFamily: "Inter, sans-serif",
                                            }}
                                            onMouseEnter={(e) => {
                                                e.currentTarget.style.backgroundColor =
                                                    "rgba(255, 255, 255, 0.2)";
                                                e.currentTarget.style.color =
                                                    "#ffffff";
                                            }}
                                            onMouseLeave={(e) => {
                                                e.currentTarget.style.backgroundColor =
                                                    "rgba(255, 255, 255, 0.8)";
                                                e.currentTarget.style.color =
                                                    "#8a775a";
                                            }}
                                        >
                                            Ver Detalles
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
                {/* Botón "Ver todos" */}
                <div className="text-center mt-4">
                    <Link
                        to="/experiencias"
                        className="btn btn-lg"
                        style={{ backgroundColor:"#8a775a", color: " #ffffff", borderColor: " #ffffff", fontSize: "12px", fontFamily: "Inter, sans-serif", }}
                    >
                        Ver Todas las Experiencias
                    </Link>
                </div>
            </div>
        </section>
    );
};

export default Seccion3;
