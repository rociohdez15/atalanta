import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import axios from "axios";
import {
    ArrowLeft,
    MapPin,
    Calendar,
    ChevronRight,
    ChevronLeft,
} from "lucide-react";
import { motion } from "framer-motion";
import { X } from "phosphor-react";

const Galeria = () => {
    const [imagenes, setImagenes] = useState([]);
    const [pagina, setPagina] = useState(0);
    const [totalPaginas, setTotalPaginas] = useState(0);
    const tamañoPagina = 6;
    const [selectedItem, setSelectedItem] = useState(null);

    const { pathname } = useLocation();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [pathname]);

    useEffect(() => {
        axios
            .get(`/api/imagenes?page=${pagina}&size=${tamañoPagina}`)
            .then((res) => {
                setImagenes(res.data.content);
                setTotalPaginas(res.data.totalPages);
            });
    }, [pagina]);
    return (
        <div className="container py-5">
            <div className="mb-4">
                <button
                    type="button"
                    onClick={() => (window.location.href = "/")}
                    className="btn btn-link d-flex align-items-center mb-4"
                    style={{
                        transition:
                            "color 0.3s ease, background-color 0.3s ease",
                        textDecoration: "none", // quita el subrayado
                        boxShadow: "none", // quita cualquier sombra por defecto
                        color: " #8a775a",
                        fontFamily: "Inter, sans-serif",
                        fontSize: "10pt",
                    }}
                    onMouseEnter={(e) => {
                        e.currentTarget.style.color = " #8a775a";
                        e.currentTarget.style.backgroundColor =
                            "rgba(53, 55, 46, 0.1)";
                        e.currentTarget.style.textDecoration = "none";
                        e.currentTarget.style.boxShadow = "none";
                    }}
                    onMouseLeave={(e) => {
                        e.currentTarget.style.color = " #8a775a";
                        e.currentTarget.style.backgroundColor = "transparent";
                        e.currentTarget.style.textDecoration = "none";
                        e.currentTarget.style.boxShadow = "none";
                    }}
                >
                    <ArrowLeft size={20} className="me-2" />
                    Volver al inicio
                </button>
                <br />
            </div>
            <motion.div
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.8 }}
                className="text-center mb-16"
            >
                <h1
                    className="text-center fw-bold"
                    style={{
                        marginTop: "-120px",
                        color: " #8a775a",
                        fontFamily: '"TT Espina Trial Variable", sans-serif',
                        fontSize: "clamp(2rem, 5vw, 4rem)",
                        transform: "scaleX(1.5)", // 1.0 es normal, >1 estira
                        display: "inline-block",
                    }}
                >
                    Galería
                </h1>
            </motion.div>

            <motion.div
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4, duration: 0.8 }}
                className="container my-5" // <-- Espaciado vertical general
            >
                {Array.from(
                    { length: Math.ceil(imagenes.length / 3) },
                    (_, fila) => (
                        <motion.div
                            key={fila}
                            initial={{ y: 50, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            transition={{
                                delay: 0.4 + fila * 0.2,
                                duration: 0.8,
                            }}
                            className="row justify-content-center g-4 mb-4" // <-- Espacio entre filas
                        >
                            {imagenes
                                .slice(fila * 3, fila * 3 + 3)
                                .map((img, index) => (
                                    <motion.div
                                        key={img.id}
                                        initial={{
                                            y: 50,
                                            opacity: 0,
                                            scale: 0.9,
                                        }}
                                        animate={{ y: 0, opacity: 1, scale: 1 }}
                                        transition={{
                                            delay: 0.6 + index * 0.05,
                                            duration: 0.6,
                                        }}
                                        whileHover={{ y: -10 }}
                                        className="col-12 col-sm-6 col-lg-4 col-xl-3"
                                    >
                                        <div
                                            className="bg-light rounded-3 shadow overflow-hidden position-relative"
                                            style={{
                                                backgroundColor: " #8a775a",
                                            }}
                                        >
                                            {/* Imagen con efecto hover de zoom */}
                                            <motion.div
                                                whileHover={{ scale: 1.05 }}
                                                transition={{ duration: 0.6 }}
                                                className="ratio"
                                                style={{
                                                    aspectRatio: "4 / 3",
                                                    overflow: "hidden",
                                                }} // <-- Imagen menos larga
                                            >
                                                <img
                                                    src={`/storage/uploads/images/${img.imagen}`}
                                                    alt={img.titulo}
                                                    className="w-100 h-100 object-fit-cover"
                                                />
                                            </motion.div>

                                            {/* Overlay inferior (si se desea usar con animación futura) */}
                                            <div
                                                className="position-absolute bottom-0 start-0 end-0 p-3 text-white overlay-gradient"
                                                style={{
                                                    transform:
                                                        "translateY(100%)",
                                                    transition:
                                                        "transform 0.3s ease",
                                                }}
                                            >
                                                <h5
                                                    className="fw-bold text-truncate"
                                                    style={{
                                                        fontFamily:
                                                            "Inter, sans-serif",
                                                    }}
                                                >
                                                    {img.titulo}
                                                </h5>
                                                <div className="small">
                                                    <div className="d-flex align-items-center mb-1">
                                                        <MapPin
                                                            size={14}
                                                            className="me-2 flex-shrink-0"
                                                        />
                                                        <span
                                                            className="text-truncate"
                                                            style={{
                                                                fontFamily:
                                                                    "Inter, sans-serif",
                                                                fontSize:
                                                                    "10pt",
                                                            }}
                                                        >
                                                            {img.ubicacion}
                                                        </span>
                                                    </div>
                                                    <div className="d-flex align-items-center">
                                                        <Calendar
                                                            size={14}
                                                            className="me-2 flex-shrink-0"
                                                        />
                                                        <span
                                                            style={{
                                                                fontFamily:
                                                                    "Inter, sans-serif",
                                                                fontSize:
                                                                    "10pt",
                                                            }}
                                                        >
                                                            {new Date(
                                                                img.fecha
                                                            ).toLocaleDateString(
                                                                "en-CA"
                                                            )}{" "}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>

                                            {/* Contenido debajo de la imagen */}
                                            <div
                                                className="p-3 text-dark"
                                                style={{
                                                    backgroundColor: " #8a775a",
                                                }}
                                            >
                                                <h5
                                                    className="fw-bold text-truncate"
                                                    style={{
                                                        fontSize: "15px",
                                                        color: "#ffffff",
                                                    }}
                                                >
                                                    {img.titulo}
                                                </h5>
                                                <div className="mb-3 small text-muted">
                                                    <div className="d-flex align-items-center mb-1">
                                                        <MapPin
                                                            size={14}
                                                            className="me-2"
                                                            style={{
                                                                color: " #ffffff",
                                                            }}
                                                        />
                                                        <span
                                                            className="text-truncate"
                                                            style={{
                                                                marginTop:
                                                                    "-1px",
                                                                color: "#ffffff",
                                                            }}
                                                        >
                                                            {img.ubicacion}
                                                        </span>
                                                    </div>
                                                    <div className="d-flex align-items-center">
                                                        <Calendar
                                                            size={14}
                                                            className="me-2"
                                                            style={{
                                                                color: " #ffffff",
                                                            }}
                                                        />
                                                        <span
                                                            style={{
                                                                marginTop:
                                                                    "-1px",
                                                                color: "#ffffff",
                                                            }}
                                                        >
                                                            {new Date(
                                                                img.fecha
                                                            ).toLocaleDateString(
                                                                "en-CA"
                                                            )}{" "}
                                                        </span>
                                                    </div>
                                                </div>

                                                <button
                                                    type="button"
                                                    className="btn w-100 border-opacity-30 rounded-top-2"
                                                    style={{
                                                        backgroundColor:
                                                            "rgba(255, 255, 255, 0.8)", // fondo blanco translúcido
                                                        backdropFilter:
                                                            "blur(12px)",
                                                        WebkitBackdropFilter:
                                                            "blur(12px)",
                                                        color: "#8a775a", // texto marrón
                                                        border: "1px solid rgba(255,255,255,0.5)", // borde sutil
                                                        minWidth: "110px",
                                                        textAlign: "center",
                                                        fontSize: "12px",
                                                        transition:
                                                            "all 0.3s ease",
                                                        fontFamily:
                                                            "Inter, sans-serif",
                                                    }}
                                                    onMouseEnter={(e) => {
                                                        e.currentTarget.style.backgroundColor =
                                                            "rgba(255, 255, 255, 0.2)";
                                                        e.currentTarget.style.color =
                                                            "#ffffff";
                                                    }}
                                                    onMouseLeave={(e) => {
                                                        e.currentTarget.style.backgroundColor =
                                                            "rgba(255, 255, 255, 0.8)";
                                                        e.currentTarget.style.color =
                                                            "#8a775a";
                                                    }}
                                                    onClick={() =>
                                                        setSelectedItem(img)
                                                    }
                                                >
                                                    Ver Detalles y Mapa
                                                </button>
                                            </div>
                                        </div>
                                    </motion.div>
                                ))}
                        </motion.div>
                    )
                )}
            </motion.div>

            {selectedItem && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="modal show d-flex align-items-center justify-content-center"
                    style={{
                        display: "block",
                        backgroundColor: "rgba(0,0,0,0.8)",
                        zIndex: 1050,
                    }}
                    onClick={() => setSelectedItem(null)}
                >
                    <motion.div
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.8, opacity: 0 }}
                        className="modal-dialog modal-dialog-centered"
                        onClick={(e) => e.stopPropagation()}
                        style={{
                            maxHeight: "70vh",
                            overflowY: "auto",
                            maxWidth: "40vw",
                            width: "40vw",
                        }}
                    >
                        <div
                            className="modal-content rounded-4 p-3"
                            style={{ backgroundColor: " #8a775a" }}
                        >
                            {/* Header */}
                            <div className="position-relative">
                                <img
                                    src={`/storage/uploads/images/${selectedItem.imagen}`}
                                    alt={selectedItem?.titulo || "Imagen"}
                                    className="img-fluid rounded-4"
                                    style={{
                                        height: "20rem",
                                        objectFit: "cover",
                                        width: "100%",
                                        marginTop: "60px",
                                    }}
                                />
                                <button
                                    type="button"
                                    className="btn position-absolute top-0 end-0 m-2 rounded-circle shadow-sm"
                                    onClick={() => setSelectedItem(null)}
                                    aria-label="Close modal"
                                    style={{
                                        width: "32px",
                                        height: "32px",
                                        padding: 0,
                                        backgroundColor: "#ffffff",
                                        color: " #8a775a",
                                    }}
                                >
                                    <X size={16} />
                                </button>
                                <div
                                    className="position-absolute bottom-0 start-0 p-4 text-white"
                                    style={{
                                        textShadow: "0 0 4px rgba(0,0,0,0.7)",
                                    }}
                                >
                                    <h4
                                        className="fw-bold"
                                        style={{ fontSize: "1.1rem" }}
                                    >
                                        {selectedItem?.titulo || "Sin título"}
                                    </h4>
                                    <div
                                        className="d-flex gap-2"
                                        style={{ fontSize: "0.85rem" }}
                                    >
                                        <div className="d-flex align-items-center">
                                            <MapPin
                                                size={14}
                                                className="me-1"
                                            />
                                            {selectedItem?.ubicacion ||
                                                "Sin ubicación"}
                                        </div>
                                        <div className="d-flex align-items-center">
                                            <Calendar
                                                size={14}
                                                className="me-1"
                                            />
                                            {new Date(
                                                selectedItem?.fecha
                                            ).toLocaleDateString("en-CA")}{" "}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Content */}
                            <div className="modal-body p-2">
                                <h5
                                    className="fw-bold mb-3"
                                    style={{
                                        color: "#ffffff",
                                        fontFamily: "Inter, sans-serif",
                                    }}
                                >
                                    Ubicación en el Mapa
                                </h5>

                                {/* Embedded Map */}
                                <div
                                    className="mb-3 shadow rounded-3 overflow-hidden"
                                    style={{ height: "200px" }}
                                >
                                    <iframe
                                        src={`https://www.google.com/maps?q=${encodeURIComponent(
                                            selectedItem?.coordenadas
                                                ? `${selectedItem.coordenadas.lat},${selectedItem.coordenadas.lng}`
                                                : selectedItem?.ubicacion || ""
                                        )}&output=embed`}
                                        width="100%"
                                        height="200"
                                        style={{ border: 0 }}
                                        allowFullScreen
                                        loading="lazy"
                                        referrerPolicy="no-referrer-when-downgrade"
                                        title={`Mapa de ${
                                            selectedItem?.titulo || "Ubicación"
                                        }`}
                                    />
                                </div>

                                {/* Location Details */}
                                <div
                                    className="p-3 rounded-3"
                                    style={{
                                        background: "#ffffff",
                                        fontSize: "0.9rem",
                                    }}
                                >
                                    <h6 className="fw-bold text-dark mb-2" style={{ fontFamily: "Inter, sans-serif"}}>
                                        Información del Destino
                                    </h6>
                                    <div className="row text-secondary small">
                                        <div className="col-6 mb-1">
                                            <span className="fw-semibold text-dark" style={{ fontFamily: "Inter, sans-serif"}}>
                                                Ubicación:
                                            </span>{" "}
                                            <span className="" style={{ fontFamily: "Inter, sans-serif"}}>
                                                {selectedItem?.ubicacion ||
                                                    "Sin ubicación"}
                                            </span>
                                        </div>
                                        <div className="col-6 mb-1">
                                            <span className="fw-semibold text-dark" style={{ fontFamily: "Inter, sans-serif"}}>
                                                Fecha:
                                            </span>{" "}
                                            <span className="" style={{ fontFamily: "Inter, sans-serif"}}>
                                                {new Date(
                                                    selectedItem?.fecha
                                                ).toLocaleDateString(
                                                    "en-CA"
                                                )}{" "}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                </motion.div>
            )}

            <motion.div
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1, duration: 0.8 }}
                className="d-flex justify-content-center align-items-center gap-3 flex-wrap my-5"
            >
                {/* Botón Anterior */}
                <button
                    className="btn d-flex align-items-center px-4 py-2 rounded-pill"
                    style={{
                        backgroundColor: "#8a775a",
                        color: "#ffffff",
                        border: "none",
                    }}
                    onClick={() => setPagina(Math.max(pagina - 1, 0))}
                    disabled={pagina <= 0}
                >
                    <ChevronLeft size={18} className="me-2" />
                </button>

                {/* Botones números página */}
                {Array.from({ length: totalPaginas }, (_, index) => (
                    <button
                        key={index}
                        onClick={() => setPagina(index)}
                        className="btn rounded-circle d-flex align-items-center justify-content-center p-0"
                        style={{
                            width: "40px",
                            height: "40px",
                            backgroundColor:
                                index === pagina ? " #5c503eff" : "#8a775a", // claro si activo, oscuro si no
                            color: index === pagina ? "#ffffff" : "#ffffff", // texto oscuro si activo, claro si no
                            border: "none",
                            transition: "all 0.3s",
                            cursor: "pointer",
                        }}
                    >
                        {index + 1}
                    </button>
                ))}

                {/* Botón Siguiente */}
                <button
                    className="btn d-flex align-items-center px-4 py-2 rounded-pill"
                    style={{
                        backgroundColor: "#8a775a",
                        color: "#ffffff",
                        border: "none",
                    }}
                    onClick={() =>
                        setPagina(Math.min(pagina + 1, totalPaginas - 1))
                    }
                    disabled={pagina >= totalPaginas - 1}
                >
                    <ChevronRight size={18} className="ms-2" />
                </button>
            </motion.div>
        </div>
    );
};

export default Galeria;
