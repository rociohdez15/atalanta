import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";

const ReservasCliente = () => {
    const navigate = useNavigate();
    const { id } = useParams(); // suponiendo que id viene de la ruta

    const handleRowClick = (id) => {
        navigate(`/factura-reserva/${id}`);
    };

    const [currentPage, setCurrentPage] = useState(1);
    const [entriesPerPage] = useState(10);

    const [reservas, setReservas] = useState([]);
    const [reservasFiltradas, setReservasFiltradas] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");

    // Cargar reservas del cliente
    useEffect(() => {

        axios
            .get(`/api/reservas/cliente/${id}`)
            .then((res) => {
                if (Array.isArray(res.data)) {
                    setReservas(res.data);
                    setReservasFiltradas(res.data);
                } else if (res.data) {
                    setReservas([res.data]);
                    setReservasFiltradas([res.data]);
                } else {
                    setReservas([]);
                    setReservasFiltradas([]);
                }
            })
            .catch((err) => {
                console.error(
                    ""
                );
                Swal.fire({
                    icon: "error",
                    title: "Error al cargar reservas",
                    text: err.message || "No se pudo obtener la información.",
                });
            });
    }, [id]);

    // Búsqueda en reservas (por ejemplo por reservation_token o estado)
    useEffect(() => {

        const delayDebounce = setTimeout(() => {
            if (searchTerm.trim() === "") {
                setReservasFiltradas(reservas);
                return;
            }

            // Filtrado local: aquí puedes filtrar por campos que quieras
            const filtered = reservas.filter((r) => {
                const token = r.reservation_token || "";
                const estado = r.estado || "";
                return (
                    token.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    estado.toLowerCase().includes(searchTerm.toLowerCase())
                );
            });

            setReservasFiltradas(filtered);
        }, 300);

        return () => clearTimeout(delayDebounce);
    }, [searchTerm, reservas]);

    const indexOfLast = currentPage * entriesPerPage;
    const indexOfFirst = indexOfLast - entriesPerPage;
    const currentReservations = reservasFiltradas.slice(
        indexOfFirst,
        indexOfLast
    );

    const paginate = (pageNumber) => {
        setCurrentPage(pageNumber);
    };

    const pageNumbers = [];
    for (
        let i = 1;
        i <= Math.ceil(reservasFiltradas.length / entriesPerPage);
        i++
    ) {
        pageNumbers.push(i);
    }

const handleDownload = async (reservaId) => {

    try {
        const token = sessionStorage.getItem("token") || localStorage.getItem("token");
        if (!token) {
            alert("No hay token de autenticación, por favor inicia sesión.");
            return;
        }

        const response = await fetch(`/api/factura/${reservaId}/${id}`, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });

        if (!response.ok) {
            const errorData = await response.json();
            alert(`Error: ${errorData.error || "No se pudo descargar la factura"}`);
            return;
        }

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", `factura_reserva_${reservaId}.pdf`);
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.URL.revokeObjectURL(url);
    } catch (error) {
        alert("No se pudo descargar la factura.");
    }
};



    return (
        // ... resto del componente igual ...
        <div className="content-page">
            <div className="content">
                {/* Start Content */}
                <div className="container-fluid">
                    {/* page title */}
                    <div className="row">
                        <div className="col-12">
                            <div className="page-title-box">
                                <h4 className="page-title text-center">
                                    Reservas del cliente {id}
                                </h4>
                            </div>
                        </div>
                    </div>

                    {/* Tabla reservas */}
                    <div className="container-fluid p-3">
                        <div className="d-flex justify-content-end mb-3">
                            <label htmlFor="searchInput" className="me-2 mb-0">
                                Buscar:
                            </label>
                            <input
                                id="searchInput"
                                type="search"
                                className="form-control form-control-sm"
                                style={{ width: 150 }}
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>

                        <div className="table-responsive">
                            <table className="table table-sm align-middle mb-0 bordered-table">
                                <thead>
                                    <tr className="text-secondary text-nowrap">
                                        <th>ID</th>
                                        <th>Reservation Token</th>
                                        <th>Cliente ID</th>
                                        <th>Paquete ID</th>
                                        <th>Num Personas</th>
                                        <th>Fecha Pago</th>
                                        <th>Tipo Pago</th>
                                        <th>Descuento</th>
                                        <th>Estado</th>
                                        <th>Num Cuotas</th>
                                        <th>Importe Cuotas</th>
                                        <th>Total Precio</th>
                                        <th>Fecha Reserva</th>
                                        <th>Operaciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {currentReservations.length > 0 ? (
                                        currentReservations.map((reserva) => (
                                            <tr
                                                key={reserva.id}
                                            >
                                                <td>{reserva.id}</td>
                                                <td>
                                                    {reserva.reservation_token}
                                                </td>
                                                <td>{reserva.cliente_id}</td>
                                                <td>{reserva.paquete_id}</td>
                                                <td>{reserva.num_personas}</td>
                                                <td>
                                                    {reserva.fecha_pago
                                                        ? new Date(
                                                              reserva.fecha_pago
                                                          ).toLocaleDateString(
                                                              "en-CA"
                                                          )
                                                        : ""}
                                                </td>
                                                <td>{reserva.metodo_pago === 'parcial' ? 'Parcial' : reserva.metodo_pago === 'total' ? 'Total' : reserva.metodo_pago}</td>
                                                <td>{reserva.descuento}</td>
                                                <td>{reserva.estado}</td>
                                                <td>{reserva.num_cuotas}</td>
                                                <td>
                                                    {reserva.importe_cuotas}
                                                </td>
                                                <td>{reserva.total_precio}</td>
                                                <td>
                                                    {reserva.fecha_reserva
                                                        ? new Date(
                                                              reserva.fecha_reserva
                                                          ).toLocaleDateString(
                                                              "en-CA"
                                                          )
                                                        : ""}
                                                </td>
                                                <td>
                                                    <button
                                                        className="btn btn-primary btn-sm"
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleDownload(
                                                                reserva.id
                                                            );
                                                        }}
                                                        title="Descargar factura"
                                                    >
                                                        <i className="fas fa-file-download"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr>
                                            <td
                                                colSpan="14"
                                                className="text-center text-muted"
                                            >
                                                No se encontraron reservas.
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>

                        {/* Paginación */}
                        <div
                            className="d-flex justify-content-center align-items-center mt-3 text-secondary"
                            style={{ fontSize: "0.75rem" }}
                        >
                            <nav aria-label="Page navigation example">
                                <ul className="pagination mb-0">
                                    <li className="page-item">
                                        <button
                                            className="page-link"
                                            aria-label="Previous"
                                            onClick={() =>
                                                setCurrentPage(currentPage - 1)
                                            }
                                            disabled={currentPage === 1}
                                        >
                                            <i className="fas fa-chevron-left" />
                                        </button>
                                    </li>
                                    {pageNumbers.map((number) => (
                                        <li
                                            key={number}
                                            className={`page-item ${
                                                number === currentPage
                                                    ? "active"
                                                    : ""
                                            }`}
                                        >
                                            <button
                                                className="page-link"
                                                onClick={() => paginate(number)}
                                            >
                                                {number}
                                            </button>
                                        </li>
                                    ))}
                                    <li className="page-item">
                                        <button
                                            className="page-link"
                                            aria-label="Next"
                                            onClick={() =>
                                                setCurrentPage(currentPage + 1)
                                            }
                                            disabled={
                                                currentPage ===
                                                pageNumbers.length
                                            }
                                        >
                                            <i className="fas fa-chevron-right" />
                                        </button>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            {/* Footer */}
            <footer className="footer">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-12 text-center">
                            2025 © Atalanta
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    );
};

export default ReservasCliente;
