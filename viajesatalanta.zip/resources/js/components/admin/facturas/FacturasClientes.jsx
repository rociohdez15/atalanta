import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";

const Principal = () => {
    const navigate = useNavigate();

    const handleRowClick = (id) => {
        navigate(`/factura-cliente/${id}`);
    };

    const [currentPage, setCurrentPage] = useState(1);
    const [entriesPerPage] = useState(10);

    const [clientes, setClientes] = useState([]);
    const [clientesFiltrados, setClientesFiltrados] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");

    useEffect(() => {
        axios
            .get("/api/clientes/obtener-clientes")
            .then((res) => {
                const data = Array.isArray(res.data) ? res.data : [res.data];
                setClientes(data);
                setClientesFiltrados(data);
            });
    }, []);

    useEffect(() => {
        const delayDebounce = setTimeout(() => {
            if (searchTerm.trim() === "") {
                setClientesFiltrados(clientes);
                return;
            }

            axios
                .get(
                    `/api/clientes/buscar?input=${encodeURIComponent(
                        searchTerm
                    )}`
                )
                .then((res) => {
                    const data = Array.isArray(res.data)
                        ? res.data
                        : [res.data];
                    setClientesFiltrados(data);
                });
        }, 300);

        return () => clearTimeout(delayDebounce);
    }, [searchTerm, clientes]);

    const indexOfLastClient = currentPage * entriesPerPage;
    const indexOfFirstClient = indexOfLastClient - entriesPerPage;
    const currentClients = clientesFiltrados.slice(
        indexOfFirstClient,
        indexOfLastClient
    );

    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    const pageNumbers = [];
    for (
        let i = 1;
        i <= Math.ceil(clientesFiltrados.length / entriesPerPage);
        i++
    ) {
        pageNumbers.push(i);
    }

    const handleDelete = (id) => {
        Swal.fire({
            title: "¿Eliminar cliente?",
            text: "Esta acción no se puede deshacer.",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#d33",
            cancelButtonColor: "#3085d6",
            confirmButtonText: "Sí, eliminar",
            cancelButtonText: "Cancelar",
        }).then((result) => {
            if (result.isConfirmed) {
                axios
                    .delete(`/api/clientes/eliminar/${id}`)
                    .then(() => {
                        setClientes((prev) => prev.filter((c) => c.id !== id));
                        setClientesFiltrados((prev) =>
                            prev.filter((c) => c.id !== id)
                        );
                        Swal.fire(
                            "Eliminado",
                            "El cliente ha sido eliminado correctamente.",
                            "success"
                        );
                    })
                    .catch((err) => {
                        Swal.fire(
                            "Error",
                            "No se pudo eliminar el cliente.",
                            "error"
                        );
                    });
            }
        });
    };

    return (
        <div className="content-page">
            <div className="content">
                {/* Start Content*/}
                <div className="container-fluid">
                    {/* start page title */}
                    <div className="row">
                        <div className="col-12">
                            <div className="page-title-box">
                                <h4 className="page-title text-center">
                                    Listado de Clientes
                                </h4>
                            </div>
                        </div>
                    </div>

                    {/* Tabla Facturas o Usuarios (según datos) */}
                    <div className="container-fluid p-3">
                        <div className="d-flex flex-column flex-md-row justify-content-between align-items-center mb-3">
                            <div className="d-flex align-items-center mb-2 mb-md-0"></div>
                            <div className="d-flex align-items-center">
                                <label
                                    htmlFor="searchInput"
                                    className="me-2 mb-0"
                                >
                                    Buscar:
                                </label>
                                <input
                                    id="searchInput"
                                    type="search"
                                    className="form-control form-control-sm"
                                    style={{ width: 150 }}
                                    value={searchTerm}
                                    onChange={(e) =>
                                        setSearchTerm(e.target.value)
                                    }
                                />
                            </div>
                        </div>
                        <div className="table-responsive">
                            <table className="table table-sm align-middle mb-0 bordered-table">
                                <thead>
                                    <tr className="text-secondary text-nowrap">
                                        <th scope="col" className="text-start">
                                            ID
                                        </th>
                                        <th scope="col" className="text-start">
                                            Usuario ID
                                        </th>
                                        <th scope="col" className="text-start">
                                            Nombre
                                        </th>
                                        <th scope="col" className="text-start">
                                            Apellidos
                                        </th>
                                        <th scope="col" className="text-start">
                                            DNI
                                        </th>
                                        <th scope="col" className="text-start">
                                            Dirección
                                        </th>
                                        <th scope="col" className="text-start">
                                            Teléfono
                                        </th>
                                        <th scope="col" className="text-start">
                                            Fecha Nac.
                                        </th>
                                        <th scope="col" className="text-start">
                                            Operaciones
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {currentClients.length > 0 ? (
                                        currentClients.map((item) => (
                                            <tr
                                                key={item.id}
                                                onClick={() =>
                                                    handleRowClick(item.id)
                                                }
                                                style={{
                                                    cursor: "pointer",
                                                    position: "relative",
                                                    backgroundColor:
                                                        item.is_read
                                                            ? "transparent"
                                                            : "#f2f2f2",
                                                }}
                                            >
                                                <td>{item.id}</td>
                                                <td>{item.usuario_id}</td>
                                                <td>{item.nombre}</td>
                                                <td>{item.apellidos}</td>
                                                <td>{item.dni}</td>
                                                <td>{item.direccion}</td>
                                                <td>{item.telefono}</td>
                                                <td>
                                                    {new Date(
                                                        item.fecha_nacimiento
                                                    ).toLocaleDateString(
                                                        "en-CA"
                                                    )}
                                                </td>
                                                <td>
                                                    <button
                                                        className="btn btn-success btn-sm"
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleDelete(
                                                                item.id
                                                            );
                                                        }}
                                                    >
                                                        <i className="fas fa-trash-alt"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr>
                                            <td
                                                colSpan="9"
                                                className="text-center text-muted"
                                            >
                                                No se encontraron resultados.
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                        <div
                            className="d-flex justify-content-center align-items-center mt-3 text-secondary"
                            style={{ fontSize: "0.75rem" }}
                        >
                            <nav aria-label="Page navigation example">
                                <ul className="pagination mb-0">
                                    <li className="page-item">
                                        <button
                                            className="page-link"
                                            aria-label="Previous"
                                            onClick={() =>
                                                setCurrentPage(currentPage - 1)
                                            }
                                            disabled={currentPage === 1}
                                        >
                                            <i className="fas fa-chevron-left" />
                                        </button>
                                    </li>
                                    {pageNumbers.map((number) => (
                                        <li
                                            key={number}
                                            className={`page-item ${
                                                number === currentPage
                                                    ? "active"
                                                    : ""
                                            }`}
                                        >
                                            <button
                                                className="page-link"
                                                onClick={() => paginate(number)}
                                            >
                                                {number}
                                            </button>
                                        </li>
                                    ))}
                                    <li className="page-item">
                                        <button
                                            className="page-link"
                                            aria-label="Next"
                                            onClick={() =>
                                                setCurrentPage(currentPage + 1)
                                            }
                                            disabled={
                                                currentPage ===
                                                pageNumbers.length
                                            }
                                        >
                                            <i className="fas fa-chevron-right" />
                                        </button>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                {/* container */}
            </div>
            {/* content */}
            {/* Footer Start */}
            <footer className="footer">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-12 text-center">
                            2025 © Atalanta
                        </div>
                    </div>
                </div>
            </footer>
            {/* end Footer */}
        </div>
    );
};

export default Principal;
