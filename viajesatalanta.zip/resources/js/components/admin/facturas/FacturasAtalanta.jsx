import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Swal from "sweetalert2";

const Principal = () => {

    const [currentPage, setCurrentPage] = useState(1);
    const [entriesPerPage] = useState(10);

    const [facturas, setFacturas] = useState([]);
    const [facturasFiltradas, setFacturasFiltradas] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");

    useEffect(() => {
        axios
            .get("/api/facturas")
            .then((res) => {
                const data = Array.isArray(res.data) ? res.data : [res.data];
                setFacturas(data);
                setFacturasFiltradas(data);
            });
    }, []);


    const indexOfLastItem = currentPage * entriesPerPage;
    const indexOfFirstItem = indexOfLastItem - entriesPerPage;
    const currentClients = facturasFiltradas.slice(
        indexOfFirstItem,
        indexOfLastItem
    );

    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    const pageNumbers = [];
    for (
        let i = 1;
        i <= Math.ceil(facturasFiltradas.length / entriesPerPage);
        i++
    ) {
        pageNumbers.push(i);
    }

    const handleDelete = (id) => {
        Swal.fire({
            title: "¿Eliminar factura?",
            text: "Esta acción no se puede deshacer.",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#d33",
            cancelButtonColor: "#3085d6",
            confirmButtonText: "Sí, eliminar",
            cancelButtonText: "Cancelar",
        }).then((result) => {
            if (result.isConfirmed) {
                axios
                    .delete(`/api/facturas/eliminar/${id}`)
                    .then(() => {
                        setFacturas((prev) => prev.filter((f) => f.id !== id));
                        setFacturasFiltradas((prev) =>
                            prev.filter((f) => f.id !== id)
                        );
                        Swal.fire(
                            "Eliminado",
                            "La factura ha sido eliminada correctamente.",
                            "success"
                        );
                    })
                    .catch((err) => {
                        console.error("Error al eliminar:", err);
                        Swal.fire(
                            "Error",
                            "No se pudo eliminar la factura.",
                            "error"
                        );
                    });
            }
        });
    };

    const handleDownload = async (facturaId) => {
        try {
            const token =
                sessionStorage.getItem("token") ||
                localStorage.getItem("token");
            if (!token) {
                alert(
                    "No hay token de autenticación, por favor inicia sesión."
                );
                return;
            }

            const responsePdf = await fetch(
                `/api/factura/${facturaId}`,
                {
                    method: "GET",
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );

            if (!responsePdf.ok) {
                const errorData = await responsePdf.json();
                alert(
                    `Error al descargar la factura: ${
                        errorData.error || "Error desconocido"
                    }`
                );
                return;
            }

            const blob = await responsePdf.blob();
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = url;
            link.setAttribute("download", `factura_reserva_${facturaId}.pdf`);
            document.body.appendChild(link);
            link.click();
            link.remove();
            window.URL.revokeObjectURL(url);
        } catch (error) {
            console.error("Error en la descarga:", error);
            alert("No se pudo descargar la factura.");
        }
    };

    return (
        <div className="content-page">
            <div className="content">
                {/* Start Content*/}
                <div className="container-fluid">
                    {/* start page title */}
                    <div className="row">
                        <div className="col-12">
                            <div className="page-title-box">
                                <h4 className="page-title text-center">
                                    Listado de Facturas
                                </h4>
                            </div>
                        </div>
                    </div>

                    {/* Tabla Facturas o Usuarios (según datos) */}
                    <div className="container-fluid p-3">
                        
                        <div className="table-responsive">
                            <table className="table table-sm align-middle mb-0 bordered-table">
                                <thead>
                                    <tr className="text-secondary text-nowrap">
                                        <th scope="col" className="text-start">
                                            ID
                                        </th>
                                        <th scope="col" className="text-start">
                                            Cliente ID
                                        </th>
                                        <th scope="col" className="text-start">
                                            Reserva ID
                                        </th>
                                        <th scope="col" className="text-start">
                                            Nombre Cliente
                                        </th>
                                        <th scope="col" className="text-start">
                                            Email Cliente
                                        </th>
                                        <th scope="col" className="text-start">
                                            Fecha Compra
                                        </th>
                                        <th scope="col" className="text-start">
                                            Tipo Pago
                                        </th>
                                        <th scope="col" className="text-start">
                                            Precio Total
                                        </th>
                                        <th scope="col" className="text-start">
                                            IVA
                                        </th>
                                        <th scope="col" className="text-start">
                                            Teléfono Empresa
                                        </th>
                                        <th scope="col" className="text-start">
                                            Email Empresa
                                        </th>
                                        <th scope="col" className="text-start">
                                            Detalles
                                        </th>
                                        <th scope="col" className="text-start">
                                            Operaciones
                                        </th>
                                        {/* Nueva columna */}
                                    </tr>
                                </thead>
                                <tbody>
                                    {currentClients.length > 0 ? (
                                        currentClients.map((item) => (
                                            <tr key={item.id}>
                                                <td>{item.id}</td>
                                                <td>{item.cliente_id}</td>
                                                <td>{item.reserva_id}</td>
                                                <td>{item.nombre_cliente}</td>
                                                <td>{item.email_cliente}</td>
                                                <td>
                                                    {new Date(
                                                        item.fecha_compra
                                                    ).toLocaleDateString(
                                                        "en-CA"
                                                    )}
                                                </td>
                                                <td>
                                                    {item.metodo_pago ===
                                                    "parcial"
                                                        ? "Parcial"
                                                        : item.metodo_pago ===
                                                          "total"
                                                        ? "Total"
                                                        : item.metodo_pago}
                                                </td>
                                                <td>{item.precio_total} €</td>
                                                <td>{item.iva} %</td>
                                                <td>{item.telefono_empresa}</td>
                                                <td>{item.email_empresa}</td>
                                                <td>{item.detalles}</td>
                                                <td>
                                                    <button
                                                        className="btn btn-primary btn-sm"
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleDownload(
                                                                item.id
                                                            );
                                                        }}
                                                        title="Descargar factura"
                                                    >
                                                        <i className="fas fa-file-download"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr>
                                            <td
                                                colSpan="14"
                                                className="text-center text-muted"
                                            >
                                                No se encontraron resultados.
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                        <div
                            className="d-flex justify-content-center align-items-center mt-3 text-secondary"
                            style={{ fontSize: "0.75rem" }}
                        >
                            <nav aria-label="Page navigation example">
                                <ul className="pagination mb-0">
                                    <li className="page-item">
                                        <button
                                            className="page-link"
                                            aria-label="Previous"
                                            onClick={() =>
                                                setCurrentPage(currentPage - 1)
                                            }
                                            disabled={currentPage === 1}
                                        >
                                            <i className="fas fa-chevron-left" />
                                        </button>
                                    </li>
                                    {pageNumbers.map((number) => (
                                        <li
                                            key={number}
                                            className={`page-item ${
                                                number === currentPage
                                                    ? "active"
                                                    : ""
                                            }`}
                                        >
                                            <button
                                                className="page-link"
                                                onClick={() => paginate(number)}
                                            >
                                                {number}
                                            </button>
                                        </li>
                                    ))}
                                    <li className="page-item">
                                        <button
                                            className="page-link"
                                            aria-label="Next"
                                            onClick={() =>
                                                setCurrentPage(currentPage + 1)
                                            }
                                            disabled={
                                                currentPage ===
                                                pageNumbers.length
                                            }
                                        >
                                            <i className="fas fa-chevron-right" />
                                        </button>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                {/* container */}
            </div>
            {/* content */}
            {/* Footer Start */}
            <footer className="footer">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-12 text-center">
                            2025 © Atalanta
                        </div>
                    </div>
                </div>
            </footer>
            {/* end Footer */}
        </div>
    );
};

export default Principal;
