import React, { useState } from "react";
import axios from "axios";
import Swal from "sweetalert2";

const CrearPaquete = () => {
    const [nombre, setNombre] = useState("");
    const [fechaInicio, setFechaInicio] = useState("");
    const [fechaFin, setFechaFin] = useState("");
    const [precio, setPrecio] = useState("");
    const [tipoViaje, setTipoViaje] = useState("");
    const [descripcion, setDescripcion] = useState("");
    const [foto, setFoto] = useState(null);
    const [previewFotos, setPreviewFotos] = useState([]);
    const [plazas, setPlazas] = useState("");
    const [error, setError] = useState("");

    const [serviciosIncluidos, setServiciosIncluidos] = useState([""]);
    const [serviciosNoIncluidos, setServiciosNoIncluidos] = useState([""]);

    const [galeria, setGaleria] = useState(Array(6).fill(null));
    const [previewGaleria, setPreviewGaleria] = useState(Array(6).fill(null));

    const [puntosMapa, setPuntosMapa] = useState([
        { nombre: "", latitud: "", longitud: "", descripcion: "" },
    ]);

    const [itinerario, setItinerario] = useState([
        { dia: 1, fecha: "", descripcion: "" },
    ]);

    const handleFotosChange = (e) => {
        const file = e.target.files[0];
        if (!file) {
            setFoto(null);
            setPreviewFotos([]);
            return;
        }
        if (!file.type.startsWith("image/")) {
            setError("Solo puedes subir archivos de imagen.");
            setFoto(null);
            setPreviewFotos([]);
            return;
        }
        setError("");
        setFoto(file);
        setPreviewFotos([URL.createObjectURL(file)]);
    };

    const handleGaleriaChange = (index, file) => {
        const nuevasImagenes = [...galeria];
        nuevasImagenes[index] = file;
        setGaleria(nuevasImagenes);

        const nuevasPrevias = [...previewGaleria];
        nuevasPrevias[index] = file ? URL.createObjectURL(file) : null;
        setPreviewGaleria(nuevasPrevias);
    };

    const agregarServicioIncluido = () => {
        setServiciosIncluidos([...serviciosIncluidos, ""]);
    };
    const cambiarServicioIncluido = (index, valor) => {
        const nuevos = [...serviciosIncluidos];
        nuevos[index] = valor;
        setServiciosIncluidos(nuevos);
    };
    const eliminarServicioIncluido = (index) => {
        const nuevos = serviciosIncluidos.filter((_, i) => i !== index);
        setServiciosIncluidos(nuevos.length ? nuevos : [""]);
    };

    const agregarServicioNoIncluido = () => {
        setServiciosNoIncluidos([...serviciosNoIncluidos, ""]);
    };
    const cambiarServicioNoIncluido = (index, valor) => {
        const nuevos = [...serviciosNoIncluidos];
        nuevos[index] = valor;
        setServiciosNoIncluidos(nuevos);
    };
    const eliminarServicioNoIncluido = (index) => {
        const nuevos = serviciosNoIncluidos.filter((_, i) => i !== index);
        setServiciosNoIncluidos(nuevos.length ? nuevos : [""]);
    };

    // MAPA: Funciones
    const cambiarPuntoMapa = (index, campo, valor) => {
        const nuevos = [...puntosMapa];
        nuevos[index][campo] = valor;
        setPuntosMapa(nuevos);
    };

    const agregarPuntoMapa = () => {
        setPuntosMapa([
            ...puntosMapa,
            {
                nombre: "",
                latitud: "",
                longitud: "",
                descripcion: "",
            },
        ]);
    };

    const eliminarPuntoMapa = (index) => {
        const nuevos = [...puntosMapa];
        nuevos.splice(index, 1);
        setPuntosMapa(
            nuevos.length
                ? nuevos
                : [
                      {
                          nombre: "",
                          latitud: "",
                          longitud: "",
                          descripcion: "",
                      },
                  ]
        );
    };

    // Funciones para manejar itinerario
    const cambiarItinerario = (index, campo, valor) => {
        const nuevos = [...itinerario];
        nuevos[index][campo] = valor;
        setItinerario(nuevos);
    };

    const agregarItinerario = () => {
        setItinerario([
            ...itinerario,
            { dia: itinerario.length + 1, fecha: "", descripcion: "" },
        ]);
    };

    const eliminarItinerario = (index) => {
        const nuevos = [...itinerario];
        nuevos.splice(index, 1);
        setItinerario(nuevos.length ? nuevos : [{ dia: 1, fecha: "", descripcion: "" }]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const serviciosIncluidosValidos = serviciosIncluidos.filter(
            (s) => s.trim() !== ""
        );
        const serviciosNoIncluidosValidos = serviciosNoIncluidos.filter(
            (s) => s.trim() !== ""
        );
        const puntosMapaValidos = puntosMapa.filter(
            (p) =>
                p.nombre.trim() &&
                p.latitud.trim() &&
                p.longitud.trim() &&
                p.descripcion.trim()
        );

         const itinerarioValidos = itinerario.filter(
            (item) => item.dia && item.fecha.trim() && item.descripcion.trim()
        );

         // Validaciones nuevas
        if (itinerarioValidos.length === 0) {
            setError("Debe añadir al menos un día válido en el itinerario.");
            return;
        }

        if (
            !nombre.trim() ||
            !fechaInicio ||
            !fechaFin ||
            !precio ||
            !tipoViaje.trim() ||
            !descripcion.trim() ||
            !foto ||
            !plazas ||
            galeria.some((img) => img === null)
        ) {
            setError(
                "Todos los campos son obligatorios y debe subir las 6 imágenes de la galería."
            );
            return;
        }

        if (new Date(fechaFin) < new Date(fechaInicio)) {
            setError("La fecha fin debe ser posterior a la fecha inicio.");
            return;
        }

        if (serviciosIncluidosValidos.length === 0) {
            setError("Debe añadir al menos un servicio incluido.");
            return;
        }

        if (serviciosNoIncluidosValidos.length === 0) {
            setError("Debe añadir al menos un servicio no incluido.");
            return;
        }

        if (puntosMapaValidos.length === 0) {
            setError("Debe añadir al menos un punto válido en el mapa.");
            return;
        }

        setError("");

        const formData = new FormData();
        formData.append("nombre", nombre);
        formData.append("fecha_inicio", fechaInicio);
        formData.append("fecha_fin", fechaFin);
        formData.append("precio", precio);
        formData.append("tipo_viaje", tipoViaje);
        formData.append("descripcion", descripcion);
        formData.append("plazas", plazas);
        formData.append("foto", foto);

        galeria.forEach((img) => {
            formData.append("galeria[]", img);
        });

        serviciosIncluidosValidos.forEach((s) =>
            formData.append("servicios_incluidos[]", s.trim())
        );
        serviciosNoIncluidosValidos.forEach((s) =>
            formData.append("servicios_no_incluidos[]", s.trim())
        );

        puntosMapaValidos.forEach((punto, index) => {
            formData.append(`puntos_mapa[${index}][nombre]`, punto.nombre);
            formData.append(`puntos_mapa[${index}][latitud]`, punto.latitud);
            formData.append(`puntos_mapa[${index}][longitud]`, punto.longitud);
            formData.append(
                `puntos_mapa[${index}][descripcion]`,
                punto.descripcion
            );
        });

        // Añadimos itinerario
        itinerarioValidos.forEach((item, index) => {
            formData.append(`itinerario[${index}][dia]`, item.dia);
            formData.append(`itinerario[${index}][fecha]`, item.fecha);
            formData.append(`itinerario[${index}][descripcion]`, item.descripcion);
        });

        try {
            const response = await axios.post(
                "/api/paquetes/agregar",
                formData,
                {
                    headers: { "Content-Type": "multipart/form-data" },
                }
            );

            if (response.status === 200 || response.status === 201) {
                Swal.fire({
                    icon: "success",
                    title: "Paquete creado",
                    text: `El paquete "${nombre}" se ha creado correctamente.`,
                    confirmButtonColor: "#28a745",
                });

                // Limpiar campos
                setNombre("");
                setFechaInicio("");
                setFechaFin("");
                setPrecio("");
                setTipoViaje("");
                setDescripcion("");
                setFoto(null);
                setPreviewFotos([]);
                setPlazas("");
                setServiciosIncluidos([""]);
                setServiciosNoIncluidos([""]);
                setGaleria(Array(6).fill(null));
                setPreviewGaleria(Array(6).fill(null));
                setPuntosMapa([
                    { nombre: "", latitud: "", longitud: "", descripcion: "" },
                ]);

                setItinerario([{ dia: "", fecha: "", descripcion: "" }]); // reseteo itinerario
            }
        } catch (error) {
            if (error.response && error.response.data.errors) {
                Swal.fire({
                    icon: "error",
                    title: "Error de validación",
                    html: Object.values(error.response.data.errors)
                        .flat()
                        .join("<br>"),
                    confirmButtonColor: "#d33",
                });
            } else {
                Swal.fire({
                    icon: "error",
                    title: "Error",
                    text: "Hubo un problema al crear el paquete. Inténtalo de nuevo.",
                    confirmButtonColor: "#d33",
                });
            }
        }
    };

    return (
        <div className="content-page">
            <div className="content">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-12">
                            <div className="page-title-box">
                                <h4 className="page-title text-center">
                                    Crear Experiencia
                                </h4>
                            </div>
                        </div>
                    </div>

                    <div
                        className="bg-white p-5 rounded-5 shadow-lg col-12 col-md-12 col-lg-10 mx-auto"
                        style={{ maxWidth: "1000px" }}
                    >
                        {error && (
                            <div className="alert alert-danger">{error}</div>
                        )}

                        <form
                            onSubmit={handleSubmit}
                            encType="multipart/form-data"
                        >
                            {/* Campos existentes */}
                            <label className="form-label fw-bold text-center d-block fs-3">
                                Experiencia
                            </label>

                            <div className="mb-3">
                                <label htmlFor="nombre" className="form-label">
                                    Nombre
                                </label>
                                <input
                                    type="text"
                                    id="nombre"
                                    className="form-control"
                                    value={nombre}
                                    onChange={(e) => setNombre(e.target.value)}
                                    required
                                />
                            </div>

                            <div className="row">
                                <div className="col-md-6 mb-3">
                                    <label
                                        htmlFor="fechaInicio"
                                        className="form-label"
                                    >
                                        Fecha Inicio
                                    </label>
                                    <input
                                        type="date"
                                        id="fechaInicio"
                                        className="form-control"
                                        value={fechaInicio}
                                        onChange={(e) =>
                                            setFechaInicio(e.target.value)
                                        }
                                        required
                                    />
                                </div>
                                <div className="col-md-6 mb-3">
                                    <label
                                        htmlFor="fechaFin"
                                        className="form-label"
                                    >
                                        Fecha Fin
                                    </label>
                                    <input
                                        type="date"
                                        id="fechaFin"
                                        className="form-control"
                                        value={fechaFin}
                                        onChange={(e) =>
                                            setFechaFin(e.target.value)
                                        }
                                        required
                                    />
                                </div>
                            </div>

                            <div className="mb-3">
                                <label htmlFor="precio" className="form-label">
                                    Precio (€)
                                </label>
                                <input
                                    type="number"
                                    id="precio"
                                    className="form-control"
                                    min="0"
                                    step="0.01"
                                    value={precio}
                                    onChange={(e) => setPrecio(e.target.value)}
                                    required
                                />
                            </div>

                            <div className="mb-3">
                                <label
                                    htmlFor="tipoViaje"
                                    className="form-label"
                                >
                                    Tipo de viaje
                                </label>
                                <input
                                    type="text"
                                    id="tipoViaje"
                                    className="form-control"
                                    value={tipoViaje}
                                    onChange={(e) =>
                                        setTipoViaje(e.target.value)
                                    }
                                    required
                                />
                            </div>

                            <div className="mb-3">
                                <label
                                    htmlFor="descripcion"
                                    className="form-label"
                                >
                                    Descripción
                                </label>
                                <textarea
                                    id="descripcion"
                                    className="form-control"
                                    rows="4"
                                    value={descripcion}
                                    onChange={(e) =>
                                        setDescripcion(e.target.value)
                                    }
                                    required
                                ></textarea>
                            </div>

                            <div className="mb-3">
                                <label className="form-label" htmlFor="foto">
                                    Foto de Portada
                                </label>
                                <input
                                    type="file"
                                    id="foto"
                                    className="form-control"
                                    accept="image/*"
                                    onChange={handleFotosChange}
                                    required
                                />
                            </div>

                            {previewFotos.length > 0 && (
                                <div className="mb-3 d-flex flex-wrap gap-2">
                                    {previewFotos.map((src, index) => (
                                        <img
                                            key={index}
                                            src={src}
                                            alt={`Previsualización ${
                                                index + 1
                                            }`}
                                            style={{
                                                maxWidth: "150px",
                                                maxHeight: "150px",
                                                borderRadius: "8px",
                                            }}
                                        />
                                    ))}
                                </div>
                            )}

                            <div className="mb-3">
                                <label htmlFor="plazas" className="form-label">
                                    Plazas
                                </label>
                                <input
                                    type="number"
                                    id="plazas"
                                    className="form-control"
                                    min="1"
                                    value={plazas}
                                    onChange={(e) => setPlazas(e.target.value)}
                                    required
                                />
                            </div>

                            {/* NUEVA SECCIÓN - Servicios Incluidos */}
                            <div className="mb-4">
                                <label className="form-label fw-bold text-center d-block fs-3">
                                    Servicios
                                </label>
                                <label className="form-label fw-bold">
                                    Servicios incluidos
                                </label>
                                {serviciosIncluidos.map((servicio, index) => (
                                    <div
                                        key={index}
                                        className="input-group mb-2"
                                    >
                                        <input
                                            type="text"
                                            className="form-control"
                                            placeholder={`Servicio incluido #${
                                                index + 1
                                            }`}
                                            value={servicio}
                                            onChange={(e) =>
                                                cambiarServicioIncluido(
                                                    index,
                                                    e.target.value
                                                )
                                            }
                                        />
                                        <button
                                            type="button"
                                            className="btn btn-outline-danger btn-sm"
                                            onClick={() =>
                                                eliminarServicioIncluido(index)
                                            }
                                            aria-label="Eliminar servicio incluido"
                                        >
                                            &times;
                                        </button>
                                    </div>
                                ))}
                                <button
                                    type="button"
                                    className="btn btn-outline-primary"
                                    onClick={agregarServicioIncluido}
                                >
                                    + Añadir servicio incluido
                                </button>
                            </div>

                            {/* NUEVA SECCIÓN - Servicios No Incluidos */}
                            <div className="mb-4">
                                <label className="form-label fw-bold">
                                    Servicios no incluidos
                                </label>
                                {serviciosNoIncluidos.map((servicio, index) => (
                                    <div
                                        key={index}
                                        className="input-group mb-2"
                                    >
                                        <input
                                            type="text"
                                            className="form-control"
                                            placeholder={`Servicio no incluido #${
                                                index + 1
                                            }`}
                                            value={servicio}
                                            onChange={(e) =>
                                                cambiarServicioNoIncluido(
                                                    index,
                                                    e.target.value
                                                )
                                            }
                                        />
                                        <button
                                            type="button"
                                            className="btn btn-outline-danger btn-sm"
                                            onClick={() =>
                                                eliminarServicioNoIncluido(
                                                    index
                                                )
                                            }
                                            aria-label="Eliminar servicio no incluido"
                                        >
                                            &times;
                                        </button>
                                    </div>
                                ))}
                                <button
                                    type="button"
                                    className="btn btn-outline-primary"
                                    onClick={agregarServicioNoIncluido}
                                >
                                    + Añadir servicio no incluido
                                </button>
                            </div>

                            {/* NUEVA SECCIÓN - Galería de imágenes */}
                            <div className="mb-4">
                                <label className="form-label fw-bold text-center d-block fs-3">
                                    Galería (6 imágenes)
                                </label>
                                {galeria.map((img, index) => {
                                    let sizeText = "";
                                    if ([0].includes(index))
                                        sizeText = "(300px ancho X 500px alto)";
                                    if ([1, 2, 4, 5].includes(index))
                                        sizeText = "(300px ancho X 120px alto)";
                                    if (index === 3)
                                        sizeText = "(600px ancho X 180px alto)";

                                    return (
                                        <div key={index} className="mb-3">
                                            <label className="form-label">
                                                Imagen {index + 1}{" "}
                                                <span className="text-muted">
                                                    {sizeText}
                                                </span>
                                            </label>
                                            <input
                                                type="file"
                                                className="form-control"
                                                accept="image/*"
                                                onChange={(e) =>
                                                    handleGaleriaChange(
                                                        index,
                                                        e.target.files[0]
                                                    )
                                                }
                                                required
                                            />
                                            {previewGaleria[index] && (
                                                <img
                                                    src={previewGaleria[index]}
                                                    alt={`Vista previa ${
                                                        index + 1
                                                    }`}
                                                    style={{
                                                        maxWidth: "150px",
                                                        maxHeight: "150px",
                                                        marginTop: "10px",
                                                        borderRadius: "8px",
                                                    }}
                                                />
                                            )}
                                        </div>
                                    );
                                })}
                            </div>

                            {/* NUEVA SECCIÓN - Puntos del Mapa */}
                            <div className="mb-4">
                                <label className="form-label fw-bold text-center d-block fs-3">
                                    Puntos del Mapa
                                </label>
                                {puntosMapa.map((punto, index) => (
                                    <div
                                        key={index}
                                        className="mb-3 border rounded p-3"
                                    >
                                        <label className="form-label fw-bold">
                                            Punto #{index + 1}
                                        </label>
                                        <input
                                            type="text"
                                            className="form-control mb-2"
                                            placeholder="Nombre del lugar"
                                            value={punto.nombre}
                                            onChange={(e) =>
                                                cambiarPuntoMapa(
                                                    index,
                                                    "nombre",
                                                    e.target.value
                                                )
                                            }
                                        />
                                        <input
                                            type="text"
                                            className="form-control mb-2"
                                            placeholder="Latitud"
                                            value={punto.latitud}
                                            onChange={(e) =>
                                                cambiarPuntoMapa(
                                                    index,
                                                    "latitud",
                                                    e.target.value
                                                )
                                            }
                                        />
                                        <input
                                            type="text"
                                            className="form-control mb-2"
                                            placeholder="Longitud"
                                            value={punto.longitud}
                                            onChange={(e) =>
                                                cambiarPuntoMapa(
                                                    index,
                                                    "longitud",
                                                    e.target.value
                                                )
                                            }
                                        />
                                        <textarea
                                            className="form-control mb-2"
                                            placeholder="Ubicación (Nombre, ej: Madrid)"
                                            value={punto.descripcion}
                                            onChange={(e) =>
                                                cambiarPuntoMapa(
                                                    index,
                                                    "descripcion",
                                                    e.target.value
                                                )
                                            }
                                            rows={2}
                                        ></textarea>
                                        <button
                                            type="button"
                                            className="btn btn-outline-danger btn-sm"
                                            onClick={() =>
                                                eliminarPuntoMapa(index)
                                            }
                                        >
                                            &times; Eliminar punto
                                        </button>
                                    </div>
                                ))}
                                <button
                                    type="button"
                                    className="btn btn-outline-success"
                                    onClick={agregarPuntoMapa}
                                >
                                    + Añadir punto del mapa
                                </button>
                            </div>

                            {/* NUEVA SECCIÓN - Itinerario */}
                            <div className="mb-4">
                                <label className="form-label fw-bold text-center d-block fs-3">
                                    Itinerario
                                </label>
                                {itinerario.map((item, index) => (
                                    <div
                                        key={index}
                                        className="mb-3 border rounded p-3"
                                    >
                                        <label className="form-label fw-bold">
                                            Día 
                                        </label>

                                        <input
                                            type="text"
                                            className="form-control mb-2"
                                            placeholder="Día"
                                            onChange={(e) =>
                                                cambiarItinerario(
                                                    index,
                                                    "dia",
                                                    e.target.value
                                                )
                                            }
                                        />
                                        <input
                                            type="date"
                                            className="form-control mb-2"
                                            placeholder="Fecha"
                                            value={item.fecha}
                                            onChange={(e) =>
                                                cambiarItinerario(
                                                    index,
                                                    "fecha",
                                                    e.target.value
                                                )
                                            }
                                        />
                                        <textarea
                                            className="form-control mb-2"
                                            placeholder="Descripción"
                                            value={item.descripcion}
                                            onChange={(e) =>
                                                cambiarItinerario(
                                                    index,
                                                    "descripcion",
                                                    e.target.value
                                                )
                                            }
                                            rows={3}
                                        ></textarea>

                                        <button
                                            type="button"
                                            className="btn btn-outline-danger btn-sm"
                                            onClick={() =>
                                                eliminarItinerario(index)
                                            }
                                        >
                                            &times; Eliminar día
                                        </button>
                                    </div>
                                ))}
                                <button
                                    type="button"
                                    className="btn btn-outline-success"
                                    onClick={agregarItinerario}
                                >
                                    + Añadir día al itinerario
                                </button>
                            </div>

                            <button
                                type="submit"
                                className="btn btn-success w-100 text-white"
                                style={{ fontWeight: "600", fontSize: "18px" }}
                            >
                                Crear paquete
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CrearPaquete;
