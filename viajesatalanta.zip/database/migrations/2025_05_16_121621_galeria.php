<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('galeria', function (Blueprint $table) {
            $table->id();
            $table->string('imagen')->nullable();
            $table->string('titulo');
            $table->date('fecha');
            $table->string('ubicacion');
            $table->string('mapa');
            $table->timestamps();
        });
    }

    public function down(): void {
        Schema::dropIfExists('galeria');
    }
};

