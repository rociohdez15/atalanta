<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mapa_puntos', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('paquete_id');
            $table->string('nombre');
            $table->decimal('latitud', 10, 7);
            $table->decimal('longitud', 10, 7);
            $table->text('descripcion')->nullable();
            $table->timestamps();

            $table->foreign('paquete_id')->references('id')->on('paquetes_turisticos')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mapa_puntos');
    }
};
