<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Reserva extends Model
{
    use HasFactory;

    protected $table = 'reservas';

    protected $fillable = [
        'cliente_id',
        'paquete_id',
        'num_personas',
        'fecha_pago',
        'metodo_pago',
        'descuento',
        'estado',
        'total_precio',
        'fecha_reserva',
        'num_cuotas',         
        'importe_cuotas', 
    ];

    protected $casts = [
        'fecha_pago' => 'date',
        'fecha_reserva' => 'date',
    ];

    public function cliente()
    {
        return $this->belongsTo(User::class, 'cliente_id');
    }


    public function paquete()
    {
        return $this->belongsTo(PaqueteTuristico::class);
    }

    public function participantes()
    {
        return $this->hasMany(Participante::class, 'reserva_id'); // asumiendo que la FK es reserva_id
    }

    public function factura()
    {
        return $this->hasOne(Factura::class, 'reserva_id');
    }

    public function cliente2()
    {
        return $this->belongsTo(Cliente::class, 'cliente_id');
    }

     // 💥 Hook para borrar participantes al eliminar la reserva
    protected static function boot()
    {
        parent::boot();

        static::deleting(function ($reserva) {
            // Elimina participantes asociados antes de eliminar la reserva
            $reserva->participantes()->delete();
        });
    }
}
