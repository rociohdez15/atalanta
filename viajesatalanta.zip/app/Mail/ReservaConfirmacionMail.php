<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;

class ReservaConfirmacionMail extends Mailable
{
    use Queueable, SerializesModels;

    public $name;
    public $tipoPago;
    public $numCuotas;
    public $importeCuotas;
    public $plazas;
    public $totalPrecio;
    public $linkPagoCuotas;
    public $reserva;
    public $participantes;

    public $paqueteNombre;
    public $reservaId;
    public $clienteNombreCompleto;
    public $fechaInicioPaquete;
    public $fechaFinPaquete;

    public function __construct(
        $name,
        $tipoPago,
        $numCuotas,
        $importeCuotas,
        $plazas,
        $totalPrecio,
        $linkPagoCuotas = null,
        $reserva = null,
        $participantes = [],
        $paqueteNombre = '',
        $reservaId = null,
        $clienteNombreCompleto = '',
        $fechaInicioPaquete = null,
        $fechaFinPaquete = null
    ) {
        $this->name = $name;
        $this->tipoPago = $tipoPago;
        $this->numCuotas = $numCuotas;
        $this->importeCuotas = $importeCuotas;
        $this->plazas = $plazas;
        $this->totalPrecio = $totalPrecio;
        $this->linkPagoCuotas = $linkPagoCuotas;
        $this->reserva = $reserva;
        $this->participantes = $participantes;
        $this->paqueteNombre = $paqueteNombre;
        $this->reservaId = $reservaId;
        $this->clienteNombreCompleto = $clienteNombreCompleto;
        $this->fechaInicioPaquete = $fechaInicioPaquete;
        $this->fechaFinPaquete = $fechaFinPaquete;
    }

    public function build()
    {
        $name = $this->name;
        $tipoPago = strtolower($this->tipoPago);
        $numCuotas = $this->numCuotas;
        $importeCuotas = number_format($this->importeCuotas, 2, ',', '.');
        $plazas = $this->plazas;
        $totalPrecio = number_format($this->totalPrecio, 2, ',', '.');
        $linkPagoCuotas = $this->linkPagoCuotas;
        $cantidadRestante = $numCuotas - 1;

        $paqueteNombre = $this->paqueteNombre;
        $reservaId = $this->reservaId;
        $clienteNombreCompleto = $this->clienteNombreCompleto;

        $fechaInicioPaquete = $this->fechaInicioPaquete;
        $fechaFinPaquete = $this->fechaFinPaquete;

        $totalPrecioFloat = floatval($this->totalPrecio);
        $baseImponible = $totalPrecioFloat / 1.21;
        $iva = $totalPrecioFloat - $baseImponible;

        $baseImponibleFormatted = number_format($baseImponible, 2, ',', '.');
        $ivaFormatted = number_format($iva, 2, ',', '.');

        $fechaReserva = ($this->reserva && isset($this->reserva->fecha_reserva)) ? $this->reserva->fecha_reserva : date('Y-m-d');

        $fechaReservaFormatted = Carbon::parse($fechaReserva)->format('d/m/Y');
        $fechaInicioFormatted = $fechaInicioPaquete ? Carbon::parse($fechaInicioPaquete)->format('d/m/Y') : null;
        $fechaFinFormatted = $fechaFinPaquete ? Carbon::parse($fechaFinPaquete)->format('d/m/Y') : null;

        #$logoUrlPublico = 'http://atalanta.com/images/logo2.png';

        $htmlEmail = "
        <html>
            <body style='font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px;'>
                <div style='max-width: 600px; margin: 0 auto; background-color: #fff; padding: 30px; border-radius: 10px; color: #333;'>

                    <h1 style='color: #35372e; text-align: center;'>¡{$paqueteNombre} TE ESPERA!</h1>

                    <p style='font-size: 16px;'>Tu reserva con <strong>Atalanta</strong> ha sido confirmada.</p>

                    <hr style='border: 0; border-top: 1px solid #ddd; margin: 20px 0;'>

                    <p style='font-size: 16px;'>Hola {$clienteNombreCompleto},</p>

                    <p style='font-size: 16px;'>¡Gracias por reservar con <strong>Atalanta</strong>!<br>
                    Nos alegra acompañarte en esta nueva aventura. A continuación, encontrarás los detalles de tu reserva:</p>

                    <hr style='border: 0; border-top: 1px solid #ddd; margin: 20px 0;'>

                    <h3>📌 Detalles de tu reserva:</h3>
                    <ul style='font-size: 16px; list-style: none; padding: 0;'>
                        <li>• Destino: {$paqueteNombre}</li>";

                if ($fechaInicioFormatted) {
                    $htmlEmail .= "<li>• Fecha de salida: {$fechaInicioFormatted}</li>";
                }
                if ($fechaFinFormatted) {
                    $htmlEmail .= "<li>• Fecha de regreso: {$fechaFinFormatted}</li>";
                }

                $htmlEmail .= "
                        <li>• Número de personas: {$plazas}</li>
                        <li>• Referencia de reserva: {$reservaId}</li>
                    </ul>

                    <hr style='border: 0; border-top: 1px solid #ddd; margin: 20px 0;'>

                    <h3>¿Qué pasa ahora?</h3>
                    <p style='font-size: 16px;'>En breve recibirás otro correo con tu documentación de viaje necesaria y recomendaciones útiles para que disfrutes al máximo. Si necesitas hacer algún cambio o tienes dudas, estamos aquí para ayudarte.</p>

                    <h3>✉️ Contacto:</h3>
                    <ul style='font-size: 16px; list-style: none; padding: 0;'>
                        <li>• Correo: info@viajesatalanta.com</li>
                        <li>• Teléfono/WhatsApp: 666666666</li>
                        <li>• Horario de atención: De L a V de 9:00 h a 14:00 h</li>
                    </ul>

                    <hr style='border: 0; border-top: 1px solid #ddd; margin: 20px 0;'>

                    <p style='font-size: 16px;'>Gracias por confiar en <strong>Atalanta</strong>,<br>Tu próximo viaje comienza aquí. 🌍✈️</p>

                    <p style='margin-top: 30px; font-size: 12px; color: #777;'>Este mensaje fue generado automáticamente. Por favor, no respondas a este correo.</p>

                </div>
            </body>
        </html>";


        #$logoPath = public_path('images/logo2.png');
        #$logoData = base64_encode(file_get_contents($logoPath));
        #$logoBase64 = 'data:image/png;base64,' . $logoData;

        $htmlPdf = "
        <html>
        <head>
            <style>
                body { font-family: 'DejaVu Sans', Arial, sans-serif; color: #333; margin: 0; padding: 0; }
                .container { width: 100%; padding: 30px; }
                h1 { color: #35372e; margin-bottom: 0; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th, td { padding: 12px 15px; border: none; text-align: left; font-size: 14px; }
                th { background-color: #35372e; color: white; }
                .total { font-weight: bold; font-size: 16px; text-align: right; padding-right: 15px; }
                .footer { margin-top: 40px; font-size: 12px; color: #999; text-align: center; }
                ul.participantes { list-style-type: none; padding-left: 0; font-size: 14px; }
                ul.participantes li { padding: 5px 0; border-bottom: 1px solid #eee; }
            </style>
        </head>
        <body>
            <div class='container'>
                <table width='100%' style='border-bottom: 2px solid #35372e; margin-bottom: 20px; padding-bottom: 10px;'>
                    <tr>
                        <td style='width: 30%; vertical-align: middle;'>
                            <img src='{}' alt='Logo Empresa' style='height: 80px;'>
                        </td>
                        <td style='width: 70%; text-align: right; font-size: 14px; color: #555; vertical-align: middle;'>
                            <strong>Atalanta Travel S.L.</strong><br>
                            Calle Ejemplo 123, Madrid<br>
                            Tel: +34 912 345 678<br>
                            Email: info@atalanta.com<br>
                            NIF: B12345678
                        </td>
                    </tr>
                </table>

                <h1>Factura de Reserva</h1>

                <p><strong>Número de Reserva:</strong> {$reservaId}</p>
                <p><strong>Experiencia: </strong> {$paqueteNombre}</p>
                <p><strong>Cliente:</strong> {$clienteNombreCompleto}</p>
                <p><strong>Fecha de Reserva:</strong> {$fechaReservaFormatted}</p>";

        if ($fechaInicioFormatted && $fechaFinFormatted) {
            $htmlPdf .= "
                <p><strong>Fecha Inicio de la experiencia:</strong> {$fechaInicioFormatted}</p>
                <p><strong>Fecha Fin de la experiencia:</strong> {$fechaFinFormatted}</p>";
        }

        $htmlPdf .= "
                <table>
                    <tr><th>Concepto</th><th>Detalle</th></tr>
                    <tr><td>Tipo de Pago</td><td>" . ucfirst($tipoPago) . "</td></tr>
                    <tr><td>Número de Cuotas</td><td>{$numCuotas}</td></tr>
                    <tr><td>Importe por Cuota</td><td>{$importeCuotas} €</td></tr>
                    <tr><td>Número de viajeros</td><td>{$plazas}</td></tr>
                    <tr><td>Base Imponible</td><td>{$baseImponibleFormatted} €</td></tr>
                    <tr><td>IVA (21%)</td><td>{$ivaFormatted} €</td></tr>
                    <tr><td><strong>Total Factura</strong></td><td><strong>{$totalPrecio} €</strong></td></tr>
                </table>
                </br></br></br></br>
                <h2>Viajeros</h2>
                <ul class='participantes'>";

        foreach ($this->participantes as $p) {
            $dni = $p['dni'] ?? 'N/A';
            $htmlPdf .= "<li>{$p['nombre']} {$p['apellidos']} - Email: {$p['email']} - DNI: {$dni}</li>";
        }

        $htmlPdf .= "
                </ul>

                <div class='footer'>
                    <p>Atalanta Travel S.L. - Todos los derechos reservados &copy; " . date('Y') . "</p>
                </div>
            </div>
        </body>
        </html>";

        $pdf = Pdf::loadHTML($htmlPdf)->setPaper('A4');

        return $this->subject('Confirmación de tu reserva')
            ->html($htmlEmail)
            ->attachData($pdf->output(), 'factura_reserva.pdf', [
                'mime' => 'application/pdf',
            ]);
    }
}
