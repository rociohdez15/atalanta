<?php

namespace App\Http\Controllers\Reservas;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Ssheduardo\Redsys\Facades\Redsys;
use Exception;
use Stripe\Stripe;
use Stripe\Checkout\Session;
use App\Models\Reserva;
use App\Models\Participante;
use App\Models\PaqueteTuristico;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Mail\ReservaConfirmacionMail;
use Tymon\JWTAuth\Facades\JWTAuth;



class ReservasController extends Controller
{
    public function pendientes()
    {
        $reservasPendientes = Reserva::with(['cliente2', 'paquete'])
            ->where('estado', 'Pendiente')
            ->get()
            ->map(function ($reserva) {
                return [
                    'id' => $reserva->id,
                    'reservation_token' => $reserva->reservation_token,
                    'cliente_nombre' => $reserva->cliente2->nombre ?? 'N/A',
                    'paquete_nombre' => $reserva->paquete->nombre ?? 'N/A',
                    'num_personas' => $reserva->num_personas,
                    'fecha_pago' => $reserva->fecha_pago,
                    'metodo_pago' => $reserva->metodo_pago,
                    'descuento' => $reserva->descuento,
                    'estado' => $reserva->estado,
                    'num_cuotas' => $reserva->num_cuotas,
                    'importe_cuotas' => $reserva->importe_cuotas,
                    'total_precio' => $reserva->total_precio,
                    'fecha_reserva' => $reserva->fecha_reserva,
                ];
            });

        return response()->json($reservasPendientes);
    }

    public function update(Request $request, $id)
    {
        $reserva = Reserva::with(['cliente2', 'paquete'])->find($id);

        if (!$reserva) {
            return response()->json(['message' => 'Reserva no encontrada'], 404);
        }

        $validated = $request->validate([
            'metodo_pago' => 'required|string|max:255',
            'num_cuotas' => 'required|integer|min:0',
            'importe_cuotas' => 'required|numeric|min:0',
            'total_precio' => 'required|numeric|min:0',
            'estado' => 'required|string|in:Pendiente,Confirmada,Cancelada',
        ]);

        $reserva->update($validated);

        // Mapeamos como en buscar() para que incluya los nombres del cliente y paquete
        $reservaMapeada = [
            'id' => $reserva->id,
            'reservation_token' => $reserva->reservation_token,
            'cliente_nombre' => $reserva->cliente2->nombre ?? 'N/A',
            'paquete_nombre' => $reserva->paquete->nombre ?? 'N/A',
            'num_personas' => $reserva->num_personas,
            'fecha_pago' => $reserva->fecha_pago,
            'metodo_pago' => $reserva->metodo_pago,
            'descuento' => $reserva->descuento,
            'estado' => $reserva->estado,
            'num_cuotas' => $reserva->num_cuotas,
            'importe_cuotas' => $reserva->importe_cuotas,
            'total_precio' => $reserva->total_precio,
            'fecha_reserva' => $reserva->fecha_reserva,
        ];

        return response()->json($reservaMapeada, 200);
    }


    public function destroy($id)
    {
        $reserva = Reserva::find($id);

        if (!$reserva) {
            return response()->json(['message' => 'Reserva no encontrada'], 404);
        }

        $reserva->delete();

        return response()->json(['message' => 'Reserva eliminada correctamente'], 200);
    }

    public function buscar(Request $request)
    {
        $input = $request->query('input');

        if (is_numeric($input)) {
            $reserva = Reserva::with(['cliente2', 'paquete'])->find($input);
            if (!$reserva) {
                return response()->json(['message' => 'No se encontraron resultados.'], 404);
            }
            $reservaMapeada = [
                'id' => $reserva->id,
                'reservation_token' => $reserva->reservation_token,
                'cliente_nombre' => $reserva->cliente2->nombre ?? 'N/A',
                'paquete_nombre' => $reserva->paquete->nombre ?? 'N/A',
                'num_personas' => $reserva->num_personas,
                'fecha_pago' => $reserva->fecha_pago,
                'metodo_pago' => $reserva->metodo_pago,
                'descuento' => $reserva->descuento,
                'estado' => $reserva->estado,
                'num_cuotas' => $reserva->num_cuotas,
                'importe_cuotas' => $reserva->importe_cuotas,
                'total_precio' => $reserva->total_precio,
                'fecha_reserva' => $reserva->fecha_reserva,
            ];
            return response()->json([$reservaMapeada]);
        }

        $resultados = Reserva::with(['cliente2', 'paquete'])
            ->whereHas('cliente2', function ($query) use ($input) {
                $query->where('nombre', 'LIKE', "%$input%");
            })
            ->orWhereHas('paquete', function ($query) use ($input) {
                $query->where('nombre', 'LIKE', "%$input%");
            })
            ->get()
            ->map(function ($reserva) {
                return [
                    'id' => $reserva->id,
                    'reservation_token' => $reserva->reservation_token,
                    'cliente_nombre' => $reserva->cliente2->nombre ?? 'N/A',
                    'paquete_nombre' => $reserva->paquete->nombre ?? 'N/A',
                    'num_personas' => $reserva->num_personas,
                    'fecha_pago' => $reserva->fecha_pago,
                    'metodo_pago' => $reserva->metodo_pago,
                    'descuento' => $reserva->descuento,
                    'estado' => $reserva->estado,
                    'num_cuotas' => $reserva->num_cuotas,
                    'importe_cuotas' => $reserva->importe_cuotas,
                    'total_precio' => $reserva->total_precio,
                    'fecha_reserva' => $reserva->fecha_reserva,
                ];
            });

        if ($resultados->isEmpty()) {
            return response()->json(['message' => 'No se encontraron resultados.'], 404);
        }

        return response()->json($resultados);
    }

    public function confirmadas()
    {
        $reservasPendientes = Reserva::with(['cliente2', 'paquete'])
            ->where('estado', 'Confirmada')
            ->get()
            ->map(function ($reserva) {
                return [
                    'id' => $reserva->id,
                    'reservation_token' => $reserva->reservation_token,
                    'cliente_nombre' => $reserva->cliente2->nombre ?? 'N/A',
                    'paquete_nombre' => $reserva->paquete->nombre ?? 'N/A',
                    'num_personas' => $reserva->num_personas,
                    'fecha_pago' => $reserva->fecha_pago,
                    'metodo_pago' => $reserva->metodo_pago,
                    'descuento' => $reserva->descuento,
                    'estado' => $reserva->estado,
                    'num_cuotas' => $reserva->num_cuotas,
                    'importe_cuotas' => $reserva->importe_cuotas,
                    'total_precio' => $reserva->total_precio,
                    'fecha_reserva' => $reserva->fecha_reserva,
                ];
            });

        return response()->json($reservasPendientes);
    }

    public function canceladas()
    {
        $reservasPendientes = Reserva::with(['cliente2', 'paquete'])
            ->where('estado', 'Cancelada')
            ->get()
            ->map(function ($reserva) {
                return [
                    'id' => $reserva->id,
                    'reservation_token' => $reserva->reservation_token,
                    'cliente_nombre' => $reserva->cliente2->nombre ?? 'N/A',
                    'paquete_nombre' => $reserva->paquete->nombre ?? 'N/A',
                    'num_personas' => $reserva->num_personas,
                    'fecha_pago' => $reserva->fecha_pago,
                    'metodo_pago' => $reserva->metodo_pago,
                    'descuento' => $reserva->descuento,
                    'estado' => $reserva->estado,
                    'num_cuotas' => $reserva->num_cuotas,
                    'importe_cuotas' => $reserva->importe_cuotas,
                    'total_precio' => $reserva->total_precio,
                    'fecha_reserva' => $reserva->fecha_reserva,
                ];
            });

        return response()->json($reservasPendientes);
    }


    public function getPorReserva($id)
    {
        try {
            $participantes = Participante::where('reserva_id', $id)->get();

            if ($participantes->isEmpty()) {
                return response()->json([], 200); // Devuelve un array vacío si no hay participantes
            }

            return response()->json($participantes, 200);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Error al obtener los participantes.',
                'detalle' => $e->getMessage()
            ], 500);
        }
    }

    public function updateParticipantes(Request $request, $id)
    {
        $participante = Participante::findOrFail($id);

        $validated = $request->validate([
            'nombre' => 'required|string|max:255',
            'apellidos' => 'required|string|max:255',
            'email' => 'nullable|email|max:255',
            'dni' => 'nullable|string|max:20',
            'telefono' => 'nullable|string|max:20',
            'direccion' => 'nullable|string|max:255',
            'ciudad' => 'nullable|string|max:255',
            'provincia' => 'nullable|string|max:255',
            'fecha_nacimiento' => 'nullable|date',
            'experiencia' => 'nullable|string',
            'motivacion' => 'nullable|string',
            'info_relevante' => 'nullable|string',
        ]);

        $participante->update($validated);

        return response()->json($participante);
    }

    public function destroyParticipantes($id)
    {
        $participante = Participante::find($id);

        if (!$participante) {
            return response()->json(['message' => 'Participante no encontrado.'], 404);
        }

        $participante->delete();

        return response()->json(['message' => 'Participante eliminado correctamente.']);
    }
}
