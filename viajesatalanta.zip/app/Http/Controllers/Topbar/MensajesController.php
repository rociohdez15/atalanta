<?php

namespace App\Http\Controllers\Topbar;

use App\Models\FormularioContacto;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class MensajesController extends Controller
{
public function obtenerMensajes()
{
    $mensajes = FormularioContacto::orderBy('is_read')->get();

    return response()->json($mensajes);
}


    public function marcarComoLeido(Request $request)
    {
        $mensaje = FormularioContacto::find($request->id);

        if (!$mensaje) {
            return response()->json(['error' => 'Mensaje no encontrado'], 404);
        }

        $mensaje->is_read = 1;
        $mensaje->save();

        return response()->noContent(); // 204
    }

    public function obtenerMensajePorId($id)
    {
        $mensaje = FormularioContacto::find($id);

        if (!$mensaje) {
            return response()->json(['error' => 'Mensaje no encontrado'], 404);
        }

        return response()->json($mensaje);
    }

    public function buscarMensajes(Request $request)
    {
        $input = $request->input('input');

        if (is_numeric($input)) {
            $mensajes = FormularioContacto::where('id', $input)->get();
        } else {
            $mensajes = FormularioContacto::where('nombre', 'LIKE', "%$input%")
                ->orWhere('email', 'LIKE', "%$input%")
                ->get();
        }

        return response()->json($mensajes);
    }

    public function eliminarMensaje($id)
    {
        $mensaje = FormularioContacto::find($id);

        if (!$mensaje) {
            return response()->json(['error' => 'Mensaje no encontrado'], 404);
        }

        try {
            $mensaje->delete();
            return response()->json(['message' => 'Mensaje eliminado correctamente']);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Error al eliminar el mensaje'], 500);
        }
    }

     public function agregar(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'mensaje' => 'required|string',
        ]);

        $validated['is_read'] = 0;
        $validated['fecha'] = now()->toDateString(); 

        FormularioContacto::create($validated);

        return response()->json(['message' => 'Mensaje guardado correctamente'], 201);
    }
}
