<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Cliente;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use App\Mail\WelcomeMail;
use App\Http\Controllers\Controller;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Str;
use App\Mail\NuevaContrasenaMail;


class AuthController extends Controller
{
    public function login(Request $request)
    {
        $credentials = $request->only(['email', 'password']);
        $remember = $request->input('remember', false); // true o false

        // Cambia la duración del token si se marca 'remember'
        if ($remember) {
            JWTAuth::factory()->setTTL(60 * 24 * 7); // 7 días
        } else {
            JWTAuth::factory()->setTTL(60); // 1 hora
        }

        if (!$token = auth('api')->attempt($credentials)) {
            return response()->json(['error' => 'Credenciales inválidas'], 401);
        }

        $user = auth('api')->user();

        return response()->json([
            'token' => $token,
            'rol' => $user->rol ?? 'USER',
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
            ],
        ]);
    }

    public function register(Request $request)
    {
        // Validar los datos
        $validator = Validator::make($request->all(), [
            'nombre' => 'required|string|max:255',
            'apellidos' => 'required|string|max:255',
            'dni' => 'required|string|unique:clientes,dni|regex:/^\d{8}[A-Za-z]$/',
            'direccion' => 'required|string|max:255',
            'telefono' => 'required|string|max:20',
            'fechaNacimiento' => 'required|date|before:-18 years',
            'email' => 'required|string|email|max:255|unique:users,email',
            'password' => ['required', 'string', 'min:8', 'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/'],
        ], [
            'dni.regex' => 'El DNI debe tener 8 números seguidos de una letra.',
            'password.regex' => 'La contraseña debe contener al menos una mayúscula, una minúscula y un número.',
            'fechaNacimiento.before' => 'Debes ser mayor de 18 años.',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }

        // Crear usuario
        $user = User::create([
            'name' => $request->nombre,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'rol' => 'USER',
        ]);

        // Crear cliente
        $client = Cliente::create([
            'nombre' => $request->nombre,
            'apellidos' => $request->apellidos,
            'dni' => $request->dni,
            'direccion' => $request->direccion,
            'telefono' => $request->telefono,
            'fecha_nacimiento' => $request->fechaNacimiento,
            'usuario_id' => $user->id,
        ]);

        // Enviar correo de bienvenida con HTML personalizado
        Mail::to($user->email)->send(new WelcomeMail($user->name));

        return response()->json(['message' => 'Usuario registrado con éxito.'], 201);
    }

    public function olvidaste(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
        ]);

        $user = User::where('email', $request->email)->first();

        if (!$user) {
            return response()->json(['message' => 'No existe un usuario con ese correo.'], 404);
        }

        $nuevaContrasena = Str::random(10);
        $user->password = Hash::make($nuevaContrasena);
        $user->save();

        Mail::to($user->email)->send(new NuevaContrasenaMail($user->name, $nuevaContrasena));

        return response()->json(['message' => 'Se ha enviado una nueva contraseña al correo.']);
    }
}
