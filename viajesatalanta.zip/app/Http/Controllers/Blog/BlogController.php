<?php

namespace App\Http\Controllers\Blog;

use App\Http\Controllers\Controller;
use App\Models\Entrada;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Http\Request;
use App\Models\LikeEntrada;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;


class BlogController extends Controller
{
    public function index(Request $request)
    {
        $pageSize = $request->input('size', 3);

        $entradas = Entrada::withCount('likes')
            ->orderBy('fecha_publicacion', 'desc')
            ->paginate($pageSize);

        return response()->json([
            'content' => $entradas->items(),
            'totalPages' => $entradas->lastPage(),
        ]);
    }

    public function show($id)
    {
        $entrada = Entrada::withCount('likes')->findOrFail($id);

        return response()->json($entrada);
    }

    public function toggle(Request $request)
    {
        try {
            Log::info('Toggle LikeEntrada llamado', [
                'user' => optional(Auth::user())->id,
                'entrada_id' => $request->entrada_id
            ]);

            $user = Auth::user();

            if (!$user) {
                return response()->json(['error' => 'Usuario no autenticado'], 401);
            }

            $request->validate([
                'entrada_id' => 'required|exists:entradas,id'
            ]);

            $like = LikeEntrada::where('usuario_id', $user->id)
                ->where('entrada_id', $request->entrada_id)
                ->first();

            if ($like) {
                // Eliminar like
                $like->delete();

                // Opcional: Crear notificación de "unlike" o eliminar la notificación si tienes lógica para ello

                return response()->json(['message' => 'LikeEntrada eliminado']);
            } else {
                // Crear like
                LikeEntrada::create([
                    'usuario_id' => $user->id,
                    'entrada_id' => $request->entrada_id,
                    'fecha' => now()->toDateString()
                ]);

                $user = Auth::user();

                // Obtener el cliente vinculado al usuario autenticado
                $cliente = DB::table('clientes')->where('usuario_id', $user->id)->first();

                if (!$cliente) {
                    return response()->json(['error' => 'Cliente no encontrado para el usuario'], 400);
                }

                // Ahora usas $cliente->id para cliente_id en notificaciones
                DB::table('notificaciones')->insert([
                    'tipo' => 'like',
                    'cliente_id' => $cliente->id,
                    'fecha' => now(),
                    'is_read' => 0,
                    'created_at' => now(),
                    'updated_at' => now()
                ]);

                return response()->json(['message' => 'LikeEntrada añadido']);
            }
        } catch (\Throwable $e) {
            Log::error('Error en toggle LikeEntrada: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json(['error' => 'Error interno del servidor'], 500);
        }
    }

    public function count($entradaId)
    {
        $count = LikeEntrada::where('entrada_id', $entradaId)->count();
        return response()->json(['likes' => $count]);
    }

    public function likedByUser($entradaId)
    {
        $user = Auth::user();
        $liked = LikeEntrada::where('entrada_id', $entradaId)
            ->where('usuario_id', $user->id)
            ->exists();

        return response()->json(['liked' => $liked]);
    }

    public function obtenerEntradas()
    {
        return Entrada::all();
    }

    public function eliminar($id)
    {
        $entrada = Entrada::find($id);

        if (!$entrada) {
            return response()->json(['message' => 'Entrada no encontrada'], 404);
        }

        // Eliminar archivo del sistema si existe
        // Ruta del directorio completo de la entrada
        $directorio = 'public/blog/' . $entrada->id;

        // Eliminar el directorio completo con todas las imágenes
        if (Storage::exists($directorio)) {
            Storage::deleteDirectory($directorio);
        }

        $entrada->delete();

        return response()->json(['message' => 'Entrada eliminada correctamente'], 200);
    }

    public function editar(Request $request, $id)
    {
        $request->validate([
            'titulo' => 'required|string',
            'fecha_publicacion' => 'required|date',
            'contenido' => 'required|string',
            'imagen' => 'nullable|image|max:2048',
        ]);

        $entrada = Entrada::findOrFail($id);

        $entrada->titulo = $request->input('titulo');
        $entrada->fecha_publicacion = $request->input('fecha_publicacion');
        $entrada->contenido = $request->input('contenido');

        if ($request->hasFile('imagen')) {
            // Elimina archivo anterior si existe
            if ($entrada->imagen_destacada) {
                $rutaAnterior = storage_path("app/public/blog/{$entrada->id}/" . $entrada->imagen_destacada);
                if (file_exists($rutaAnterior)) {
                    unlink($rutaAnterior);
                }
            }

            // Guarda la nueva imagen
            $file = $request->file('imagen');
            $path = $file->store("public/blog/{$entrada->id}");

            // Actualiza el nombre o ruta en el modelo
            $entrada->imagen_destacada = basename($path);
        }


        $entrada->save();

        return response()->json($entrada);
    }

    public function buscar(Request $request)
    {
        $input = $request->input('query');

        if (!$input) {
            // Si no hay input, devolver todas las entradas o vacías
            return response()->json(Entrada::all());
        }

        // Si el input es numérico, buscar por id exacto o por título (like)
        if (is_numeric($input)) {
            $entradas = Entrada::where('id', $input)
                ->orWhere('titulo', 'like', "%{$input}%")
                ->get();
        } else {
            // Si no es numérico, buscar solo por título LIKE
            $entradas = Entrada::where('titulo', 'like', "%{$input}%")->get();
        }

        return response()->json($entradas);
    }

    public function agregar(Request $request)
    {
        try {
            // Validación básica (sin validar fecha porque la ignoramos)
            $validated = $request->validate([
                'titulo' => 'required|string|max:255',
                'contenido' => 'required|string',
                'imagen_destacada' => 'required|image|max:2048', // máximo 2MB
            ]);

            $user = JWTAuth::parseToken()->authenticate();
            if (!$user) {
                return response()->json(['error' => 'Usuario no autenticado'], 401);
            }

            // Fecha actual
            $fechaActual = Carbon::now();

            // Crear entrada sin imagen primero
            $entrada = Entrada::create([
                'titulo' => $validated['titulo'],
                'fecha_publicacion' => $fechaActual, // siempre la fecha actual
                'contenido' => $validated['contenido'],
                'imagen_destacada' => null,
                'autor_id' => $user->id,
            ]);

            // Guardar imagen en public/blog/{id}/
            if ($request->hasFile('imagen_destacada')) {
                $file = $request->file('imagen_destacada');

                $carpeta = "blog/{$entrada->id}";
                $rutaCompleta = storage_path("app/public/blog/{$entrada->id}");


                if (!file_exists($rutaCompleta)) {
                    if (!mkdir($rutaCompleta, 0755, true) && !is_dir($rutaCompleta)) {
                        throw new \RuntimeException(sprintf('No se pudo crear el directorio "%s"', $rutaCompleta));
                    }
                }

                $nombreImagen = time() . '_' . $file->getClientOriginalName();

                // Mover archivo y verificar
                if (!$file->move($rutaCompleta, $nombreImagen)) {
                    throw new \Exception('Error al mover la imagen al directorio destino.');
                }

                // Actualizar entrada con nombre imagen
                $entrada->imagen_destacada = $nombreImagen;
                $entrada->save();
            }

            return response()->json([
                'message' => 'Entrada creada correctamente',
                'entrada' => $entrada,
            ], 201);
        } catch (\Exception $e) {
            Log::error('Error en agregar entrada: ' . $e->getMessage());
            return response()->json([
                'message' => 'Error al crear la entrada',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
