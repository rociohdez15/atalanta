<?php

namespace App\Http\Controllers\Usuarios;

use App\Models\Cliente;
use App\Models\User;
use App\Models\Reserva;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Http\Controllers\Controller;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Log;

class DashboardUserController extends Controller
{
    public function show(Request $request)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
        } catch (\Exception $e) {
            return response()->json(['error' => 'Token inválido o usuario no autenticado'], 401);
        }

        $cliente = Cliente::where('usuario_id', $user->id)->first();

        if (!$cliente) {
            return response()->json(['error' => 'Cliente no encontrado'], 404);
        }

        return response()->json($cliente);
    }

    public function update(Request $request)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
        } catch (\Exception $e) {
            return response()->json(['error' => 'Token inválido o usuario no autenticado'], 401);
        }

        $cliente = Cliente::where('usuario_id', $user->id)->first();

        if (!$cliente) {
            return response()->json(['error' => 'Cliente no encontrado'], 404);
        }

        $request->validate([
            'nombre' => 'required|string|max:255',
            'apellidos' => 'required|string|max:255',
            'dni' => 'required|string|max:20|unique:clientes,dni,' . $cliente->id,
            'direccion' => 'nullable|string|max:255',
            'telefono' => 'nullable|string|max:20',
            'fecha_nacimiento' => 'nullable|date',
        ]);

        $cliente->nombre = $request->nombre;
        $cliente->apellidos = $request->apellidos;
        $cliente->dni = $request->dni;
        $cliente->direccion = $request->direccion;
        $cliente->telefono = $request->telefono;
        $cliente->fecha_nacimiento = $request->fecha_nacimiento;

        $cliente->save();

        return response()->json($cliente);
    }

    public function cambioPassword(Request $request)
    {
        Log::info('Inicio cambioPassword');

        $request->validate([
            'current_password' => ['required'],
            'new_password' => ['required', 'min:8', 'confirmed'],
        ]);

        Log::info('Validación de datos completada', [
            'current_password' => $request->current_password,
            // No pongas new_password por seguridad
        ]);

        try {
            $jwtUser = JWTAuth::parseToken()->authenticate();
            Log::info('Usuario autenticado con JWT', ['user_id' => $jwtUser->id]);
        } catch (\Exception $e) {
            Log::error('Error al autenticar token JWT', ['exception' => $e->getMessage()]);
            return response()->json(['error' => 'Token inválido o usuario no autenticado'], 401);
        }

        $user = User::find($jwtUser->id);

        if (!$user) {
            Log::error('Usuario no encontrado en la base de datos', ['user_id' => $jwtUser->id]);
            return response()->json(['error' => 'Usuario no encontrado.'], 404);
        }

        Log::info('Usuario encontrado', ['user_id' => $user->id]);

        if (!Hash::check($request->current_password, $user->password)) {
            Log::warning('Contraseña actual incorrecta', [
                'user_id' => $user->id,
                'input_password' => $request->current_password,
            ]);
            return response()->json(['current_password' => ['La contraseña actual no es correcta.']], 422);
        }

        Log::info('Contraseña actual correcta, procediendo a cambiarla');

        $user->password = Hash::make($request->new_password);

        if ($user->save()) {
            Log::info('Contraseña actualizada y usuario guardado', ['user_id' => $user->id]);
        } else {
            Log::error('Error al guardar el usuario tras cambiar la contraseña', ['user_id' => $user->id]);
            return response()->json(['error' => 'Error al actualizar la contraseña.'], 500);
        }

        return response()->json([
            'message' => 'Contraseña actualizada correctamente.'
        ], 200);
    }

    public function listarReservasUsuario(Request $request)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();

            // Buscar cliente por usuario_id
            $cliente = Cliente::where('usuario_id', $user->id)->first();

            if (!$cliente) {
                return response()->json(['error' => 'Cliente no encontrado'], 404);
            }

            // Obtener reservas con el paquete turístico y el cliente
            $reservas = $cliente->reservas()->with(['paquete', 'cliente'])->get();

            $resultado = $reservas->map(function ($reserva) {
                $fechaReserva = $reserva->fecha_reserva instanceof \Carbon\Carbon ? $reserva->fecha_reserva->format('Y-m-d') : null;
                $fechaInicio = $reserva->paquete && $reserva->paquete->fecha_inicio instanceof \Carbon\Carbon ? $reserva->paquete->fecha_inicio->format('Y-m-d') : null;
                $fechaFin = $reserva->paquete && $reserva->paquete->fecha_fin instanceof \Carbon\Carbon ? $reserva->paquete->fecha_fin->format('Y-m-d') : null;


                $clienteNombreCompleto = $reserva->cliente ? $reserva->cliente->nombre . ' ' . $reserva->cliente->apellidos : null;

                return [
                    'reserva_id' => $reserva->id,
                    'numero_reserva' => $reserva->reservation_token ?? null,
                    'experiencia' => $reserva->paquete?->nombre,
                    'clienteNombreCompleto' => $clienteNombreCompleto,
                    'fecha_reserva' => $fechaReserva,
                    'fecha_inicio' => $fechaInicio,
                    'fecha_fin' => $fechaFin,
                    'tipo_pago' => $reserva->metodo_pago,
                    'num_cuotas' => $reserva->num_cuotas ?? null,
                    'importe_cuotas' => $reserva->importe_cuotas ?? null,
                    'total_precio' => $reserva->total_precio,
                    'num_personas' => $reserva->num_personas,
                    'estado' => $reserva->estado,
                ];
            });

            return response()->json($resultado);
        } catch (\Exception $e) {
            Log::error('Error en listarReservasUsuario: ' . $e->getMessage());
            return response()->json(['error' => 'Error interno: ' . $e->getMessage()], 500);
        }
    }

public function mostrarNombrePorLog(Request $request, $reservaId)
{
    try {
        $user = JWTAuth::parseToken()->authenticate();
    } catch (\Exception $e) {
        Log::error('Token inválido o usuario no autenticado: ' . $e->getMessage());
        return response()->json(['error' => 'Token inválido o usuario no autenticado'], 401);
    }

    $cliente = Cliente::where('usuario_id', $user->id)->first();

    if (!$cliente) {
        Log::error('Cliente no encontrado para usuario ID: ' . $user->id);
        return response()->json(['error' => 'Cliente no encontrado'], 404);
    }

    $reserva = Reserva::with('paquete')->find($reservaId);
    if (!$reserva) {
        Log::error("Reserva no encontrada con ID: {$reservaId}");
        return response()->json(['error' => 'Reserva no encontrada'], 404);
    }

    $nombrePaquete = $reserva->paquete ? $reserva->paquete->nombre : 'Paquete no asociado';

    // Fechas formateadas o fallback
    $fechaReservaFormatted = $reserva->fecha_reserva ? date('d/m/Y', strtotime($reserva->fecha_reserva)) : 'No disponible';
    $fechaInicioFormatted = $reserva->paquete && $reserva->paquete->fecha_inicio ? date('d/m/Y', strtotime($reserva->paquete->fecha_inicio)) : null;
    $fechaFinFormatted = $reserva->paquete && $reserva->paquete->fecha_fin ? date('d/m/Y', strtotime($reserva->paquete->fecha_fin)) : null;

    $tipoPago = $reserva->metodo_pago ?? 'No disponible';
    $numCuotas = $reserva->num_cuotas ?? 'N/A';
    $importeCuotas = $reserva->importe_cuotas ?? 'N/A';
    $plazas = $reserva->num_personas ?? 'N/A';

    $ivaRate = 0.21;
    $precioTotal = $reserva->total_precio ?? 0;
    if ($precioTotal > 0) {
        $baseImponible = round($precioTotal / (1 + $ivaRate), 2);
        $iva = round($precioTotal - $baseImponible, 2);
    } else {
        $baseImponible = 0;
        $iva = 0;
    }

    // Formatear números para la factura
    $baseImponibleFormatted = number_format($baseImponible, 2, ',', '.');
    $ivaFormatted = number_format($iva, 2, ',', '.');
    $totalPrecio = number_format($precioTotal, 2, ',', '.');

    $clienteNombreCompleto = $cliente->nombre . ' ' . $cliente->apellidos;

    // Obtener participantes - deberás adaptar esta parte a cómo almacenas los participantes de la reserva
    // Por ejemplo, si tienes relación: $reserva->participantes()
    $participantes = $reserva->participantes ?? [];

    // Logo en base64
    $logoPath = public_path('images/logo2.png');
    $logoData = base64_encode(file_get_contents($logoPath));
    $logoBase64 = 'data:image/png;base64,' . $logoData;

    $htmlPdf = "
    <html>
    <head>
        <style>
            body { font-family: 'DejaVu Sans', Arial, sans-serif; color: #333; margin: 0; padding: 0; }
            .container { width: 100%; padding: 30px; }
            h1 { color: #35372e; margin-bottom: 0; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { padding: 12px 15px; border: none; text-align: left; font-size: 14px; }
            th { background-color: #35372e; color: white; }
            .total { font-weight: bold; font-size: 16px; text-align: right; padding-right: 15px; }
            .footer { margin-top: 40px; font-size: 12px; color: #999; text-align: center; }
            ul.participantes { list-style-type: none; padding-left: 0; font-size: 14px; }
            ul.participantes li { padding: 5px 0; border-bottom: 1px solid #eee; }
        </style>
    </head>
    <body>
        <div class='container'>
            <table width='100%' style='border-bottom: 2px solid #35372e; margin-bottom: 20px; padding-bottom: 10px;'>
                <tr>
                    <td style='width: 30%; vertical-align: middle;'>
                        <img src='{$logoBase64}' alt='Logo Empresa' style='height: 80px;'>
                    </td>
                    <td style='width: 70%; text-align: right; font-size: 14px; color: #555; vertical-align: middle;'>
                        <strong>Atalanta Travel S.L.</strong><br>
                        Calle Ejemplo 123, Madrid<br>
                        Tel: +34 912 345 678<br>
                        Email: info@atalanta.com<br>
                        NIF: B12345678
                    </td>
                </tr>
            </table>

            <h1>Factura de Reserva</h1>

            <p><strong>Número de Reserva:</strong> {$reservaId}</p>
            <p><strong>Experiencia: </strong> {$nombrePaquete}</p>
            <p><strong>Cliente:</strong> {$clienteNombreCompleto}</p>
            <p><strong>Fecha de Reserva:</strong> {$fechaReservaFormatted}</p>";

    if ($fechaInicioFormatted && $fechaFinFormatted) {
        $htmlPdf .= "
            <p><strong>Fecha Inicio de la experiencia:</strong> {$fechaInicioFormatted}</p>
            <p><strong>Fecha Fin de la experiencia:</strong> {$fechaFinFormatted}</p>";
    }

    $htmlPdf .= "
            <table>
                <tr><th>Concepto</th><th>Detalle</th></tr>
                <tr><td>Tipo de Pago</td><td>" . ucfirst($tipoPago) . "</td></tr>
                <tr><td>Número de Cuotas</td><td>{$numCuotas}</td></tr>
                <tr><td>Importe por Cuota</td><td>{$importeCuotas} €</td></tr>
                <tr><td>Número de viajeros</td><td>{$plazas}</td></tr>
                <tr><td>Base Imponible</td><td>{$baseImponibleFormatted} €</td></tr>
                <tr><td>IVA (21%)</td><td>{$ivaFormatted} €</td></tr>
                <tr><td><strong>Total Factura</strong></td><td><strong>{$totalPrecio} €</strong></td></tr>
            </table>
            <br><br><br><br>
            <h2>Viajeros</h2>
            <ul class='participantes'>";

    foreach ($participantes as $p) {
        $dni = $p['dni'] ?? 'N/A';
        $nombreP = $p['nombre'] ?? 'Nombre no disponible';
        $apellidosP = $p['apellidos'] ?? '';
        $emailP = $p['email'] ?? 'Email no disponible';
        $htmlPdf .= "<li>{$nombreP} {$apellidosP} - Email: {$emailP} - DNI: {$dni}</li>";
    }

    $htmlPdf .= "
            </ul>

            <div class='footer'>
                <p>Atalanta Travel S.L. - Todos los derechos reservados &copy; " . date('Y') . "</p>
            </div>
        </div>
    </body>
    </html>";

    $pdf = PDF::loadHTML($htmlPdf)->setPaper('A4');

    // Para descargar el PDF directamente:
    return $pdf->download("factura_reserva_{$reservaId}.pdf");

    // Si quieres enviarlo inline para visualizar en navegador:
    // return $pdf->stream("factura_reserva_{$reservaId}.pdf");
}




}
