<?php

namespace App\Http\Controllers\Facturas;

use App\Http\Controllers\Controller;
use App\Models\Cliente;
use App\Models\Reserva;
use App\Models\Factura;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\DB;




class FacturasController extends Controller
{
    // Obtener todos los clientes
    public function obtenerClientes()
    {
        return response()->json(Cliente::all());
    }

    // Buscar clientes por término en nombre, apellidos o dni
    public function buscarClientes(Request $request)
    {
        $input = $request->query('input', '');

        if (!$input) {
            return response()->json(Cliente::all());
        }

        $clientes = Cliente::where('nombre', 'like', "%$input%")
            ->orWhere('apellidos', 'like', "%$input%")
            ->orWhere('dni', 'like', "%$input%")
            ->get();

        return response()->json($clientes);
    }

    // Eliminar cliente por id
    public function eliminarCliente($id)
    {
        $cliente = Cliente::find($id);

        if (!$cliente) {
            return response()->json(['message' => 'Cliente no encontrado'], 404);
        }

        $cliente->delete();

        return response()->json(['message' => 'Cliente eliminado']);
    }

    public function reservasPorCliente($clienteId)
    {
        Log::info('reservasPorCliente llamado con clienteId:', ['clienteId' => $clienteId]);

        $reservas = Reserva::where('cliente_id', $clienteId)->get();

        Log::info('Reservas encontradas:', ['count' => $reservas->count(), 'reservas' => $reservas]);

        return response()->json($reservas);
    }


    public function generarFacturaAdmin($reservaId, $id)
    {
        // Buscar la reserva con ese id
        $reserva = Reserva::with('paquete')->find($reservaId);

        if (!$reserva) {
            return response()->json(['error' => 'Reserva no encontrada'], 404);
        }

        // Buscar el cliente con el clienteId que viene por la URL
        $cliente = Cliente::find($id);

        if (!$cliente) {
            return response()->json(['error' => 'Cliente no encontrado'], 404);
        }


        $reserva = Reserva::with('paquete')->find($reservaId);
        if (!$reserva) {
            Log::error("Reserva no encontrada con ID: {$reservaId}");
            return response()->json(['error' => 'Reserva no encontrada'], 404);
        }

        $nombrePaquete = $reserva->paquete ? $reserva->paquete->nombre : 'Paquete no asociado';

        // Fechas formateadas o fallback
        $fechaReservaFormatted = $reserva->fecha_reserva ? date('d/m/Y', strtotime($reserva->fecha_reserva)) : 'No disponible';
        $fechaInicioFormatted = $reserva->paquete && $reserva->paquete->fecha_inicio ? date('d/m/Y', strtotime($reserva->paquete->fecha_inicio)) : null;
        $fechaFinFormatted = $reserva->paquete && $reserva->paquete->fecha_fin ? date('d/m/Y', strtotime($reserva->paquete->fecha_fin)) : null;

        $tipoPago = $reserva->metodo_pago ?? 'No disponible';
        $numCuotas = $reserva->num_cuotas ?? 'N/A';
        $importeCuotas = $reserva->importe_cuotas ?? 'N/A';
        $plazas = $reserva->num_personas ?? 'N/A';

        $ivaRate = 0.21;
        $precioTotal = $reserva->total_precio ?? 0;
        if ($precioTotal > 0) {
            $baseImponible = round($precioTotal / (1 + $ivaRate), 2);
            $iva = round($precioTotal - $baseImponible, 2);
        } else {
            $baseImponible = 0;
            $iva = 0;
        }

        // Formatear números para la factura
        $baseImponibleFormatted = number_format($baseImponible, 2, ',', '.');
        $ivaFormatted = number_format($iva, 2, ',', '.');
        $totalPrecio = number_format($precioTotal, 2, ',', '.');

        $clienteNombreCompleto = $cliente->nombre . ' ' . $cliente->apellidos;

        // Obtener participantes - deberás adaptar esta parte a cómo almacenas los participantes de la reserva
        // Por ejemplo, si tienes relación: $reserva->participantes()
        $participantes = $reserva->participantes ?? [];

        // Logo en base64
        $logoPath = public_path('images/logo2.png');
        $logoData = base64_encode(file_get_contents($logoPath));
        $logoBase64 = 'data:image/png;base64,' . $logoData;

        $htmlPdf = "
    <html>
    <head>
        <style>
            body { font-family: 'DejaVu Sans', Arial, sans-serif; color: #333; margin: 0; padding: 0; }
            .container { width: 100%; padding: 30px; }
            h1 { color: #35372e; margin-bottom: 0; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { padding: 12px 15px; border: none; text-align: left; font-size: 14px; }
            th { background-color: #35372e; color: white; }
            .total { font-weight: bold; font-size: 16px; text-align: right; padding-right: 15px; }
            .footer { margin-top: 40px; font-size: 12px; color: #999; text-align: center; }
            ul.participantes { list-style-type: none; padding-left: 0; font-size: 14px; }
            ul.participantes li { padding: 5px 0; border-bottom: 1px solid #eee; }
        </style>
    </head>
    <body>
        <div class='container'>
            <table width='100%' style='border-bottom: 2px solid #35372e; margin-bottom: 20px; padding-bottom: 10px;'>
                <tr>
                    <td style='width: 30%; vertical-align: middle;'>
                        <img src='{$logoBase64}' alt='Logo Empresa' style='height: 80px;'>
                    </td>
                    <td style='width: 70%; text-align: right; font-size: 14px; color: #555; vertical-align: middle;'>
                        <strong>Atalanta Travel S.L.</strong><br>
                        Calle Ejemplo 123, Madrid<br>
                        Tel: +34 912 345 678<br>
                        Email: info@atalanta.com<br>
                        NIF: B12345678
                    </td>
                </tr>
            </table>

            <h1>Factura de Reserva</h1>

            <p><strong>Número de Reserva:</strong> {$reservaId}</p>
            <p><strong>Experiencia: </strong> {$nombrePaquete}</p>
            <p><strong>Cliente:</strong> {$clienteNombreCompleto}</p>
            <p><strong>Fecha de Reserva:</strong> {$fechaReservaFormatted}</p>";

        if ($fechaInicioFormatted && $fechaFinFormatted) {
            $htmlPdf .= "
            <p><strong>Fecha Inicio de la experiencia:</strong> {$fechaInicioFormatted}</p>
            <p><strong>Fecha Fin de la experiencia:</strong> {$fechaFinFormatted}</p>";
        }

        $htmlPdf .= "
            <table>
                <tr><th>Concepto</th><th>Detalle</th></tr>
                <tr><td>Tipo de Pago</td><td>" . ucfirst($tipoPago) . "</td></tr>
                <tr><td>Número de Cuotas</td><td>{$numCuotas}</td></tr>
                <tr><td>Importe por Cuota</td><td>{$importeCuotas} €</td></tr>
                <tr><td>Número de viajeros</td><td>{$plazas}</td></tr>
                <tr><td>Base Imponible</td><td>{$baseImponibleFormatted} €</td></tr>
                <tr><td>IVA (21%)</td><td>{$ivaFormatted} €</td></tr>
                <tr><td><strong>Total Factura</strong></td><td><strong>{$totalPrecio} €</strong></td></tr>
            </table>
            <br><br><br><br>
            <h2>Viajeros</h2>
            <ul class='participantes'>";

        foreach ($participantes as $p) {
            $dni = $p['dni'] ?? 'N/A';
            $nombreP = $p['nombre'] ?? 'Nombre no disponible';
            $apellidosP = $p['apellidos'] ?? '';
            $emailP = $p['email'] ?? 'Email no disponible';
            $htmlPdf .= "<li>{$nombreP} {$apellidosP} - Email: {$emailP} - DNI: {$dni}</li>";
        }

        $htmlPdf .= "
            </ul>

            <div class='footer'>
                <p>Atalanta Travel S.L. - Todos los derechos reservados &copy; " . date('Y') . "</p>
            </div>
        </div>
    </body>
    </html>";

        $pdf = PDF::loadHTML($htmlPdf)->setPaper('A4');

        // Para descargar el PDF directamente:
        return $pdf->download("factura_reserva_{$reservaId}.pdf");

        // Si quieres enviarlo inline para visualizar en navegador:
        // return $pdf->stream("factura_reserva_{$reservaId}.pdf");
    }

    public function index()
    {
        return response()->json(Factura::all());
    }

    public function show($id)
    {
        $factura = Factura::find($id);
        return $factura
            ? response()->json($factura)
            : response()->json(['error' => 'Factura no encontrada'], 404);
    }

public function buscador(Request $request)
{
    $input = $request->query('input');

    Log::info('Input recibido en buscador:', ['input' => $input]);

    if (!$input) {
        return response()->json([], 200);
    }

    $resultados = DB::table('facturas')
        ->where('id', 'LIKE', "%{$input}%")
        ->orWhere('nombre_cliente', 'LIKE', "%{$input}%")
        ->orWhere('apellidos_cliente', 'LIKE', "%{$input}%")
        ->orWhere('email_cliente', 'LIKE', "%{$input}%")
        ->orWhere('reserva_id', 'LIKE', "%{$input}%")
        ->get();

    return response()->json($resultados, 200);
}


    public function destroy($id)
    {
        $factura = Factura::find($id);
        if (!$factura) {
            return response()->json(['error' => 'Factura no encontrada'], 404);
        }

        $factura->delete();
        return response()->json(['mensaje' => 'Factura eliminada']);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'cliente_id' => 'required|integer',
            'reserva_id' => 'required|integer',
            'nombre_cliente' => 'required|string|max:255',
            'apellidos_cliente' => 'required|string|max:255',
            'email_cliente' => 'required|email|max:255',
            'fecha_compra' => 'required|date',
            'metodo_pago' => 'required|string|max:255',
            'precio_total' => 'required|numeric',
            'iva' => 'required|numeric',
            'telefono_empresa' => 'required|string|max:50',
            'email_empresa' => 'required|email|max:255',
            'detalles' => 'nullable|string',
        ]);

        $factura = Factura::create($data);
        return response()->json($factura, 201);
    }

    public function generarFacturaSimple($facturaId)
    {
        Log::info("Inicio generación factura simple, facturaId: {$facturaId}");

        try {
            $factura = DB::table('facturas')->where('id', $facturaId)->first();

            if (!$factura) {
                Log::warning("Factura no encontrada con ID: {$facturaId}");
                return response()->json(['error' => 'Factura no encontrada'], 404);
            }

            Log::info("Factura encontrada: ", (array)$factura);

            $logoPath = public_path('images/logo2.png');
            Log::info("Ruta logo: {$logoPath}");

            if (!file_exists($logoPath)) {
                Log::error("Archivo de logo no encontrado en: {$logoPath}");
                return response()->json(['error' => 'Logo no encontrado'], 500);
            }

            $logoData = base64_encode(file_get_contents($logoPath));
            $logoBase64 = 'data:image/png;base64,' . $logoData;

            Log::info("Logo cargado y codificado correctamente.");

            $ivaRate = $factura->iva / 100;
            $precioTotal = $factura->precio_total;
            $baseImponible = round($precioTotal / (1 + $ivaRate), 2);
            $ivaValor = round($precioTotal - $baseImponible, 2);

            Log::info("Cálculos de base imponible e IVA realizados.", [
                'ivaRate' => $ivaRate,
                'precioTotal' => $precioTotal,
                'baseImponible' => $baseImponible,
                'ivaValor' => $ivaValor
            ]);

            $baseImponibleFormatted = number_format($baseImponible, 2, ',', '.');
            $ivaFormatted = number_format($ivaValor, 2, ',', '.');
            $precioTotalFormatted = number_format($precioTotal, 2, ',', '.');

            $fechaFormatted = date('d/m/Y', strtotime($factura->fecha_compra));

            $htmlPdf = "
            <html>
            <head>
                <style>
                    body { font-family: 'DejaVu Sans', sans-serif; color: #333; padding: 30px; }
                    h1 { color: #35372e; }
                    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                    th, td { padding: 10px; border-bottom: 1px solid #ddd; font-size: 14px; }
                    th { background-color: #35372e; color: white; }
                    .footer { margin-top: 50px; text-align: center; font-size: 12px; color: #999; }
                </style>
            </head>
            <body>
                <table width='100%' style='margin-bottom: 30px;'>
                    <tr>
                        <td style='width: 30%;'>
                            <img src='{$logoBase64}' alt='Logo Empresa' style='height: 80px;'>
                        </td>
                        <td style='text-align: right;'>
                            <strong>Atalanta Travel S.L.</strong><br>
                            Tel: {$factura->telefono_empresa}<br>
                            Email: {$factura->email_empresa}
                        </td>
                    </tr>
                </table>

                <h1>Factura</h1>

                <p><strong>Nº Factura:</strong> {$factura->id}</p>
                <p><strong>Fecha de Compra:</strong> {$fechaFormatted}</p>

                <h2>Cliente</h2>
                <p><strong>ID Cliente:</strong> {$factura->cliente_id}</p>
                <p><strong>Nombre:</strong> {$factura->nombre_cliente} {$factura->apellidos_cliente}</p>
                <p><strong>Email:</strong> {$factura->email_cliente}</p>

                <h2>Detalles de la Compra</h2>
                <table>
                    <tr><th>Reserva ID</th><td>{$factura->reserva_id}</td></tr>
                    <tr><th>Tipo de Pago</th><td>{$factura->metodo_pago}</td></tr>
                    <tr><th>Detalle</th><td>{$factura->detalles}</td></tr>
                    <tr><th>Base Imponible</th><td>{$baseImponibleFormatted} €</td></tr>
                    <tr><th>IVA ({$factura->iva}%)</th><td>{$ivaFormatted} €</td></tr>
                    <tr><th><strong>Total</strong></th><td><strong>{$precioTotalFormatted} €</strong></td></tr>
                </table>

                <div class='footer'>
                    <p>Atalanta Travel S.L. - Todos los derechos reservados &copy; " . date('Y') . "</p>
                </div>
            </body>
            </html>
        ";

            Log::info("HTML generado correctamente para PDF.");

            $pdf = Pdf::loadHTML($htmlPdf)->setPaper('A4');

            Log::info("PDF generado correctamente, listo para descargar.");

            return $pdf->download("factura_{$factura->id}.pdf");
        } catch (\Exception $e) {
            Log::error("Error generando factura: " . $e->getMessage(), ['exception' => $e]);
            return response()->json(['error' => 'Error generando factura.'], 500);
        }
    }
}
