<?php

namespace App\Http\Controllers\Pago;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Ssheduardo\Redsys\Facades\Redsys;
use Exception;
use Stripe\Stripe;
use Stripe\Checkout\Session;
use App\Models\Reserva;
use App\Models\Participante;
use App\Models\PaqueteTuristico;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Mail\ReservaConfirmacionMail;
use Tymon\JWTAuth\Facades\JWTAuth;



class PagoController extends Controller
{
    public function crearPago(Request $request)
    {
        Stripe::setApiKey(config('services.stripe.secret'));

        $session = Session::create([
            'payment_method_types' => ['card'],
            'line_items' => [[
                'price_data' => [
                    'currency' => 'eur',
                    'product_data' => [
                        'name' => 'Reserva de viaje',
                    ],
                    'unit_amount' => $request->total * 100, // en céntimos
                ],
                'quantity' => 1,
            ]],
            'mode' => 'payment',
            'success_url' => url('/pago/exito'),
            'cancel_url' => url('/pago/cancelado'),
        ]);

        return response()->json(['url' => $session->url]);
    }

    public function registrarReserva(Request $request)
    {
        try {
            Log::info('Inicio registrarReserva', ['request' => $request->all()]);

            $request->validate([
                'reservationToken' => 'required|string',
                'paqueteId' => 'required|integer|exists:paquetes_turisticos,id',
                'clienteId' => 'nullable|integer|exists:clientes,id',
                'tipoPago' => 'nullable|string',
                'cuotas' => 'nullable|integer',
                'importeCuotas' => 'nullable|numeric',
                'totalPrecio' => 'nullable|numeric',
                'plazas' => 'nullable|integer',
                'participantes' => 'required|array|min:1',
                'participantes.*.nombre' => 'required|string',
                'participantes.*.apellidos' => 'required|string',
                'participantes.*.email' => 'required|email',
                'participantes.*.dni' => 'nullable|string',
                'participantes.*.telefono' => 'nullable|string',
                'participantes.*.direccion' => 'nullable|string',
                'participantes.*.ciudad' => 'nullable|string',
                'participantes.*.provincia' => 'nullable|string',
                'participantes.*.fechaNacimiento' => 'nullable|date',
                'participantes.*.experiencia' => 'nullable|string',
                'participantes.*.motivacion' => 'nullable|string',
                'participantes.*.infoRelevante' => 'nullable|string',
            ]);

            Log::info('Validación pasada correctamente');

            $existingReserva = Reserva::where('reservation_token', $request->reservationToken)->first();
            if ($existingReserva) {
                Log::warning('Reserva ya existe con este token', ['token' => $request->reservationToken]);
                return response()->json([
                    'message' => 'Reserva ya registrada previamente',
                    'reserva_id' => $existingReserva->id,
                ], 200);
            }

            $tipoPago = strtolower($request->tipoPago);
            $numCuotas = $request->cuotas;
            $importeCuotas = $request->importeCuotas;

            $totalPrecio = $tipoPago === 'parcial' && $numCuotas && $importeCuotas
                ? $numCuotas * $importeCuotas
                : $request->totalPrecio;

            $reserva = new Reserva();
            $reserva->reservation_token = $request->reservationToken;
            $reserva->paquete_id = $request->paqueteId;
            $reserva->cliente_id = $request->clienteId;
            $reserva->metodo_pago = $request->tipoPago;
            $reserva->num_cuotas = $numCuotas;
            $reserva->importe_cuotas = $importeCuotas;
            $reserva->total_precio = $totalPrecio;
            $reserva->num_personas = $request->plazas;
            $reserva->fecha_reserva = now();
            $reserva->fecha_pago = now();
            $reserva->descuento = 0;
            $reserva->estado = 'Pendiente';

            $saved = $reserva->save();
            Log::info('Reserva guardada', ['reserva_id' => $reserva->id, 'saved' => $saved]);

            DB::table('notificaciones')->insert([
                'cliente_id' => $request->clienteId,
                'tipo' => 'reserva',
                'is_read' => 0,
                'fecha' => now(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            Log::info('Notificación creada');

            $paquete = PaqueteTuristico::find($request->paqueteId);
            $fechaInicio = $paquete ? $paquete->fecha_inicio : null;
            $fechaFin = $paquete ? $paquete->fecha_fin : null;

            if ($paquete && $request->plazas) {
                $paquete->plazas = max(0, $paquete->plazas - $request->plazas);
                $paquete->save();
                Log::info('Plazas paquete actualizadas', ['paquete_id' => $paquete->id, 'nuevas_plazas' => $paquete->plazas]);
            }

            foreach ($request->participantes as $index => $p) {
                DB::table('participantes')->insert([
                    'reserva_id' => $reserva->id,
                    'nombre' => $p['nombre'],
                    'apellidos' => $p['apellidos'],
                    'email' => $p['email'],
                    'dni' => $p['dni'] ?? null,
                    'telefono' => $p['telefono'] ?? null,
                    'direccion' => $p['direccion'] ?? null,
                    'ciudad' => $p['ciudad'] ?? null,
                    'provincia' => $p['provincia'] ?? null,
                    'fecha_nacimiento' => $p['fechaNacimiento'] ?? null,
                    'experiencia' => $p['experiencia'] ?? null,
                    'motivacion' => $p['motivacion'] ?? null,
                    'info_relevante' => $p['infoRelevante'] ?? null,
                ]);
                Log::info("Participante insertado", ['indice' => $index, 'nombre' => $p['nombre']]);
            }

            Log::info('Todos los participantes insertados');

            $participantesParaMail = $request->participantes;

            $user = JWTAuth::parseToken()->authenticate();

            $clienteEmail = $user->email;
            $clienteNombre = $user->name ?? 'Cliente';
            $clienteApellidos = $user->apellidos ?? '';

            $clienteNombreCompleto = trim($clienteNombre . ' ' . $clienteApellidos);

            // --- Aquí insertamos la factura ---
            $iva = 21;
            $telefonoEmpresa = '912345678';
            $emailEmpresa = 'empresa@example.com';
            $detalles = "Reserva de paquete turístico ID: {$paquete->id}";

            DB::table('facturas')->insert([
                'cliente_id' => $request->clienteId,
                'reserva_id' => $reserva->id,
                'nombre_cliente' => $clienteNombre,
                'apellidos_cliente' => $clienteApellidos,
                'email_cliente' => $clienteEmail,
                'fecha_compra' => now(),
                'metodo_pago' => $request->tipoPago,
                'precio_total' => $totalPrecio,
                'iva' => $iva,
                'telefono_empresa' => $telefonoEmpresa,
                'email_empresa' => $emailEmpresa,
                'detalles' => $detalles,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            Log::info('Factura registrada correctamente.');

            if ($clienteEmail) {
                $linkPagoCuotas = null;
                if ($tipoPago === 'cuotas') {
                    $linkPagoCuotas = url("/pagos/pendientes/{$reserva->id}");
                }

                Mail::to($clienteEmail)->send(new ReservaConfirmacionMail(
                    $clienteNombreCompleto,
                    $tipoPago,
                    $numCuotas,
                    $importeCuotas,
                    $request->plazas,
                    $totalPrecio,
                    $linkPagoCuotas,
                    $reserva,
                    $participantesParaMail,
                    $paquete ? $paquete->nombre : null,
                    $reserva->id,
                    $clienteNombreCompleto,
                    $fechaInicio,
                    $fechaFin
                ));
                Log::info('Email de confirmación enviado a ' . $clienteEmail);
                // --- Envío al admin ---
                $adminEmail = 'lourdes.hernandezsilva@viajesatalanta.com';
                Mail::to($adminEmail)->send(new \App\Mail\NotificacionNuevaReserva($reserva, $participantesParaMail));
            } else {
                Log::warning('No se encontró email para enviar confirmación');
            }

            Log::info('Fin registrarReserva');

            return response()->json([
                'message' => 'Reserva y participantes registrados correctamente',
                'reserva_id' => $reserva->id,
            ], 201);
        } catch (\Illuminate\Validation\ValidationException $e) {
            Log::error('Error de validación en registrarReserva', ['errors' => $e->errors()]);
            return response()->json([
                'message' => 'Error de validación',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            Log::error('Error al registrar la reserva: ' . $e->getMessage(), [
                'request' => $request->all(),
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json([
                'message' => 'Error al registrar la reserva',
                'error' => $e->getMessage(),
            ], 500);
        }
    }




    public function obtenerClienteUsuario(Request $request)
    {
        // Obtener el usuario autenticado con Auth
        $user = JWTAuth::parseToken()->authenticate();

        if (!$user) {
            return response()->json(['message' => 'Usuario no autenticado'], 401);
        }

        // Obtener el cliente vinculado al usuario autenticado
        $cliente = DB::table('clientes')->where('usuario_id', $user->id)->first();

        if (!$cliente) {
            return response()->json(['message' => 'Cliente no encontrado'], 404);
        }

        return response()->json($cliente);
    }
}
